package com.janas.apoco.generic;

import java.io.Serializable;

import android.util.Log;

public class KcalResult implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	public static final String CLAZZ_NAME = KcalResult.class.getSimpleName();
	
	
	private String mProdukt;
	private String mMarke;
	private String mGewicht;
	private String mEnergie;
	private String mBarcode;
	
	
	public KcalResult(String produkt, String marke, float gewicht, int energie, String barcode) {
		
		mProdukt = produkt;
		mMarke = marke;
		mGewicht = Float.toString(gewicht);
		mEnergie = Integer.toString(energie, 10);
		mBarcode = barcode;
		Log.d(CLAZZ_NAME, toString());
	}


	public String getmProdukt() {
		
		return mProdukt;
	}


	public String getmMarke() {
		
		return mMarke;
	}


	public String getmGewicht() {
		
		return mGewicht;
	}


	public String getmEnergie() {
		
		return mEnergie;
	}
	
	
	public String getBarcode() {
		
		return mBarcode;
	}


	@Override
	public String toString() {
		return "KcalResult [mProdukt=" + mProdukt + ", mMarke=" + mMarke
				+ ", mGewicht=" + mGewicht + ", mEnergie=" + mEnergie
				+ ", mBarcode=" + mBarcode + "]";
	}


	public void setmProdukt(String mProdukt) {
		this.mProdukt = mProdukt;
	}


	public void setmMarke(String mMarke) {
		this.mMarke = mMarke;
	}


	public void setmGewicht(String mGewicht) {
		this.mGewicht = mGewicht;
	}


	public void setmEnergie(String mEnergie) {
		this.mEnergie = mEnergie;
	}
	
	
	public void setBarcode(String barcode) {
		
		this.mBarcode = barcode;
	}
	
	
	

}
