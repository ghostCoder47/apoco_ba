package com.janas.apoco.network;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.janas.apoco.activity.interfaces.CloseableIF;
import com.janas.apoco.bluetooth.HandlerMessagesIF;

public class NetworkHandler extends Handler {

	
	public static final String CLAZZ_NAME = NetworkHandler.class.getSimpleName();
	
	
	private Context mContext;
	private CloseableIF mCloseableActivity;
	
	public NetworkHandler(Context context, boolean isCloseingRequire) {
		
		this.mContext = context;
		if (context instanceof CloseableIF && isCloseingRequire)
			this.mCloseableActivity = (CloseableIF) context;
	}
	
	@Override
	public void handleMessage(Message msg) {
		
		
		AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
		switch(msg.what) {
		
		case HandlerMessagesIF.NETWORK_NOT_AVAILABLE: 
			
			builder.setTitle("No Wifi Connection");
			builder.setMessage("The Network is unavailable. Please try your request again later.");
			builder.setPositiveButton("OK", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int whichButton) {

					if (null != mCloseableActivity) {
						
						mCloseableActivity.close();
					}
				}
				
				
			});
			builder.create().show();
			Log.d(CLAZZ_NAME, "NETWORK NOT AVAILABLE");
			
			break;
			
			
		case HandlerMessagesIF.WIFI_STATE_CONNECTED:
			
			Log.d(CLAZZ_NAME, "WIFI STATE: CONNECTED");
			break;
			
			
		case HandlerMessagesIF.NO_SERVER_RESPONSE_200: 
		
			builder.setTitle("Server antwortet nicht");
			builder.setMessage(String.format("IP: %s antwortet nicht. Netzwerk Aktivitäten können im Augenblick nicht ausgeführt werden.", msg.obj.toString()));
			builder.setPositiveButton("OK", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int whichButton) {

					if (null != mCloseableActivity) {
						
						mCloseableActivity.close();
					}
				}
				
				
			});
			builder.create().show();
			Log.d(CLAZZ_NAME, "NO SERVER RESPONSE: 200");
			break;
			
			
		case HandlerMessagesIF.NETWORK_DISCONNECTED:
			
			builder.setTitle("Netzwerk nicht verbunden");
			builder.setMessage("Netzwerk Aktivitäten können im Augenblick nicht ausgeführt werden");
			builder.setPositiveButton("OK", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int whichButton) {

					if (null != mCloseableActivity) {
						
						mCloseableActivity.close();
					}
				}
				
				
			});
			builder.create().show();
			Log.d(CLAZZ_NAME, "NETWORK DISCONNECTED");
			break;
			
			
		case HandlerMessagesIF.SERVER_RESPONDING_200_SUCCESS:
			
			Log.d(CLAZZ_NAME, "SERVER RESPONDING: 200 SUCCESS");
			break;
			
			
		case HandlerMessagesIF.URL_CONNECTION_ERROR:
			
			builder.setTitle(String.format("Server nicht erreichbar", msg.obj.toString()));
			builder.setMessage(String.format("Server IP: \"%s\" ist im moment nicht erreichbar. Netzwerk Aktivitäten können im Augenblick nicht ausgeführt werden", msg.obj.toString()));
			builder.setPositiveButton("OK", new OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int whichButton) {

					if (null != mCloseableActivity) {
						
						mCloseableActivity.close();
					}
				}
				
				
			});
			builder.create().show();
			Log.d(CLAZZ_NAME, "URL CONNECTION ERROR");
			
		}
	}
	
}
