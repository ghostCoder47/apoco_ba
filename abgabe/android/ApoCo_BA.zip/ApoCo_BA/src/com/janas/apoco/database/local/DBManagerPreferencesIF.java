package com.janas.apoco.database.local;

/**
 * Hier werden die Informationen über Datenbank Name und Version gehalten.
 * Genutzt für Verbindung mit interner Datenbank.
 * Die Versionsnummer steuert den Neuaufbar der Datenbank bei änderung.
 */
public interface DBManagerPreferencesIF {
	
	public static final String DATENBANK_NAME = "apoco.db";
	public static final int DATENBANK_VERSION = 10;
}
