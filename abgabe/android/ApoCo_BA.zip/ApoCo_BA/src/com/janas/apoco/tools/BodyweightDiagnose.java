package com.janas.apoco.tools;

import com.janas.apoco.arrayadapter.model.BodyweightModel;

public final class BodyweightDiagnose {

	
	
	public static String performDiagnose(BodyweightModel model, String wunschgewicht) {
		
		double wg = 0;
		double weight = 0;
		try {
			
			wg = Double.parseDouble(wunschgewicht);
			weight = Double.parseDouble(model.weight);
		} catch (NumberFormatException e) {
			
			return "---";
		}
		if (wg < weight) {
			
			return String.format("%.2f", (weight - wg)) + " bis zum Zielgewicht";
		} else return "Zielgewicht erreicht";
	}
	
}
