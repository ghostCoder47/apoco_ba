package com.janas.apoco.tools;

import android.content.Context;

import com.janas.apoco.database.extern.ExternServerDIR;
import com.janas.apoco.preferences.PreferencesManager;

public class URLBuilder {
	
	
	public String getURL(Context context, String phpURL) {
		
		String url = String.format(
				ExternServerDIR.ANDROID_CONNECTION_DIR, 
				new PreferencesManager(context).getServerIP()
				) + "%s";
		url = String.format(url, phpURL);
		return url;
	}

}
