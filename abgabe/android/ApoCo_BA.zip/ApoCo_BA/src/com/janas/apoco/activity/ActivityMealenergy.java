package com.janas.apoco.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.arrayadapter.MealContentAdapter;
import com.janas.apoco.arrayadapter.model.MealContentModel;
import com.janas.apoco.arrayadapter.model.MealModel;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.database.local.dto.MealenergyDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.generic.KcalResult;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.GetFood;
import com.janas.apoco.network.asynctask.SynchronizeBodyweight;
import com.janas.apoco.network.asynctask.SynchronizeMealenergy;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.zxing.IntentIntegrator;
import com.janas.apoco.zxing.IntentResult;

public class ActivityMealenergy extends Activity {

	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = ActivityFoodKcal.class.getSimpleName();
	public static final int FOOD_SUCCESS 	= 0x0;
	public static final int FOOD_FAILED		= 0x1;
	public static final int SYNCHRONIZING_DATA_COMPLETE = 0x2;
	public static final int SYNCHRONIZING_DATA_FAILED 	= 0x3;
	
	private Button mBarcodeScannBtn, mOKBtn, mBackBtn;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;	
	private TextView mGesammtenergieTv, mFreieEinheitenTv;	
	private ArrayList<MealContentModel> mMealContentList;
	private MealContentAdapter mMealenergyContentAdapter;	
	private ListView mMealenergyContentLV;	
	private Handler mHandlerAct;	
	private int mGesammtenergie, mTageseinheiten;
	private MealenergyDTO mMealenergy;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_mealenergy);
		
		
		setupBarcodeScannBtn();
		setupOKBtn();	//to do sync
		setupBackBtn();
		setupUser();
		setupDBManager();
		setupGesammtenergieTv();
		setupTageseinheiten();
		setupFreieEinheitenTv();
		setupMealContentList();
		setupMealenergyAdapter();
		setupMealenergyContentLV();
		setupHandlerAct();
		
	}

	
	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}


	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}
	

	private void setupBarcodeScannBtn() {
		
		mBarcodeScannBtn = (Button) findViewById(R.id.btnBarcodeScann);
		mBarcodeScannBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				IntentIntegrator integrator = new IntentIntegrator(ActivityMealenergy.this);
				integrator.initiateScan();
			}
		});
	}


	private void setupOKBtn() {
		
		mOKBtn = (Button) findViewById(R.id.btnOK);
		mOKBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				//try to sync 
//				Context activity = ActivityMealenergy.this;
//				new SynchronizeMealenergy(activity, new NetworkHandler(activity), mHandlerAct).execute(mUser);
				
				
//				Intent result = new Intent();
//				result.putExtra(ActivityExtrasCodesIF.KCAL_RESULT, kcalResult);
				setResult(RESULT_OK);		
				onBackPressed();
			}
		});
	}

	
	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}
	
	
	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityMealenergy.this);
	}
	

	private void setupGesammtenergieTv() {
		
		mGesammtenergieTv = (TextView) findViewById(R.id.gesammtenergieTv);
		mGesammtenergie = getIntent().getIntExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, 0);		
		mGesammtenergieTv.setText(Integer.toString(mGesammtenergie));
	}

	
	
	private void setupTageseinheiten() {
		
		mTageseinheiten = getIntent().getIntExtra(ActivityExtrasCodesIF.TAGESEINHEITEN, 0);	
	}
	

	private void setupFreieEinheitenTv() {
		
		mFreieEinheitenTv = (TextView) findViewById(R.id.freieeinheitenTv);
		int freieEinheiten = mTageseinheiten - mGesammtenergie;
		mFreieEinheitenTv.setText(Integer.toString(freieEinheiten));
		if (freieEinheiten <= 0) {
		
			mFreieEinheitenTv.setTextColor(Color.RED);
			
			AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMealenergy.this);
			builder.setTitle("Freieinheiten überschritten");
			builder.setMessage(String.format("Die zugelassenen Freieinheiten von: %d kcal wurden für Heute überschritten", mTageseinheiten));
			builder.setPositiveButton("OK", null);
			builder.create().show();
		}
		else
			mFreieEinheitenTv.setTextColor(Color.BLACK);
	}


	private void setupMealContentList() {
		
		mMealContentList = new ArrayList<MealContentModel>();
	}


	private void setupMealenergyAdapter() {
		
		mMealenergyContentAdapter = new MealContentAdapter(ActivityMealenergy.this, mMealContentList);
	}


	private void setupMealenergyContentLV() {
		
		mMealenergyContentLV = (ListView) findViewById(R.id.mealenergy_contentListView);
		mMealenergyContentLV.setAdapter(mMealenergyContentAdapter);
		mMealenergyContentLV.setOnItemClickListener(new OnItemClickListener() {
			
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				
				Object o = mMealenergyContentAdapter.getItem(position);
				if (o instanceof MealModel) {
					
					String barcode = ((MealContentModel) o).barcode;
					
					//TO DO
//					Intent mealenergyIntent = new Intent(getApplicationContext(), ActivityMealenergyDetails.class);
//					mealenergyIntent.putExtra(ActivityExtrasCodesIF.MEAL_ID, barcode);	
//					startActivity(mealenergyIntent);
//					overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
					
					FoodDTO food = mDBManager.getFood(barcode);					
					Toasting.inScreenCenter(getApplicationContext(), food.toString());				
					
				}
			}
		
		});
	}

	
	public void setupHandlerAct() {
		
		mHandlerAct = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				
				switch (msg.what) {
				
				case FOOD_SUCCESS:
					
					FoodDTO food = (FoodDTO) msg.obj;
					Intent mealenergyContent = new Intent(getApplicationContext(), ActivityMealenergyContent.class);
					mealenergyContent.putExtra(ActivityExtrasCodesIF.FOOD, food);	
					mealenergyContent.putExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, mGesammtenergie);
					mealenergyContent.putExtra(ActivityExtrasCodesIF.TAGESEINHEITEN, mTageseinheiten);
					startActivityForResult(mealenergyContent, ActivityRequestCodesIF.REQUEST_NEW_KCAL_ENTRY);
					overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
					break;
					
					
				case FOOD_FAILED:
					
					AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMealenergy.this);
					builder.setTitle("unbekanter Barcode");
					String why = msg.obj.toString();
					builder.setMessage(why);
					builder.setPositiveButton("OK", null);
					builder.create().show();
					break;
					
					
				case SYNCHRONIZING_DATA_COMPLETE:
					
					onBackPressed();
					break;
				}
			}
		};
	}
	
	
	@Override
	protected void onActivityResult(int pRequestCode, int pResultCode, Intent pData) {
		
		super.onActivityResult(pRequestCode, pResultCode, pData);
		switch(pRequestCode) {
		
		
		case IntentIntegrator.REQUEST_CODE:
			
			if (RESULT_OK == pResultCode) {
				
				if (null == pData) return;
				
				IntentResult scanResult = IntentIntegrator.parseActivityResult(pRequestCode, pResultCode, pData);
				String barcode = scanResult.getContents();
				Toasting.inScreenCenter(getApplicationContext(), "Barcode: " + barcode);
				Context activity = ActivityMealenergy.this;
				new GetFood(activity, new NetworkHandler(activity, true), mHandlerAct).execute(barcode);
			}
			break;
			
			
		case ActivityRequestCodesIF.REQUEST_NEW_KCAL_ENTRY:
			
			Log.d(CLAZZ_NAME, "new kcal entry");
			if (RESULT_OK == pResultCode) {
				
				Log.d(CLAZZ_NAME, "RESULT_OK");
				if (null == pData) return;
				
				KcalResult kcalResult = (KcalResult) pData.getSerializableExtra(ActivityExtrasCodesIF.KCAL_RESULT);
				MealContentModel mealModel = MealContentModel.convertResult_to_MODEL(kcalResult);
				mMealenergyContentAdapter.add(mealModel);
				if (null == mMealenergy) {
					
					mMealenergy = new MealenergyDTO(mUser);
					mMealenergy._id = mDBManager.insertMealenergy(mMealenergy);
				}
				MealenergyContentDTO mealContent = new MealenergyContentDTO(kcalResult, mMealenergy);
				mDBManager.insertMealenergyContent(mealContent);
				updateEnergie(mealContent.energie_kcal);
			} else {
				
				Log.d(CLAZZ_NAME, "RESULT_NOT_OK: " + pResultCode);
			}
						
		}
	}
	
	
	private void updateEnergie(int energie) {
		
		mGesammtenergie += energie;
		mGesammtenergieTv.setText(Integer.toString(mGesammtenergie));
		setupFreieEinheitenTv();
	}
	
	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
}
