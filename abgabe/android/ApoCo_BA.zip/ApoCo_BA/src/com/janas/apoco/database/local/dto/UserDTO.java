package com.janas.apoco.database.local.dto;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.database.local.tbl.UserTbl;


public class UserDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = UserDTO.class.getSimpleName();

	
	public long _id;
	public String vorname;
	public String nachname;
	public String email;
	public String password;
	
	
	public UserDTO() {}
	
	
	public UserDTO(long id, String vorname, String nachname, String email, String password) {
		
		this._id 		= id;
		this.vorname 	= vorname;
		this.nachname	= nachname; 
		this.email 		= email;
		this.password 	= password;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public UserDTO(Cursor cursor) {
		
		int idxID 		= cursor.getColumnIndex(UserTbl._ID);
		int idxVorname	= cursor.getColumnIndex(UserTbl.VORNAME);
		int idxNachname = cursor.getColumnIndex(UserTbl.NACHNAME);
		int idxEmail 	= cursor.getColumnIndex(UserTbl.EMAIL);
		int idxPassword = cursor.getColumnIndex(UserTbl.PASSWORD);
		
		this._id 		= cursor.getLong(idxID);
		this.vorname 	= cursor.getString(idxVorname);
		this.nachname	= cursor.getString(idxNachname);
		this.email 		= cursor.getString(idxEmail);
		this.password 	= cursor.getString(idxPassword);
		cursor.close();
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		
		return _id;
	}


	public void set_id(long _id) {
		
		this._id = _id;
	}


	public String getVorname() {
		
		return vorname;
	}


	public void setVorname(String vorname) {
		
		this.vorname = vorname;
	}


	public String getNachname() {
		
		return nachname;
	}


	public void setNachname(String nachname) {
		
		this.nachname = nachname;
	}


	public String getEmail() {
		
		return email;
	}


	public void setEmail(String email) {
		
		this.email = email;
	}


	public String getPassword() {
		
		return password;
	}


	public void setPassword(String password) {
		
		this.password = password;
	}


	@Override
	public String toString() {
		return "UserDTO [_id=" + _id + ", vorname=" + vorname + ", nachname="
				+ nachname + ", email=" + email + ", password=" + password
				+ "]";
	}
	
	
	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(UserTbl._ID, this._id);
			obj.put(UserTbl.VORNAME, this.vorname);
			obj.put(UserTbl.NACHNAME, this.nachname);
			obj.put(UserTbl.EMAIL, this.email);
			obj.put(UserTbl.PASSWORD, this.password);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}
	

}
