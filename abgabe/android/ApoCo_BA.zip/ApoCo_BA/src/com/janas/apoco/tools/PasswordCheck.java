package com.janas.apoco.tools;

import android.util.Log;

public class PasswordCheck {
	
	
	public static final String CLAZZ_NAME = PasswordCheck.class.getSimpleName();
	public static final int PASSWORD_LENGTH = 4;
		
	
	public boolean correctPassword(final String password, final String confirm) {
		
		Log.d(CLAZZ_NAME, "length: " + password.length());
		
		return password.length() >= PASSWORD_LENGTH ? 
				(!password.equals("") ? password.equals(confirm):false)
				: false; 
	}

}
