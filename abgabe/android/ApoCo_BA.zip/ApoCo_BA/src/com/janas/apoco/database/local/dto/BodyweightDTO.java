package com.janas.apoco.database.local.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.bodytel.BodyweightResult;
import com.janas.apoco.database.local.tbl.BodyweightTbl;
import com.janas.apoco.tools.TimeTools;

public class BodyweightDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = BodyweightDTO.class.getSimpleName();
	
	
	public long _id;
	public long u_id;
	public Timestamp added_on;
	public double weight;
	public String unit;
	public int sync;
	public String devicename;
	
	
	public BodyweightDTO(UserDTO user, BodyweightResult result) throws NumberFormatException {
		
		this.u_id = user._id;
		this.added_on = result.getRecordDate();
		this.weight = Double.valueOf(result.getWeight());
		this.unit = result.getUnit();
		this.devicename = result.getDeviceName();
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public BodyweightDTO(long id, long u_id, long added_on, double weight, String unit, int sync, String devicename) {
		
		this._id = id;
		this.u_id = u_id;
		this.added_on = new Timestamp(added_on);
		this.weight = weight;
		this.unit = unit;
		this.sync = sync;
		this.devicename = devicename;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public BodyweightDTO(Cursor cursor) {
		
		int idxID 				= cursor.getColumnIndex(BodyweightTbl._ID);
		int idxU_id				= cursor.getColumnIndex(BodyweightTbl.U_ID);
		int idxAdded_on 		= cursor.getColumnIndex(BodyweightTbl.ADDED_ON);
		int idxWeight		 	= cursor.getColumnIndex(BodyweightTbl.WEIGHT);
		int idxUnit				= cursor.getColumnIndex(BodyweightTbl.UNIT);
		int idxSync				= cursor.getColumnIndex(BodyweightTbl.SYNC);
		int idxDevicename		= cursor.getColumnIndex(BodyweightTbl.DEVICENAME);
		
		this._id 			= cursor.getLong(idxID);
		this.u_id 			= cursor.getLong(idxU_id);
		this.added_on		= new Timestamp(cursor.getLong(idxAdded_on));
		this.weight			= cursor.getDouble(idxWeight);
		this.unit			= cursor.getString(idxUnit);
		this.sync			= cursor.getInt(idxSync);
		this.devicename		= cursor.getString(idxDevicename);
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public long getU_id() {
		return u_id;
	}


	public void setU_id(int u_id) {
		this.u_id = u_id;
	}


	public Timestamp getAdded_on() {
		return added_on;
	}


	public void setAdded_on(Timestamp added_on) {
		this.added_on = added_on;
	}


	public double getWeight() {
		return weight;
	}


	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	
	public String getUnit() {
		
		return unit;
	}
	
	
	public void setUnit(String unit) {
		
		this.unit = unit;
	}


	public int getSync() {
		return sync;
	}


	public void setSync(int sync) {
		this.sync = sync;
	}
	
	
	public String getDevicename() {
		
		return devicename;
	}
	
	
	public void setDevicename(String devicename) {
		
		this.devicename = devicename;
	}
	
	
	@Override
	public String toString() {
		return "BodyweightDTO [_id=" + _id + ", u_id=" + u_id + ", added_on="
				+ added_on + ", weight=" + weight + ", unit=" + unit
				+ ", sync=" + sync + ", devicename=" + devicename + "]";
	}


	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(BodyweightTbl._ID, this._id);
			obj.put(BodyweightTbl.U_ID, this.u_id);
			obj.put(BodyweightTbl.ADDED_ON, this.added_on);
			obj.put(BodyweightTbl.WEIGHT, this.weight);
			obj.put(BodyweightTbl.UNIT, this.unit);
			obj.put(BodyweightTbl.SYNC, this.sync);
			obj.put(BodyweightTbl.DEVICENAME, this.devicename);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}

}
