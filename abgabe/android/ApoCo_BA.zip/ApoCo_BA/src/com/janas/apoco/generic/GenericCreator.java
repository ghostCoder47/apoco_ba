package com.janas.apoco.generic;

import java.io.IOException;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.interfaces.AccessableCreatorIF;
import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bodytel.PressureTelConnectedThread;
import com.janas.apoco.bodytel.PressureTelCreator;

public class GenericCreator implements AccessableCreatorIF {

	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = PressureTelCreator.class.getSimpleName();
		
		
	@Override
	public AccessableIF createAccessable(Handler pHandler, BluetoothSocket pSocket) {
			
		KcalConnectedThread connectedTask = null;
		try {
				
			connectedTask = new KcalConnectedThread(pHandler, pSocket);
		} catch (IOException e) {
			

			e.printStackTrace();
		}
		if (DEBUG) Log.d(CLAZZ_NAME, "accessable created");
		return connectedTask;
	}

}
