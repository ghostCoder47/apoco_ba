package com.janas.apoco.tools;

public final class HexConverter {
	

	public static byte[] hexStringToByteArray(String pString) {
		
	    int len = pString.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	    	
	        data[i / 2] = (byte) ((Character.digit(pString.charAt(i), 16) << 4) + Character.digit(pString.charAt(i+1), 16));
	    }
	    return data;
	}
	
	
	public static String hexBytesToString(byte[] pBuffer, int pReadedBytes) {
		
		StringBuilder result = new StringBuilder();
		for(int i = 0; i<pReadedBytes; i++) {
        	
        	String hex = String.format("%02x", pBuffer[i]);
        	result.append(hex);
        }
		
		return result.toString();
	}
	
	
	public static byte[] StringToHexByteArray(String pString) {
		
		byte[] result = pString.getBytes();
		return result;
	}
	
	
	public static String hexToASCII(String hex) {   
		
        if(hex.length()%2 != 0){
        	
           return null;
        }
        StringBuilder sb = new StringBuilder();                
        
        for( int i=0; i < hex.length()-1; i+=2 ){
        	
            String output = hex.substring(i, (i + 2));
            int decimal = Integer.parseInt(output, 16);                  
            sb.append((char)decimal);              
        }            
        return sb.toString();
	}
	
	
	public static String asciiToHex(String ascii) {
		
        StringBuilder hex = new StringBuilder();
        
        for (int i=0; i < ascii.length(); i++) {
        	
            hex.append(Integer.toHexString(ascii.charAt(i)));
        }       
        return hex.toString();
    } 
	
	
	
}
