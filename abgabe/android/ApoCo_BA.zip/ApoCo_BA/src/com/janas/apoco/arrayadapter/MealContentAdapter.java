package com.janas.apoco.arrayadapter;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.arrayadapter.model.MealContentModel;

public class MealContentAdapter extends BaseAdapter {

	
	private ArrayList<MealContentModel> mData;
	private LayoutInflater mInflater;
	
	
	public MealContentAdapter(Activity pContext, ArrayList<MealContentModel> pData) {
		
		mInflater = LayoutInflater.from(pContext);
		mData = pData;		
	}
	
	
	public void add(MealContentModel mm) {
		
		mData.add(0, mm);
		notifyDataSetChanged();
	}

	
	@Override
	public int getCount() {
		
		return mData.size();
	}

	
	@Override
	public Object getItem(int position) {
		
		return mData.get(position);
	}

	
	@Override
	public long getItemId(int position) {
		
		return position;
	}

	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View rowView = convertView;
		ViewContainer viewContainer;
		if (null == rowView) {
		
			rowView = mInflater.inflate(R.layout.mealenergy_content_entry, null);
			
			viewContainer 				= new ViewContainer();
			viewContainer.mProdukt 		= (TextView) rowView.findViewById(R.id.produkt);
			viewContainer.mMarke 		= (TextView) rowView.findViewById(R.id.marke);
			viewContainer.mGewicht 		= (TextView) rowView.findViewById(R.id.gewicht);
			viewContainer.mGewichtUnit 	= (TextView) rowView.findViewById(R.id.gewichtUnit);
			viewContainer.mEnergie		= (TextView) rowView.findViewById(R.id.energie);
			viewContainer.mEnergieUnit 	= (TextView) rowView.findViewById(R.id.energieUnit);
			
			rowView.setTag(viewContainer);
			
		} else {
			
			viewContainer = (ViewContainer) rowView.getTag();
		}
		
		MealContentModel mm = mData.get(position);
			
		viewContainer.mProdukt.setText(mm.produkt);
		viewContainer.mMarke.setText(mm.marke);
		viewContainer.mGewicht.setText(mm.gewicht);
		viewContainer.mGewichtUnit.setText("g");
		viewContainer.mEnergie.setText(mm.energie);
		viewContainer.mEnergieUnit.setText("kcal");
		
		return rowView;
	}
	
	
	static class ViewContainer {
		
		public TextView mProdukt;
		public TextView mMarke;
		public TextView mGewicht;
		public TextView mGewichtUnit;
		public TextView mEnergie;
		public TextView mEnergieUnit;
	}
	
	
	

}
