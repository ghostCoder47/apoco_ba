package com.janas.apoco.activity;

import java.util.ArrayList;
import java.util.LinkedList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.arrayadapter.MealenergyAdapter;
import com.janas.apoco.arrayadapter.model.MealContentModel;
import com.janas.apoco.arrayadapter.model.MealModel;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.database.local.dto.MealenergyDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.CurrentTageseinheiten;
import com.janas.apoco.network.asynctask.SynchronizeMealenergy;
import com.janas.apoco.tools.Toasting;

public class ActivityFoodKcal extends Activity {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = ActivityFoodKcal.class.getSimpleName();
	public static final int UPDATE_TAGESEINHEITEN = 0x0;	//CurrentTageseinheiten.UPDATE_TAGESEINHEITEN;
	public static final int INIT_LIST = 0x1;
	public static final int SYNCHRONIZING_DATA_COMPLETE = 0x2;
	public static final int SYNCHRONIZING_DATA_FAILED = 0x3;
	
	private Button mNewMealBtn, mOKBtn, mBackBtn, mDevicesBtn, mStartBtn;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	
	private TextView mGesammtenergieTv, mFreieEinheitenTv;
	
	
	private ArrayList<MealModel> mMealList;
	private MealenergyAdapter mMealenergyAdapter;	
	private ListView mMealLV;
	
	
	private Handler mHandlerAct;	
	private int mGesammtenergie, mTageseinheiten;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_foodkcal);
		
		setupUser();
		setupDBManager();
		setupNewMealBtn();
		setupOKBtn();
		setupBackBtn();
		setupDevicesBtn();
		setupStartBtn();
		setupHandlerAct();		
		setupMealList();
		setupMealenergyAdapter();		
		setupMealLV();
		setupTageseinheiten();
		setupGesammtenergieTv();
		initList();		
		
		
	}
	
	
	private void setupStartBtn() {
		
		mStartBtn = (Button) findViewById(R.id.btnStart);
		mStartBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});		
	}


	private void setupDevicesBtn() {
		
		mDevicesBtn = (Button) findViewById(R.id.btnDevices);
		mDevicesBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lDevicesScreen = new Intent(getApplicationContext(), ActivityDevices.class);
				startActivityForResult(lDevicesScreen, ActivityRequestCodesIF.WHO_IS_CALLER_ACTIVITY);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);
			}
		});
	}


	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}


	@Override
	public void onResume() {
		
		super.onResume();			
	}

	
	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}
	

	private void setupNewMealBtn() {
		
		mNewMealBtn = (Button) findViewById(R.id.btnNewMeal);
		mNewMealBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
								
				Intent mealenergyIntent = new Intent(getApplicationContext(), ActivityMealenergy.class);
				mealenergyIntent.putExtra(ActivityExtrasCodesIF.USER, mUser);
				mealenergyIntent.putExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, mGesammtenergie);
				mealenergyIntent.putExtra(ActivityExtrasCodesIF.TAGESEINHEITEN, mTageseinheiten);
				startActivityForResult(mealenergyIntent, ActivityRequestCodesIF.REQUEST_NEW_MEAL);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
	}


	private void setupOKBtn() {
		
		mOKBtn = (Button) findViewById(R.id.btnOK);
		mOKBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				Context activity = ActivityFoodKcal.this;
				new SynchronizeMealenergy(activity, new NetworkHandler(activity, true), mHandlerAct).execute(mUser);
//				onBackPressed();
			}
		});
	}

	
	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}
	
	
	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityFoodKcal.this);
	}
	

	private void setupGesammtenergieTv() {
		
		mGesammtenergieTv = (TextView) findViewById(R.id.gesammtenergieTv);
		mGesammtenergie = 0;
		
		Log.d(CLAZZ_NAME, "setupGesammtenergieTv()");
		
		Cursor cursor = mDBManager.dayMealList(mUser);
		if (null != cursor) {
			
			Log.d(CLAZZ_NAME, "cursor != null");
			
			while (cursor.moveToNext()) {
				
				int id = cursor.getInt(0);
				Log.d(CLAZZ_NAME, "id: " + id);
				
				Cursor mealenergyContents = mDBManager.mealenergyContent(id);
				while (mealenergyContents.moveToNext()) {
					
					MealenergyContentDTO content = new MealenergyContentDTO(mealenergyContents);
					mGesammtenergie += content.energie_kcal;
					Log.d(CLAZZ_NAME, "mGesammtenergie: " + mGesammtenergie);
				}
				mealenergyContents.close();
			}
			cursor.close();
		} else {
			
			Log.d(CLAZZ_NAME, "cursor is null");
		}
		
		mGesammtenergieTv.setText(Integer.toString(mGesammtenergie));
	}


	private void setupFreieEinheitenTb() {
		
		mFreieEinheitenTv = (TextView) findViewById(R.id.freieeinheitenTv);
		int freieEinheiten = mTageseinheiten - mGesammtenergie;
		mFreieEinheitenTv.setText(Integer.toString(freieEinheiten));
		if (freieEinheiten <= 0) {
		
			mFreieEinheitenTv.setTextColor(Color.RED);
			
			AlertDialog.Builder builder = new AlertDialog.Builder(ActivityFoodKcal.this);
			builder.setTitle("Freieinheiten überschritten");
			builder.setMessage(String.format("Die zugelassenen Freieinheiten von: %d kcal wurden für Heute überschritten", mTageseinheiten));
			builder.setPositiveButton("OK", null);
			builder.create().show();
		}
		else
			mFreieEinheitenTv.setTextColor(Color.BLACK);
	}


	private void setupMealList() {
		
		mMealList = new ArrayList<MealModel>();
	}


	private void setupMealenergyAdapter() {
		
		mMealenergyAdapter = new MealenergyAdapter(ActivityFoodKcal.this, mMealList);
	}


	private void setupMealLV() {
		
		mMealLV = (ListView) findViewById(R.id.mealListView);
		mMealLV.setAdapter(mMealenergyAdapter);
		mMealLV.setOnItemClickListener(new OnItemClickListener() {
			
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				
				Object o = mMealenergyAdapter.getItem(position);
				if (o instanceof MealModel) {
					
					int mealid = (int)((MealModel) o).mealId;
					
					Intent mealenergyIntent = new Intent(getApplicationContext(), ActivityMealenergyDetails.class);
//					mealenergyIntent.putExtra(ActivityExtrasCodesIF.MEAL_ID, mealid);						
					
					Cursor cursor = mDBManager.initMealenergyContent(mealid);	
					ArrayList<MealContentModel> modelList = null;
					while (cursor.moveToNext()) {
						
						if (null == modelList) modelList = new ArrayList<MealContentModel>();
						
						FoodDTO food = mDBManager.getFood(cursor.getString(2));
						MealenergyContentDTO mc = new MealenergyContentDTO(cursor);
						modelList.add(new MealContentModel(mc, food));
					}
					mealenergyIntent.putExtra(ActivityExtrasCodesIF.MEAL_MODEL, modelList);
					startActivity(mealenergyIntent);
					overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
					
				}
			}
		
		});
	}

	
	private void setupHandlerAct() {
		
		mHandlerAct = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				
				switch	(msg.what) {
				
				case UPDATE_TAGESEINHEITEN:
					
					mTageseinheiten = mDBManager.currentTageseinheiten(mUser).tageseinheiten;
					setupFreieEinheitenTb();
					break;
					
					
				case INIT_LIST:
					
					mMealenergyAdapter.add( (MealModel) msg.obj);
					break;
					
				
				case SYNCHRONIZING_DATA_COMPLETE:
				case SYNCHRONIZING_DATA_FAILED:
					
					onBackPressed();
					break;
				}
			}
		};
	}
	
	
	private void setupTageseinheiten() {
		
		Context activity = ActivityFoodKcal.this;
		new CurrentTageseinheiten(activity, new NetworkHandler(activity, true), mHandlerAct).execute(mUser);
	}
	
	
	private void initList() {
		
		
		new Thread() {			
			
			@Override
			public void run() {
				
				Cursor cursor = mDBManager.initMealenergy(mUser);
				while (cursor.moveToNext()) {
					
					MealenergyDTO mealenergy = new MealenergyDTO(cursor);					
					
					Cursor content = mDBManager.initMealenergyContent(mealenergy._id);
					int energySum = 0;
					while (content.moveToNext()) {
						
						MealenergyContentDTO mealContent = new MealenergyContentDTO(content);
						energySum += mealContent.energie_kcal;
					}
					MealModel meal = MealModel.convertDTO_to_MODEL(mealenergy, energySum);
					mHandlerAct.obtainMessage(INIT_LIST, meal).sendToTarget();
//					mMealenergyAdapter.add(meal);
				}
				cursor.close();
				Log.d(CLAZZ_NAME, "finish initList()");
				
			}
		}.start();
	}
	
	
	@Override
	protected void onActivityResult(int pRequestCode, int pResultCode, Intent pData) {
		
		super.onActivityResult(pRequestCode, pResultCode, pData);
		switch(pRequestCode) {
		
					
		case ActivityRequestCodesIF.REQUEST_NEW_MEAL:
			
			Log.d(CLAZZ_NAME, "new meal");
			if (RESULT_OK == pResultCode) {
				
				setupMealList();
				setupMealenergyAdapter();		
				setupMealLV();
				setupTageseinheiten();
				setupGesammtenergieTv();
				initList();		
				
//				Log.d(CLAZZ_NAME, "RESULT_OK");
//				if (null == pData) return;
//				
//				KcalResult kcalResult = (KcalResult) pData.getSerializableExtra(ActivityExtrasCodesIF.KCAL_RESULT);
//				MealContentModel mealModel = MealContentModel.convertResult_to_MODEL(kcalResult);
//				mMealenergyContentAdapter.add(mealModel);
//				if (null == mMealenergy) {
//					
//					mMealenergy = new MealenergyDTO(mUser);
//					mMealenergy._id = mDBManager.insertMealenergy(mMealenergy);
//				}
//				MealenergyContentDTO mealContent = new MealenergyContentDTO(kcalResult, mMealenergy);
//				mDBManager.insertMealenergyContent(mealContent);
//				updateEnergie(mealContent.energie_kcal);
			} else {
				
				Log.d(CLAZZ_NAME, "RESULT_NOT_OK: " + pResultCode);
			}
						
		}
	}	
	
	
	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}

}
