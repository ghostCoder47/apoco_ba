package com.janas.apoco.bodytel;

import java.util.UUID;

public interface BodyTelUUIDsIF {

	public static final UUID PRESSURETEL_UUID_SPP_1234 = UUID.fromString("00001234-0000-1000-8000-00805f9b34fb");
	public static final UUID WEIGHTTEL_UUID_SPP_1101 = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
}
