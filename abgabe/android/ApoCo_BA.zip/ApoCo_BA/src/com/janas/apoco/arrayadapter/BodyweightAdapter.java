package com.janas.apoco.arrayadapter;


import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.arrayadapter.model.BodyweightModel;
import com.janas.apoco.bodytel.BodyweightResult;
import com.janas.apoco.database.local.dto.BodyweightDTO;

public class BodyweightAdapter extends BaseAdapter {

	
	private ArrayList<BodyweightModel> mData;
	private LayoutInflater mInflater;
	
	
	public BodyweightAdapter(Activity pContext, ArrayList<BodyweightModel> pData) {
		
		mInflater = LayoutInflater.from(pContext);
		mData = pData;		
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View rowView = convertView;
		ViewContainer viewContainer;
		if (null == rowView) {
		
			rowView = mInflater.inflate(R.layout.bodyweight_entry, null);
			
			viewContainer = new ViewContainer();
			viewContainer.mTitle = (TextView) rowView.findViewById(R.id.title);
			viewContainer.mTimestamp = (TextView) rowView.findViewById(R.id.date);
			viewContainer.mWeight = (TextView) rowView.findViewById(R.id.bodyweightValue);
			viewContainer.mUnit = (TextView) rowView.findViewById(R.id.unitBP);
			
			rowView.setTag(viewContainer);
			
		} else {
			
			viewContainer = (ViewContainer) rowView.getTag();
		}
		
		viewContainer.mTitle.setText("Gewicht");
		
		BodyweightModel bwm = mData.get(position);
			
		viewContainer.mTimestamp.setText(bwm.added_on);
		viewContainer.mWeight.setText(bwm.weight);
		viewContainer.mUnit.setText(bwm.unit);
		
		
		return rowView;
	}
	
	
	public void add(BodyweightModel bwm) {
		
		mData.add(0, bwm);
		notifyDataSetChanged();
	}
	
	
	public void add(BodyweightDTO bwdto) {
		
		BodyweightModel bwm = BodyweightModel.convertDTO_to_MODEL(bwdto);
		add(bwm);
	}
	
	
	static class ViewContainer {
		
		public TextView mTitle;
		public TextView mTimestamp;
		public TextView mWeight;
		public TextView mUnit;
	}


	@Override
	public int getCount() {
		
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}
}
