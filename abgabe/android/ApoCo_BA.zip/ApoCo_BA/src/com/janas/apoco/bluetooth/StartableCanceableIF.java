package com.janas.apoco.bluetooth;

public interface StartableCanceableIF {
	
	public void performStart();
	public void cancel();

}
