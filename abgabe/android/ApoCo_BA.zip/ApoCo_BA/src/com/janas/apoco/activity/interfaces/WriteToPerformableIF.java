package com.janas.apoco.activity.interfaces;

public interface WriteToPerformableIF {
	
	public void performWriteTo(String msg);
	public void performWriteTo(byte[] msg);
}
