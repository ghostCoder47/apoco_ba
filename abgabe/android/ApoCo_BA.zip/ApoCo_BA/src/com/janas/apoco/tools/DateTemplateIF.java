package com.janas.apoco.tools;

public interface DateTemplateIF {

	public static final String TIMESTAMP_TEMPLATE = "dd.MM.yyyy HH:mm";
	public static final String DATE_OF_DAY_TEMPLATE = "yyyy-MM-dd";
}
