package com.janas.apoco.activity.interfaces;

public interface ActivityExtrasCodesIF {
	
	public static final String KCAL_RESULT 			= "kcal_result";
	public static final String VERBRAUCH			= "verbrauch";
	public static final String EXTRA_DEVICE_ADDRESS	= "device_address";
	public static final String USER 				= "user";
	public static final String TAGESEINHEITEN		= "tageseinheiten";
	public static final String GESAMMTENERGIE		= "gesammtenergie";
	public static final String MEAL_ID				= "meal_id";
	public static final String FOOD					= "food";
	public static final String MEAL_MODEL			= "meal_model";

}
