package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityFoodKcal;
import com.janas.apoco.activity.ActivityFoodKcalNewEntry;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.TageseinheitenDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.URLBuilder;

public class GetFood extends AsyncTask<String, Void, Boolean> {

	public static final String CLAZZ_NAME = GetFood.class.getSimpleName();
	
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private DBManagerLocal mDBManager;
	private FoodDTO mFood;
	private boolean isNetworkConnected;
	
	public GetFood(Context context, Handler netHandler,  Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = netHandler;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("Produkt wird gesucht...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
		mDBManager = new DBManagerLocal(mContext);
	}

	
	@Override
	protected Boolean doInBackground(String... pBarcode) {
		
		boolean result = false;
		String barcode = pBarcode[0];
		//intern
		mFood = mDBManager.getFood(barcode);
		if (null != mFood) {
			
			Log.d(CLAZZ_NAME, "food found: " + mFood.toString());
			return true;
		}
		
		//netzwerk verfügbarkeit prüfen
		isNetworkConnected = new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet);		
		if (!isNetworkConnected) return false;
		
		JSONObject ean = new JSONObject();
		try {
			
			ean.put("EAN", barcode);
		} catch (JSONException e) {
			
			return false;			
		}
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(JSON_TAG_IF.BARCODE, ean.toString()));
				
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.PRODUCT_DATA);		
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);		
		
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
								
				JSONObject obj = jsonObject.getJSONObject(JSON_TAG_IF.ENERGIE);
				mFood = new FoodDTO(obj);					
				mDBManager.insertFood(mFood);
				Log.d(CLAZZ_NAME, "food inserted: " + mFood.toString());
				result = true;
				
			} else {	
				
				result = false;
			}
			Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
				
		
		return result;
	}
	

	@Override
	protected void onPostExecute(Boolean result) {
		
		if (result) {
			
			mHandlerAct.obtainMessage(ActivityFoodKcalNewEntry.FOOD_SUCCESS, mFood).sendToTarget();
		} else if (!isNetworkConnected) {
			
			String msg = "Kann Produkt nicht finden, keine Netzwerkverbindung";
			mHandlerAct.obtainMessage(ActivityFoodKcalNewEntry.FOOD_FAILED, msg).sendToTarget();
		} else {
			
			String msg = "Produkt wurde nicht gefunden";
			mHandlerAct.obtainMessage(ActivityFoodKcalNewEntry.FOOD_FAILED, msg).sendToTarget();
		}
		
		
		progressDialog.dismiss();
	}		

}
