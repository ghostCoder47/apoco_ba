package com.janas.apoco.database.local.dto;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.database.local.tbl.TageseinheitenTbl;
import com.janas.apoco.tools.TimeTools;

public class TageseinheitenDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = TageseinheitenDTO.class.getSimpleName();
	
	
	public long _id;
	public long u_id;
	public Timestamp added_on;
	public int tageseinheiten;
	
	
	public TageseinheitenDTO(UserDTO user, JSONObject obj) throws JSONException {
		
		this.u_id = user.get_id();
		this.added_on = Timestamp.valueOf((obj.getString(TageseinheitenTbl.ADDED_ON)));
		this.tageseinheiten = obj.getInt(TageseinheitenTbl.TAGESEINHEITEN);
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public TageseinheitenDTO(long id, long u_id, long added_on, int tageseinheiten) {
		
		this._id = id;
		this.u_id = u_id;
		this.added_on = new Timestamp(added_on); //new TimeTools().convertLongTimeToStringTime(added_on);
		this.tageseinheiten = tageseinheiten;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public TageseinheitenDTO(Cursor cursor) {
		
		int idxID 				= cursor.getColumnIndex(TageseinheitenTbl._ID);
		int idxU_id				= cursor.getColumnIndex(TageseinheitenTbl.U_ID);
		int idxAdded_on 		= cursor.getColumnIndex(TageseinheitenTbl.ADDED_ON);
		int idxTageseinheiten 	= cursor.getColumnIndex(TageseinheitenTbl.TAGESEINHEITEN);
		
		
		this._id 			= cursor.getLong(idxID);
		this.u_id 			= cursor.getLong(idxU_id);
		this.added_on		= new Timestamp(cursor.getLong(idxAdded_on));
		this.tageseinheiten	= cursor.getInt(idxTageseinheiten);
		cursor.close();
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public long getU_id() {
		return u_id;
	}


	public void setU_id(long u_id) {
		this.u_id = u_id;
	}


	public Timestamp getAdded_on() {
		return added_on;
	}


	public void setAdded_on(Timestamp added_on) {
		this.added_on = added_on;
	}


	public int getTageseinheiten() {
		return tageseinheiten;
	}


	public void setTageseinheiten(int tageseinheiten) {
		this.tageseinheiten = tageseinheiten;
	}


	@Override
	public String toString() {
		return "TageseinheitenDTO [_id=" + _id + ", u_id=" + u_id
				+ ", added_on=" + added_on + ", tageseinheiten="
				+ tageseinheiten + "]";
	}
	
	
	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(TageseinheitenTbl._ID, this._id);
			obj.put(TageseinheitenTbl.U_ID, this.u_id);
			obj.put(TageseinheitenTbl.ADDED_ON, this.added_on);
			obj.put(TageseinheitenTbl.TAGESEINHEITEN, this.tageseinheiten);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}

}
