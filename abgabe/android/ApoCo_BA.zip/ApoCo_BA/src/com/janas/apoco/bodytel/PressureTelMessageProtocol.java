package com.janas.apoco.bodytel;


public interface PressureTelMessageProtocol {
	
	public static final byte[] IDENT_PACKET = "ATE0\r".getBytes();
	public static final byte[] IDENT_ACK = "\r\nOK\r\n".getBytes();
	public static final byte[] SMS_HEAD = "AT+CMGS=".getBytes();
	public static final byte[] END_OF_SMS = "FF".getBytes();
	public static final byte[] END_OF_SMS_ACK = "\r\n+CMGS:".getBytes();
}
