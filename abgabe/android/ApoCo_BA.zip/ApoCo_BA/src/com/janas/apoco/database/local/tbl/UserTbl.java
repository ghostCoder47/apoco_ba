package com.janas.apoco.database.local.tbl;


import com.janas.apoco.database.local.columns.UserColumns;

public final class UserTbl implements UserColumns {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public static final String TABLE_NAME = "user";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 		" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				VORNAME + 	" TEXT NOT NULL," + 
				NACHNAME + 	" TEXT NOT NULL," + 
				EMAIL + 	" TEXT NOT NULL," + 
				PASSWORD + 	" TEXT NOT NULL" + 
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_INSERT_USER = 

			"INSERT INTO " + TABLE_NAME + " (" +
					VORNAME + "," + 
					NACHNAME + "," +
					EMAIL + "," +
					PASSWORD + ")" +
					"VALUES (?,?,?,?)";
	
	
	public static final String STMT_USER_BY_EMAIL =
			
			"SELECT * FROM " + TABLE_NAME +
			" WHERE " + EMAIL + " = ?";


	
}
