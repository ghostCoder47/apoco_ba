package com.janas.apoco.bodytel;


import android.util.Log;

public final class WeightTelMeasurementDecoder {
	
	
	private static final String CLAZZ_NAME = WeightTelMeasurementDecoder.class.getSimpleName();
	private static final boolean DEBUG = true;	
	
	
	public BodyweightResult decodeMeasurement(String pHexString) {		
		
		WeightTelSMS sms = null;
		try {
			
			sms = new WeightTelSMS(pHexString);
		} catch (IndexOutOfBoundsException e) {
			
			Log.d(CLAZZ_NAME, "OUT OF INDEX WHYLE DECODING SMS: " + e.getMessage());
		}
		
		BodyweightResult result = new BodyweightResult(sms.getWeightValue(), sms.getAsciWeightUnit());
		return result;

	}

}
