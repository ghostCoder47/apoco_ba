package com.janas.apoco.bluetooth;

import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.interfaces.AccessableCreatorIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;


public class BluetoothManager {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = BluetoothManager.class.getSimpleName();
	
	
	private volatile BluetoothAdapter mBTAdapter;
	private volatile StartableCanceableIF mAcceptThread;
	private volatile PairingThread mPairingThread;
	private int mState;
	
	
	public BluetoothManager() {
		
		mBTAdapter = BluetoothAdapter.getDefaultAdapter();
		mState = BluetoothStateIF.STATE_NONE;
	}
	
	
	
	
	//// not used /////
	private synchronized void setState(int state) {
        
        mState = state;
    }
 
    
    public synchronized int getState() {
    	
        return mState;
    }
	    
	
	public void stopDiscovery() {
		
		mBTAdapter.cancelDiscovery();	
	}
	
	
	public void performDisableBluetooth() {
		
		mBTAdapter.disable();
	}
	
	
	public void performEnableBluetooth() {
		
		mBTAdapter.enable();
	}
	
	
	public boolean isBluetoothAvailable() {
		
		return null != mBTAdapter ? true : false;
	}
	
	
	public boolean isEnabled() {
		
		if (null != mBTAdapter) {
			
			return mBTAdapter.isEnabled();
		}
		return false;
	}
	
	
	public Intent enableBluetooth() {
		
		return new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);					
	} 
	
	
	public void disableBluetooth() {
		
		if (null != mBTAdapter) {
			
			this.mBTAdapter.disable();
		}
	}
	
	
	public void listenForInquiryConnections(Handler pHandler, AccessableCreatorIF pCreator, UUID pUUID, String pSDPServiceName) {

		Log.d(CLAZZ_NAME, "listenForInquiryConnections");
		mAcceptThread = new AcceptThread(pHandler, mBTAdapter, pCreator, pUUID, pSDPServiceName);
		mAcceptThread.performStart();
	}
	
	
	public void connect(String address, Handler pHandler, AccessableCreatorIF pCreator, UUID pUUID)  {
		
		onStop();
		
		BluetoothDevice device = mBTAdapter.getRemoteDevice(address);		
		mAcceptThread = new ConnectingThread(device, pUUID, this, pHandler, pCreator);
		mAcceptThread.performStart();
	}
	
	
	public synchronized void onStop() {
		
		if (null != mAcceptThread) {
			
			mAcceptThread.cancel();
		}
		
		if (null != mPairingThread) {
			
			mPairingThread.cancel();
		}
	}
	
	
	public void paringAsServer(Activity pContext) {
		
		if (mBTAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE ) {			
			
			Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);
			pContext.startActivityForResult(discoverableIntent, ActivityRequestCodesIF.REQUEST_BT_DISCOVERABLE);
			return;
		}
	}
	
	
	public void startListening() {
		
		mPairingThread = new PairingThread(StandardUUIDsIF.SPP_1101, mBTAdapter);		
		mPairingThread.performStart();
	}
	
	
	public void paringAsClient(BluetoothDevice pDevice) {
		
	}
	
	
	public BluetoothDevice getRemotedDevice(String address) throws IllegalArgumentException {
		
		return mBTAdapter.getRemoteDevice(address);
	}
	
	
}
