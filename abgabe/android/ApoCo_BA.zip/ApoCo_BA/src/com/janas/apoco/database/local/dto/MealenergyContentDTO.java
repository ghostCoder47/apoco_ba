package com.janas.apoco.database.local.dto;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.database.local.tbl.MealenergyContentTbl;
import com.janas.apoco.generic.KcalResult;


public class MealenergyContentDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = MealenergyContentDTO.class.getSimpleName();
	
	
	public long _id;
	public long meal_id;
	public String barcode;
	public int energie_kcal;
	public double weight;
	public int sync;
	
	
	public MealenergyContentDTO(KcalResult result, MealenergyDTO meal) {
		
		this.meal_id = meal._id;
		this.barcode = result.getBarcode();
		this.energie_kcal = Integer.parseInt(result.getmEnergie());
		this.weight = Double.parseDouble(result.getmGewicht());
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public MealenergyContentDTO(long id, long meal_id, String barcode, int energie_kcal, double weight, int sync) {
		
		this._id = id;
		this.meal_id = meal_id;
		this.barcode = barcode;
		this.energie_kcal = energie_kcal;
		this.weight = weight;
		this.sync = sync;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public MealenergyContentDTO(Cursor cursor) {
		
		int idxID 			= cursor.getColumnIndex(MealenergyContentTbl._ID);
		int idxMeal_id		= cursor.getColumnIndex(MealenergyContentTbl.MEAL_ID);
		int idxBarcode 		= cursor.getColumnIndex(MealenergyContentTbl.BARCODE);
		int idxEnergie_kcal	= cursor.getColumnIndex(MealenergyContentTbl.ENERGIE_KCAL);
		int idxWeight		= cursor.getColumnIndex(MealenergyContentTbl.WEIGHT);
		int idxSync			= cursor.getColumnIndex(MealenergyContentTbl.SYNC);
		
		this._id 			= cursor.getLong(idxID);
		this.meal_id 		= cursor.getLong(idxMeal_id);
		this.barcode		= cursor.getString(idxBarcode);
		this.energie_kcal	= cursor.getInt(idxEnergie_kcal);
		this.weight 		= cursor.getDouble(idxWeight);
		this.sync			= cursor.getInt(idxSync);
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public long getMeal_id() {
		return meal_id;
	}


	public void setMeal_id(long meal_id) {
		this.meal_id = meal_id;
	}


	public String getBarcode() {
		return barcode;
	}


	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}


	public int getEnergie_kcal() {
		return energie_kcal;
	}


	public void setEnergie_kcal(int energie_kcal) {
		this.energie_kcal = energie_kcal;
	}


	public double getWeight() {
		return weight;
	}


	public void setWeight(double weight) {
		this.weight = weight;
	}


	public int getSync() {
		return sync;
	}


	public void setSync(int sync) {
		this.sync = sync;
	}


	@Override
	public String toString() {
		return "MealenergyContentDTO [_id=" + _id + ", meal_id=" + meal_id
				+ ", barcode=" + barcode + ", energie_kcal=" + energie_kcal
				+ ", weight=" + weight + ", sync=" + sync + "]";
	}
	
	
	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(MealenergyContentTbl._ID, this._id);
			obj.put(MealenergyContentTbl.MEAL_ID, this.meal_id);
			obj.put(MealenergyContentTbl.BARCODE, this.barcode);
			obj.put(MealenergyContentTbl.ENERGIE_KCAL, this.energie_kcal);
			obj.put(MealenergyContentTbl.WEIGHT, this.weight);
			obj.put(MealenergyContentTbl.SYNC, this.sync);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}
	
	
}
