package com.janas.apoco.bodytel;

import com.janas.apoco.tools.HexConverter;

public final class WeightTelMessageProtocol {		
		 
	public static final String IDENT_PACKET = "300301";
	public static final byte[] IDENT_ACK = HexConverter.hexStringToByteArray("553000");
	public static final int IDENT_LENGTH = 4;
	public static final String SINGLE_MEASUREMENT_RESULT = "44";
	public static final byte[] MEASUREMENT_RESULT_ACK = HexConverter.hexStringToByteArray("554400");
	public static final int MEASUREMENT_LENGTH = 28;
	public static final String ANY_NEW_DATA = "20";
	public static final byte[] REQUEST_DEVICES_FIRMWARE = HexConverter.hexStringToByteArray("83");
	public static final int NEW_DATA_REQUEST_LENGTH = 1;
	public static final String DEVICES_FIRMWARE = "43";
	public static final byte[] DEVICES_FIRMWARE_ACK = HexConverter.hexStringToByteArray("554300");
	public static final int DEVICES_FIRMWARE_LENGTH = 18;
	public static final byte[] NO_NEW_DATA = HexConverter.hexStringToByteArray("10");	
	public static final String CLOSE = "636c6f736520300a";
	public static final int CLOSE_LENGTH = 11;
	public static final String SUCCESS = "551000";
	public static final int SUCCESS_LENGTH = 3;
	
}