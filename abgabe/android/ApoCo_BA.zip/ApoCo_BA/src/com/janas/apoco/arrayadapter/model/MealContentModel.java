package com.janas.apoco.arrayadapter.model;


import java.io.Serializable;

import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.generic.KcalResult;

public class MealContentModel implements Serializable{
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String CLAZZ_NAME = MealContentModel.class.getSimpleName();
	
	
	public String barcode;
	public String produkt;
	public String marke;
	public String gewicht;
	public String energie;	
	
	
	public MealContentModel(){}
	
	
	public MealContentModel(MealenergyContentDTO mc, FoodDTO food) {
		
		barcode = food.getBarcode();
		produkt = food.getProdukt();
		marke 	= food.getMarkenname();
		gewicht = Double.toString(mc.getWeight());
		energie = Integer.toString(mc.getEnergie_kcal());
	}
	
	
	public static MealContentModel convertResult_to_MODEL(KcalResult result) {
		
		MealContentModel mcm = new MealContentModel();
		
		mcm.barcode = result.getBarcode();
		mcm.produkt = result.getmProdukt();
		mcm.marke	= result.getmMarke();
		mcm.gewicht = result.getmGewicht();
		mcm.energie = result.getmEnergie();
		
		return mcm;
	}
	

}
