package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityBloodpressure;
import com.janas.apoco.activity.ActivityFoodKcal;
import com.janas.apoco.activity.ActivityMealenergy;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.database.local.dto.MealenergyDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.tools.URLBuilder;

public class SynchronizeMealenergy extends AsyncTask<UserDTO, Void, Boolean> {
	
	
public static final String CLAZZ_NAME = SynchronizeMealenergy.class.getSimpleName();
	
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	private boolean isNetworkConnected;
	
	
	public SynchronizeMealenergy(Context context, Handler handlerNet, Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = handlerNet;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("synchronisiere Daten auf Server...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
		mDBManager = new DBManagerLocal(mContext);
	}

	
	@Override
	protected Boolean doInBackground(UserDTO... pUser) {
		
		//netzwerk verfügbarkeit prüfen
		isNetworkConnected = new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet);		
		if (!isNetworkConnected) return false;
		
		
		boolean result = false;		
		mUser = pUser[0];
		
		if (null == mUser) {
			
		}
		
		JSONObject user 	= mUser.toJSONObject();			
		JSONArray payload 	= new JSONArray();
		JSONArray mealAr		= new JSONArray();
		JSONArray contentAr	= new JSONArray();
		
		try {
			
			Cursor cursor = mDBManager.synchronizeMealenergy(mUser);
			//prüfung: muss was synchronisiert werden
			if (cursor.getCount() == 0) {
				
				mDBManager.closeDB();
				return true;	
			}
			
			while (cursor.moveToNext()) {
		
				MealenergyDTO mealdto = new MealenergyDTO(cursor);
				mealAr.put(cursor.getPosition(), mealdto.toJSONObject());
				
				JSONArray content 	= new JSONArray();
				Cursor mealContent = mDBManager.mealenergyContent(mealdto._id);
				while (mealContent.moveToNext()) {
					
					MealenergyContentDTO mcdto = new MealenergyContentDTO(mealContent);
					content.put(mealContent.getPosition(), mcdto.toJSONObject());
				}
				contentAr.put(cursor.getPosition(), content);				
			}
			cursor.close();
			
			payload.put(0, mealAr);
			payload.put(1, contentAr);
			
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "error while put payload: " + e.getMessage());
		}
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(JSON_TAG_IF.USER, user.toString()));
		params.add(new BasicNameValuePair(JSON_TAG_IF.PAYLOAD, payload.toString()));
				
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.INSERT_MEALENERGY);
		
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);		
		
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
				
				JSONObject sync = jsonObject.getJSONObject(JSON_TAG_IF.SYNC);
				JSONArray meal = sync.getJSONArray(JSON_TAG_IF.MEAL);
				JSONArray content = sync.getJSONArray(JSON_TAG_IF.CONTENT);
				
				int index = 0, mealids[] = new int[meal.length()];
								
				while (index < meal.length()) {
					
					int id = meal.getInt(index);
					mealids[index] = id;
					
					index++;
				}
				
				mDBManager.confirmMealenergy(mealids);
				
				index = 0;
				int contentids[] = new int[content.length()];
								
				while (index <content.length()) {
					
					int id = content.getInt(index);
					contentids[index] = id;
										
					index++;
				}
				
				mDBManager.confirmMealenergyContent(contentids);

				result = true;
				
			} else {
				
				result = false;
				
			}
			Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
		
		mDBManager.closeDB();
		return result;
	}
	

	@Override
	protected void onPostExecute(Boolean result) {
		
		if (!result) {
			
			if (!isNetworkConnected) return;
			
			if (null != jsonObject) {
				
				try {
					
					AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
					builder.setTitle("Mealenergy sync");
					builder.setMessage(jsonObject.getString(JSON_TAG_IF.MESSAGE));
					builder.setPositiveButton("OK",new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int whichButton) {

							mHandlerAct.obtainMessage(ActivityFoodKcal.SYNCHRONIZING_DATA_FAILED).sendToTarget();
						}
						
						
					});
					builder.create().show();
					
				} catch (JSONException e) {
					
					Log.d(CLAZZ_NAME, e.getMessage());
				}
				
			} else {
			
				String msg = "Bloodpressure Synchronisierung fehlgeschlagen";
				Toasting.inScreenCenter(mContext, msg);
				mHandlerAct.obtainMessage(ActivityFoodKcal.SYNCHRONIZING_DATA_FAILED).sendToTarget();
			}
			
		} else {
			
			mHandlerAct.obtainMessage(ActivityFoodKcal.SYNCHRONIZING_DATA_COMPLETE).sendToTarget();
		}
		progressDialog.dismiss();
	}		

}
