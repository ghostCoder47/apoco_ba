package com.janas.apoco.tools;

import android.content.Context;
import android.content.res.Resources;


public class ResourcesTools {
	
	
	public String getString(Context activity, int id) {
		
		Resources res = activity.getResources();
		String text = res.getString(id);
		return text;
	}

}
