package com.janas.apoco.database.local.dto;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.database.local.tbl.FoodTbl;
import com.janas.apoco.tools.JSONParser;

public class FoodDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = FoodDTO.class.getSimpleName();
	
	
	public long _id;
	public String barcode;
	public String markenname;
	public String produkt;
	public int energie_p100g;
	
	
	public FoodDTO(JSONObject obj) throws JSONException {
		
		this.barcode 		= obj.getString("EAN");
		this.markenname 	= obj.getString(FoodTbl.MARKENNAME);
		this.produkt 		= obj.getString(FoodTbl.PRODUKT);
		this.energie_p100g 	= obj.getInt("menge");
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public FoodDTO(long id, String barcode, String markenname, String produkt, int energie_p100g) {
		
		this._id = id;
		this.barcode = barcode;
		this.markenname = markenname;
		this.produkt = produkt;
		this.energie_p100g = energie_p100g;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public FoodDTO(Cursor cursor) {
		
		int idxID 				= cursor.getColumnIndex(FoodTbl._ID);
		int idxBarcode			= cursor.getColumnIndex(FoodTbl.BARCODE);
		int idxMarkenname 		= cursor.getColumnIndex(FoodTbl.MARKENNAME);
		int idxProdukt		 	= cursor.getColumnIndex(FoodTbl.PRODUKT);
		int idxEnergie_p100g	= cursor.getColumnIndex(FoodTbl.ENERGIE_P100G);
		
		this._id 			= cursor.getLong(idxID);
		this.barcode 		= cursor.getString(idxBarcode);
		this.markenname		= cursor.getString(idxMarkenname);
		this.produkt		= cursor.getString(idxProdukt);
		this.energie_p100g	= cursor.getInt(idxEnergie_p100g);
		
		cursor.close();
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public String getBarcode() {
		return barcode;
	}


	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}


	public String getMarkenname() {
		return markenname;
	}


	public void setMarkenname(String markenname) {
		this.markenname = markenname;
	}


	public String getProdukt() {
		return produkt;
	}


	public void setProdukt(String produkt) {
		this.produkt = produkt;
	}


	public int getEnergie_p100g() {
		return energie_p100g;
	}


	public void setEnergie_p100g(int energie_p100g) {
		this.energie_p100g = energie_p100g;
	}


	@Override
	public String toString() {
		return "FoodDTO [_id=" + _id + ", barcode=" + barcode + ", markenname="
				+ markenname + ", produkt=" + produkt + ", energie_p100g="
				+ energie_p100g + "]";
	}
	
	
	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(FoodTbl._ID, this._id);
			obj.put(FoodTbl.BARCODE, this.barcode);
			obj.put(FoodTbl.MARKENNAME, this.markenname);
			obj.put(FoodTbl.PRODUKT, this.produkt);
			obj.put(FoodTbl.ENERGIE_P100G, this.energie_p100g);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}

}
