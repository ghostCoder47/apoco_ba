package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.TageseinheitenColumns;
import com.janas.apoco.database.local.columns.UserColumns;

public class TageseinheitenTbl implements TageseinheitenColumns {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = TageseinheitenTbl.class.getSimpleName();
	public static final int DEFAULT_TAGESEINHEITEN = 2200;
	public static final String TABLE_NAME = "tageseinheiten";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 		" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				U_ID + 		" INTEGER NOT NULL," + 
				ADDED_ON + 	" TIMESTAMP NOT NULL DEFAULT current_timestamp," + 
				TAGESEINHEITEN + " INTEGER NOT NULL DEFAULT 0," +
				"FOREIGN KEY(" + U_ID + ") REFERENCES " + UserTbl.TABLE_NAME + "(" + UserColumns._ID + ")" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;

	
	public static final String STMT_INSERT_TAGESEINHEITEN = 
			
			"INSERT INTO " + TABLE_NAME + "(" +
					U_ID + "," + 
					ADDED_ON + "," +
					TAGESEINHEITEN + ")" + 
					"VALUES (?,?,?)";
	
	
	public static final String STMT_CURRENT_TAGESEINHEITEN = 
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + ADDED_ON + " = (" + 
					"SELECT MAX(" + ADDED_ON + ")" + 
					" FROM " + TABLE_NAME + 
					" WHERE " + U_ID + "=?)";
			
	

}
