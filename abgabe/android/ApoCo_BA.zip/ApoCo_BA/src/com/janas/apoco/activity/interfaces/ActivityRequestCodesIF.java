package com.janas.apoco.activity.interfaces;

public interface ActivityRequestCodesIF {
	

	public static final int WHO_IS_CALLER_ACTIVITY 	= 0xff0001;
	public static final int REQUEST_BT_ENABLE 		= 0xff0002;
	public static final int REQUEST_BT_DISCOVERABLE = 0xff0003;
	public static final int REQUEST_NEW_KCAL_ENTRY 	= 0xff0004;
	public static final int REQUEST_CONNECT_DEVICE	= 0xff0005;
	public static final int REQUEST_NEW_MEAL		= 0xff0006;
	
}
