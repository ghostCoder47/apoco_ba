package com.janas.apoco.bluetooth;

public interface HandlerMessagesIF {

	
	//bluetooth
	public static final int READ 						= 0xff0001;
	public static final int WRITE 						= 0xff0002;
	public static final int GET_NEEDED_DATA				= 0xff0003;
	public static final int MEASUREMENT_FINISH 			= 0xff0004;
	public static final int RECEIVING_ACCESSABLE		= 0xff0005;
	public static final int RECEIVING_CONNECTED_TASK 	= 0xff0006;
	public static final int BODY_WEIGHT_VALUE			= 0xff0007;
	public static final int BLOOD_PRESSURE_VALUE		= 0xff0008;
	public static final int INTERRUPTED_BY_EXCEPTION	= 0xff0009;
	public static final int CONNECTED_TO				= 0xff0010;
	public static final int CONNECTING					= 0xff0011;
	
	
	//network
	public static final int NETWORK_NOT_AVAILABLE			= 0xfff000;
	public static final int WIFI_STATE_CONNECTED			= 0xfff001;
	public static final int SERVER_NOT_REACHABLE			= 0xfff002;
	public static final int NO_SERVER_RESPONSE_200			= 0xfff003;
	public static final int NETWORK_DISCONNECTED			= 0xfff004;
	public static final int SERVER_RESPONDING_200_SUCCESS 	= 0xfff005;
	public static final int URL_CONNECTION_ERROR			= 0xfff006;
}
