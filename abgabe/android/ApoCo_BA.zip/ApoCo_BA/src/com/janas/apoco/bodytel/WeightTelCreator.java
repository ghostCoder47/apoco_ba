package com.janas.apoco.bodytel;

import java.io.IOException;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.interfaces.AccessableCreatorIF;
import com.janas.apoco.bluetooth.AccessableIF;

public class WeightTelCreator implements AccessableCreatorIF {

	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = WeightTelCreator.class.getSimpleName();
	
	
	@Override
	public AccessableIF createAccessable(Handler pHandler, BluetoothSocket pSocket) {
		
		WeightTelConnectedThread connectedTask = null;
		try {
			
			connectedTask = new WeightTelConnectedThread(pHandler, pSocket);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		if (DEBUG) Log.d(CLAZZ_NAME, "accessable created");
		return connectedTask;
	}

}
