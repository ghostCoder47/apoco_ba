package com.janas.apoco.database.local.columns;

public interface FoodColumns {
	
	
	public static final String _ID 				= "_id";
	public static final String BARCODE 			= "barcode";
	public static final String MARKENNAME 		= "markenname";
	public static final String PRODUKT 			= "produkt";
	public static final String ENERGIE_P100G 	= "energie_p100g";

}
