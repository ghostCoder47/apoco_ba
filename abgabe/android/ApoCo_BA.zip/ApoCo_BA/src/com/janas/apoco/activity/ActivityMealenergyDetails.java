package com.janas.apoco.activity;

import java.util.ArrayList;
import java.util.LinkedList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.widget.ListView;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.arrayadapter.MealContentAdapter;
import com.janas.apoco.arrayadapter.model.MealContentModel;

public class ActivityMealenergyDetails extends Activity {
	
	
	private long meal_id;
	private ArrayList<MealContentModel> mMealContentList;
	private MealContentAdapter mMealenergyContentAdapter;	
	private ListView mMealenergyContentLV;	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_mealenergy_details);
		

		setupMealContentList();
		setupMealenergyAdapter();
		setupMealenergyContentLV();
		initList();
	
		
	}
	
	
	private void setupMealContentList() {
		
		mMealContentList = new ArrayList<MealContentModel>();
	}


	private void setupMealenergyAdapter() {
		
		mMealenergyContentAdapter = new MealContentAdapter(ActivityMealenergyDetails.this, mMealContentList);
	}


	private void setupMealenergyContentLV() {
		
		mMealenergyContentLV = (ListView) findViewById(R.id.mealenergy_contentListView);
		mMealenergyContentLV.setAdapter(mMealenergyContentAdapter);
	}

	
	@Override
	public void onDestroy() {
		
		super.onDestroy();
	}
	
	
	private void initList() {
		
		Object obj = getIntent().getSerializableExtra(ActivityExtrasCodesIF.MEAL_MODEL);		
		if (obj instanceof ArrayList) {
			
			ArrayList<MealContentModel> modelList =  (ArrayList) obj;
			for (MealContentModel model : modelList) {
			
				mMealenergyContentAdapter.add(model);
			}
		}
	}
	
	
	@Override
	public void onBackPressed() {

		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
}
