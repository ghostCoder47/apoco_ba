package com.janas.apoco.activity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.database.local.dto.UserDTO;

public class ActivitySummary extends Activity {

	
	public static final String CLAZZ_NAME = ActivitySummary.class.getSimpleName();
	
	
	private UserDTO mUser;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_start);
		
		setupUser();
		
	}
	
	
	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}

	
	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
}
