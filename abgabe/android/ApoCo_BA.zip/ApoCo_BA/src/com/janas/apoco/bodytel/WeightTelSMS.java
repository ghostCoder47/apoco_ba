package com.janas.apoco.bodytel;

import android.util.Log;

public class WeightTelSMS {
	

	public static final String CLAZZ_NAME = WeightTelSMS.class.getSimpleName();
	/* die indexe mit 2 multiplizieren da im string für ein hex wert
	 * immer zwei stellen gebraucht werden
	 
			0:       Measurement packet start byte (= 0x44)
		1 - 5:   <Unused>
		6 - 7:   Measurement count. Always 0x00 0x01 (= 1)
		8 - 9:   Weight value times 10. 0x03 0x45 (= 837) is 83,7 kg
		10 - 25: <Unused>
		26:      Error code. Unused?
		27:      Weight unit. 0x00 (= kg) or 0x01 (= lbs)
	*/
	public static final int RADIX_HEX = 16;
	
	
	private String OxStartByte; 
	private String OxMeasurementCount;
	private int decMeasurementCount;
	private String OxWeightValue;
	private double dblWeightValue;
	private String OxErrorCode;
	private int decErrorCode;
	private String OxWeightUnit;
	private String asciWeightUnit;
	
	
	public WeightTelSMS(String hexSMS) throws IndexOutOfBoundsException {
		
		OxStartByte = hexSMS.substring(0, 2);
		OxMeasurementCount = hexSMS.substring(12, 16);
		decMeasurementCount = Integer.valueOf(OxMeasurementCount, RADIX_HEX);
		OxWeightValue	 = hexSMS.substring(16, 20);
		dblWeightValue	= decodeWeightValueFromHexString(OxWeightValue);
		OxErrorCode	= hexSMS.substring(52, 54);
		decErrorCode = Integer.valueOf(OxErrorCode, RADIX_HEX);
		OxWeightUnit = hexSMS.substring(54, 56);
		asciWeightUnit = decodeUnitToAsci(OxWeightUnit);
		
	}
	
	
	public double getWeightValue() {
		
		return dblWeightValue;
	}
	
	
	public String getAsciWeightUnit() {
		
		return asciWeightUnit;
	}
	
	
	public double decodeWeightValueFromHexString(String hexString) {
		
		Log.d(CLAZZ_NAME, "WEIGHT hex:" + hexString);
		StringBuilder weightValue = new StringBuilder();
		int i = 2;
		while (i>=0) {
			
			weightValue.append(hexString.substring(i, i+2));
			i-=2;
		}
		
		double weight = Integer.valueOf(weightValue.toString(), RADIX_HEX) / 10D;
		Log.d(CLAZZ_NAME, "WEIGHT dec:" + weight);
		return weight;
	}
	
	
	public String decodeUnitToAsci(String hexString) {
		
		int unit = Integer.valueOf(hexString, RADIX_HEX);
		String result = null;
		switch(unit) {
		
		case 0:
			
			result = "kg";
			break;
			
			
		case 1:
			
			result = "lbs";
			break;
		
		}
		return result;
	}

}
