package com.janas.apoco.activity.interfaces;

public interface MessageDisplayableIF {

	public void displayMessage(String pMessage);
}
