package com.janas.apoco.activity;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.layout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Window;

public class ActivitySplashscreen extends Activity {
	
	
	private static final int SPLASH_END = 0;
	private static final int SPLASH_DURATION = 1000;	
	
	private Handler mSplashHandler = new Handler() {
		
		@Override
		public void handleMessage(Message pMsg) {
			
			switch(pMsg.what) {
			
			case SPLASH_END:
				Intent LoginActivity = new Intent(getApplicationContext(), ActivityLogin.class);
				startActivity(LoginActivity);
				overridePendingTransition(0, R.anim.fade_out);
				break;
			}
			finish();
			
		}
	};
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.splash_screen);
		
		Message lMsg = new Message();
		lMsg.what = SPLASH_END;
		mSplashHandler.sendMessageDelayed(lMsg, SPLASH_DURATION);
	}

}
