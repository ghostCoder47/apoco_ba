package com.janas.apoco.kern;

import java.util.StringTokenizer;

import android.util.Log;

public final class KERN_PCB_MessageBuilder {
	
	
	public static final String CLAZZ_NAME = KERN_PCB_MessageBuilder.class.getSimpleName();
	
	
	private static KERN_PCB_MessageBuilder m_this = null;
	private StringBuilder mMessageBuilder;	
	private String mMessage;
	private boolean isMessageReady = false;
	
	
	private KERN_PCB_MessageBuilder(){
		
		setupMessageBuilder();
		Log.d(CLAZZ_NAME, "call CTOR");
	};
	
	
	private void setupMessageBuilder() {
		
		mMessageBuilder = new StringBuilder();
	}


	public static KERN_PCB_MessageBuilder getInstance() {
		
		if (null == m_this) {
			
			m_this = new KERN_PCB_MessageBuilder();
		}
		return m_this;
	}
	
	
	public void appendToMessage(byte[] msgPart) {
		
		mMessageBuilder.append(new String(msgPart));	
		String mb = mMessageBuilder.toString();
		Log.d(CLAZZ_NAME, "" + mb.contains("N")  +  mb.contains(":")  +  mb.contains("g"));
		if (mb.length() == 21) {
			
			synchronized(this) {
				String msg = mMessageBuilder.toString();
				StringTokenizer st = new StringTokenizer(msg, "N:g");
				String token = st.nextToken();
				mMessage = token.trim();	
				isMessageReady = true;		
				mMessageBuilder.delete(0, mMessageBuilder.length());
			}
		} else if (mb.length() > 21) {
			
			mMessageBuilder.delete(0, mMessageBuilder.length());
		} else isMessageReady = false;
	}
	
	
	public boolean isMessageReady() {
		
		return isMessageReady;
	}
	
	
	public synchronized String readMessage() {
		
		return mMessage;
	}
	

}
