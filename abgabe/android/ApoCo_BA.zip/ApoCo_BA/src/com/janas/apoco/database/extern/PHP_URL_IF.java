package com.janas.apoco.database.extern;

public interface PHP_URL_IF {
	
	
	public static final String REGISTER_USER 			= "register_user.php";
	public static final String PRODUCT_DATA 			= "product_data.php";
	public static final String CURRENT_TAGESEINHEITEN 	= "current_tageseinheiten.php";
	public static final String CURRENT_WUNSCHGEWICHT	= "current_wunschgewicht.php";
	public static final String INSERT_MEALENERGY 		= "insert_mealenergy.php";
	public static final String INSERT_BODYWEIGHT 		= "insert_bodyweight.php";
	public static final String INSERT_BLOODPRESSURE 	= "insert_bloodpressure.php";

}
