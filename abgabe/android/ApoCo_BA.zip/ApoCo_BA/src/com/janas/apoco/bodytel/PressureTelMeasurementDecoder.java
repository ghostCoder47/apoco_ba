package com.janas.apoco.bodytel;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import android.util.Log;

public class PressureTelMeasurementDecoder {
	
	
	private static final String CLAZZ_NAME = PressureTelMeasurementDecoder.class.getSimpleName();
	
	
	public List<BloodpressureResult> decodeMeasurement(String hexString) {
		
		PressureTelSMS sms = null;
		try {
			
			sms = new PressureTelSMS(hexString);
		} catch (IndexOutOfBoundsException e) {
			
			Log.d(CLAZZ_NAME, "OUT OF INDEX WHYLE DECODING SMS: " + e.getMessage());
			return null;
		}
		
		int numOfBlocks = sms.getNumberOfDataBlocks();
		List<BloodpressureResult> resultList = new LinkedList<BloodpressureResult>();
		List<String> dataBlockList = sms.parseDataBlocksToList();
		Iterator<String> dblIterator = dataBlockList.iterator();
		for (int i = 0; i<numOfBlocks; i++) {
			
			if (dblIterator.hasNext()) {
				
				resultList.add(new BloodpressureResult(dblIterator.next()));
			}
		}
		return resultList;
	}

}
