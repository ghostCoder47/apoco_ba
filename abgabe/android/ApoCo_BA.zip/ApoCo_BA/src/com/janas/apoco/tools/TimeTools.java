package com.janas.apoco.tools;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TimeTools {

	
	public String convertLongTimeToStringTime(long time) {
		
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(time);
		String format = "dd-MM-yyyy HH:mm";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(cal.getTime());
	}
	
	
	public long convertStringTimeToLongTime(String time) {
		
		
		
		    SimpleDateFormat formatter ; 
		    Date date = null; 
		    formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		    
		    try {
				date = (Date)formatter.parse(time);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		return date.getTime();
	}
}
