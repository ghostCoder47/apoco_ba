package com.janas.apoco.database.local.columns;

public interface BloodpressureColumns {
	
	
	public static final String _ID 			= "_id";
	public static final String U_ID 		= "u_id";
	public static final String ADDED_ON 	= "added_on";
	public static final String DIASTOLIC 	= "diastolic";
	public static final String SYSTOLIC 	= "systolic";
	public static final String PULSE 		= "pulse";
	public static final String SYNC 		= "sync";
	public static final String DEVICENAME	= "devicename";

}
