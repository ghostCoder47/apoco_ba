package com.janas.apoco.bodytel;

import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import android.util.Log;

public class PressureTelSMS {
	
	
	private static final String CLAZZ_NAME = PressureTelSMS.class.getSimpleName();
	
	public static final int DATA_HEADER_LENGTH = 13 * 2;
	public static final int SERIAL_NO_LENGTH = 8 * 2;
	public static final int SINGLE_DATA_BLOCK_LENGTH = 7 * 2;
	public static final int TIME_BYTES_LENGTH = 4 * 2;
	public static final int RADIX_HEX = 16;
	
	
	private int mIndex = 0;
	private int mStep = 2;
	
	private int 	decSMSOctates;
	private String 	OxSMSC_Length;
	private String 	OxTP_VP;
	private String 	OxTP_Reference;
	private String 	OxPhoneNumberLength;
	private int 	decPhoneNumerLengtht;
	private String 	OxAddressType;
	private String 	OxPhoneNumber;
	private String 	OxProtocolIdentifier;
	private String 	OxDataCodingScheme;
	private String 	OxValidityPeriod;
	private String 	OxDataLengthInOctates;
	private int 	decDataLengthInOctates;
	
	private String 	pureSMS;
	
	private String 	OxStartByte;
	private String 	OxDataBytes;
	private int 	decDataBytes;
	private String 	OxSerialNumber;
	private String 	OxSendingTime;
	private long	decSendingTimeConverted;
	private String 	OxNumberOfDataBlocks;
	private int 	decNumberOfDataBlocks;
	
	private String 	DataBlocks;
	private String 	OxEndByte;
	
	
	public PressureTelSMS(String hexSMS) throws IndexOutOfBoundsException {
		
		
		
		OxSMSC_Length 			= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxTP_VP 				= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxTP_Reference 			= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxPhoneNumberLength 	= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		decPhoneNumerLengtht 	= Integer.valueOf(OxPhoneNumberLength, RADIX_HEX) + 1;
		OxAddressType 			= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxPhoneNumber 			= hexSMS.substring(mIndex, mIndex + decPhoneNumerLengtht); 		mIndex += decPhoneNumerLengtht;
		OxProtocolIdentifier 	= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxDataCodingScheme 		= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxValidityPeriod 		= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		OxDataLengthInOctates 	= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;		
		decDataLengthInOctates 	= Integer.valueOf(OxDataLengthInOctates, RADIX_HEX);			
		
		pureSMS 				= hexSMS.substring(mIndex, mIndex + decDataLengthInOctates); 	//mIndex += mStep;
		
		OxStartByte 			= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;		
		OxDataBytes 			= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		decDataBytes 			= Integer.valueOf(OxDataBytes, RADIX_HEX);		
		
		OxSerialNumber 			= hexSMS.substring(mIndex, mIndex + SERIAL_NO_LENGTH); 			mIndex += SERIAL_NO_LENGTH;	
		OxSendingTime 			= hexSMS.substring(mIndex, mIndex + TIME_BYTES_LENGTH); 		mIndex += TIME_BYTES_LENGTH;		
		decSendingTimeConverted = secSince01011997(OxSendingTime);
		
		OxNumberOfDataBlocks 	= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		Log.d(CLAZZ_NAME, "sms hexblocks after read: " + OxNumberOfDataBlocks);
		decNumberOfDataBlocks 	= Integer.valueOf(OxNumberOfDataBlocks, RADIX_HEX);
		Log.d(CLAZZ_NAME, "sms decblocks after read: " + decNumberOfDataBlocks);
		if (decNumberOfDataBlocks >= 1)
			
			DataBlocks 				= hexSMS.substring(mIndex, mIndex + decNumberOfDataBlocks * SINGLE_DATA_BLOCK_LENGTH); 	mIndex += decNumberOfDataBlocks * SINGLE_DATA_BLOCK_LENGTH;

		OxEndByte 				= hexSMS.substring(mIndex, mIndex + mStep); 					mIndex += mStep;
		
	}
	
	
	public int getNumberOfDataBlocks() {
		
		return this.decNumberOfDataBlocks;
	}
	
	
	public String getDataBlocks() {
		
		if (decNumberOfDataBlocks != 0)
			return this.DataBlocks;
		else return "NO DATA";
	}
	
	
	public List<String> parseDataBlocksToList() {
		
		List<String> resultList = new LinkedList<String>();
		for (int i = 0; i<decNumberOfDataBlocks * SINGLE_DATA_BLOCK_LENGTH; i += SINGLE_DATA_BLOCK_LENGTH) {
			
			String dataBlock = DataBlocks.substring(i, i+SINGLE_DATA_BLOCK_LENGTH);
			resultList.add(dataBlock);
		}
		return resultList;
	}
	
	
	public static long secSince01011997(String revertHexTime) {
		
		Log.d(CLAZZ_NAME, "revertHexTime: " + revertHexTime);
		
		StringBuilder recordTime = new StringBuilder();
		int i = 6;
		while (i>=0) {
			
			recordTime.append(revertHexTime.substring(i, i+2));
			i-=2;
		}
		Log.d(CLAZZ_NAME, "forwardHexTime: " + recordTime);
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(1997, Calendar.JANUARY, 1, 0, 0, 0);
		
		long result = Long.valueOf(recordTime.toString(), RADIX_HEX) * 1000 + calendar.getTimeInMillis();	
		return result;
	}
	
}
