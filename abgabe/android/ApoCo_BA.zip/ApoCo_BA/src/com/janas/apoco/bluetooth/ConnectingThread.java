package com.janas.apoco.bluetooth;

import java.io.IOException;
import java.util.UUID;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.interfaces.AccessableCreatorIF;

public class ConnectingThread implements Runnable, StartableCanceableIF {

	
	private final boolean DEBUG = true;
	private final String CLAZZ_NAME = ConnectingThread.class.getSimpleName();
	
	
	private Thread mThread = null;
	private BluetoothDevice mDevice;
	private UUID mUUID;
	private BluetoothManager mBTManager;
	private Handler mHandler;
	private final BluetoothSocket mSocket;
	private AccessableCreatorIF mCreator;
	
	
	public ConnectingThread(BluetoothDevice device, UUID uuid, BluetoothManager btManager, Handler handler, AccessableCreatorIF pCreator) {
		
		mDevice = device;
		mUUID = uuid;
		mBTManager = btManager;
		mHandler = handler;
		mHandler.obtainMessage(HandlerMessagesIF.CONNECTING, "connecting").sendToTarget();
		mCreator = pCreator;
		BluetoothSocket tmpSocket = null;
		try {
			
			tmpSocket = mDevice.createRfcommSocketToServiceRecord(mUUID); //mBTManager.connectToDevice(mDevice, mUUID);			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		mSocket = tmpSocket;
	}
	
	
	@Override
	public void run() {
		
		mBTManager.stopDiscovery();
		
		try {
			// This is a blocking call and will only return on a
			// successful connection or an exception
			mSocket.connect();
				
		} catch (IOException e) {
			// Close the socket
			try {
				mSocket.close();
			} catch (IOException e2) {
				
			}
			return;
		}            
	
           
		AccessableIF lAccessable = mCreator.createAccessable(mHandler, mSocket);
		mHandler.obtainMessage(HandlerMessagesIF.RECEIVING_ACCESSABLE, lAccessable).sendToTarget();   
		//erzeuge accessableIF
		
		
	}
	
	
	/** Will cancel the listening socket, and cause the thread to finish. */
    public synchronized void cancel() {
    	
        try {
        	
        	if (DEBUG) Log.d(CLAZZ_NAME, "try to close");
        	mSocket.close();
            if (DEBUG) Log.d(CLAZZ_NAME, "closed");
            performInterrupt();
        } catch (IOException e) { }
    }
    
    
    public synchronized void performStart() {
    	
    	Log.d(CLAZZ_NAME, "performStart()");
    	if (mThread != null) {
			
			mThread.interrupt();
			mThread = null;
		}
    	mThread = new Thread(this);
    	mThread.start();    	
    }
    
    
    public void performInterrupt() {
    	    		
    	mThread.interrupt();
    	mThread = null;
    }

}
