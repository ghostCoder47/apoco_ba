package com.janas.apoco.activity.interfaces;

public interface CloseableIF {
	
	
	public void close();

}
