package com.janas.apoco.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.cert.Certificate;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class JSONParser {
	
	
	public static final String CLAZZ_NAME = JSONParser.class.getSimpleName();
	
	
	public static enum RequestMethodE {
		
		POST, GET;
	}
	
	
	public JSONParser() {

	}


	public JSONObject preformHttpRequest(String url, RequestMethodE method, List<NameValuePair> params) {

		InputStream inputStream = null;
		JSONObject jObj = null;
		String json = "";
		HttpClient httpClient = new DefaultHttpClient();
		HttpConnectionParams.setConnectionTimeout(httpClient.getParams(), 10000);
		HttpResponse httpResponse = null;
		HttpEntity httpEntity = null;
		
		try {
			
			
			if (method == RequestMethodE.POST){
				
				Log.d(CLAZZ_NAME, "URL: " + url);
				Log.d(CLAZZ_NAME, "PARAMS: " + params);
				
				HttpPost httpPost = new HttpPost(url);				
				httpPost.setEntity(new UrlEncodedFormEntity(params));				
				httpResponse = httpClient.execute(httpPost);				
				httpEntity = httpResponse.getEntity();
				inputStream = httpEntity.getContent();	
								
				
			} else if (method == RequestMethodE.GET){				
				
				String paramString = URLEncodedUtils.format(params, "utf-8");
				url += "?" + paramString;
				
				Log.d(CLAZZ_NAME, "URL: " + url);
				
				HttpGet httpGet = new HttpGet(url);
				httpResponse = httpClient.execute(httpGet);
				httpEntity = httpResponse.getEntity();
				inputStream = httpEntity.getContent();
				
			}			
			

		} catch (UnsupportedEncodingException e) {
			
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		try {
			
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				
				sb.append(line + "\n");
			}
			inputStream.close();
			json = sb.toString();
			Log.d(CLAZZ_NAME, "JSONString: " + json);
		} catch (Exception e) {
			
			Log.e("Buffer Error", "Error converting result " + e.toString());
		}

		try {
			
			jObj = new JSONObject(json);
		} catch (JSONException e) {
			
			Log.e(CLAZZ_NAME, "Error parsing data " + e.toString());
		}
		
		return jObj;

	}
}
