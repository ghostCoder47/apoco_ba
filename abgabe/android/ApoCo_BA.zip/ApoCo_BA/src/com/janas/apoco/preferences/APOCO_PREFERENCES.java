package com.janas.apoco.preferences;

/**
 * 
 * @author Dawid Janas
 * 
 * Dieses Interface beinhaltet alle notwendigen Konstanten
 * für den Umgang mit "Application Preferences"
 *
 */
public interface APOCO_PREFERENCES {

	/* Dateiname der Preferences Datei*/
	public static final String FILENAME = "APOCO_PREFERENCES";
			
	/* von der App genutzten Bluetoothgeräte Typ */
	public static final String BODY_SCALE 				= "BODY_WEIGHT";
	public static final String FOOD_SCALE 				= "FOOD_SCALE";
	public static final String BLOOD_PRESSURE_MONITOR 	= "BLOOD_PRESSURE";	
	
	/* von der App genutzten Bluetoothgeräte Name */
	public static final String BODY_SCALE_NAME 				= "body_scale_name";
	public static final String FOOD_SCALE_NAME 				= "food_scale_name";
	public static final String BLOOD_PRESSURE_MONITOR_NAME 	= "blood_pressure_monitor_name";
	
	/* von der App genutzten Bluetoothgeräte Adresse */
	public static final String BODY_SCALE_ADDRESS 				= "body_scale_address";
	public static final String FOOD_SCALE_ADDRESS 				= "food_scale_address";
	public static final String BLOOD_PRESSURE_MONITOR_ADDRESS 	= "blood_pressure_monitor_address";
	
	/* Zugangsdaten für Externen Server */
	public static final String SERVER_IP 		= "server_ip";
	public static final String SERVER_PORT 		= "server_port";
	public static final String SERVER_USER 		= "server_user";
	public static final String SERVER_PASSWORD 	= "server_password";
	
	public enum KNOWN_DEVICES {
		
		ManuelleMessung, WeightTel, BT_A1C51C4
	}

}
