package com.janas.apoco.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.preferences.PreferencesManager;

public class ActivityServerOptions extends Activity {

	private EditText mServerIPET, mServerPortET;
	private Button mSetupServerBtn, mBackBtn;
	private PreferencesManager mPrefManager;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_server_tools);
	
		setupPrefManager();
		setupServerIPET();
		setupServerPortET();
		setupSetupServerBtn();
		setupBackBtn();
	}
	

	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}


	private void setupPrefManager() {
		
		mPrefManager = new PreferencesManager(this);
	}


	private void setupServerPortET() {
		
		mServerPortET = (EditText) findViewById(R.id.etServerPort);
		String lServerPort = mPrefManager.getServerPort();
		if (null == lServerPort) {
			
			lServerPort = "80";			
			boolean result = mPrefManager.updateServerPort(lServerPort);
			if (!result); //fucking error
		}
		mServerPortET.setHint(lServerPort);
	}
	

	private void setupServerIPET() {
		
		mServerIPET = (EditText) findViewById(R.id.etServerIP);
		String lServerIP = mPrefManager.getServerIP();
		if (null == lServerIP) {
			
			lServerIP = "127.0.0.1";			
			boolean result = mPrefManager.updateServerIP(lServerIP);
			if (!result); //fucking error
		}
		mServerIPET.setHint(lServerIP);
	}
	
	
	private void setupSetupServerBtn() {
		
		mSetupServerBtn = (Button) findViewById(R.id.btnServerDatenEintragen);
		mSetupServerBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				String lIP = mServerIPET.getText().toString();
				if (lIP.equals("")) lIP = mServerIPET.getHint().toString();
				String lPort = mServerPortET.getText().toString();
				if (lPort.equals("")) lPort = mServerPortET.getHint().toString();
				boolean lIPResult = mPrefManager.updateServerIP(lIP);
				boolean lPortResult = mPrefManager.updateServerPort(lPort);
				if (!lIPResult || !lPortResult) {
					
					//ERROR try again
				}
				//message ok
				onBackPressed();
			}
		});
	}

	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.up_side_in, R.anim.up_side_out);
	}
}
