package com.janas.apoco.activity;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.activity.interfaces.CloseableIF;
import com.janas.apoco.activity.interfaces.WriteToPerformableIF;
import com.janas.apoco.arrayadapter.BloodpressureAdapter;
import com.janas.apoco.arrayadapter.model.BloodpressureModel;
import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.BluetoothManager;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.bodytel.BloodpressureResult;
import com.janas.apoco.bodytel.BodyTelUUIDsIF;
import com.janas.apoco.bodytel.BodyweightResult;
import com.janas.apoco.bodytel.PressureTelCreator;
import com.janas.apoco.bodytel.PressureTelMessageReader;
import com.janas.apoco.bodytel.WeightTelCreator;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.BloodpressureDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.SynchronizeBloodpressure;
import com.janas.apoco.preferences.APOCO_PREFERENCES;
import com.janas.apoco.preferences.PreferencesManager;
import com.janas.apoco.tools.BloodpressureDiagnose;
import com.janas.apoco.tools.HexConverter;
import com.janas.apoco.tools.Toasting;

public class ActivityBloodpressure extends Activity implements WriteToPerformableIF, CloseableIF { //, MessageDisplayableIF {
	
	
	public static final boolean DEBUG = false;
	public static final String CLAZZ_NAME = ActivityBloodpressure.class.getSimpleName();
	public static final int SYNCHRONIZING_DATA_COMPLETE = 0x0;
	public static final int SYNCHRONIZING_DATA_FAILED 	= 0x1;
	public static final int PERFORME_CLOSE				= 0X2;
	
	
	private static final String SDP_SERVICE_NAME = "GlucoTel SPP";
	
	
	private Button mBackBtn, mStartBtn, mDevicesBtn, mAcceptRecordBtn;	
	private ListView mResultLstV;
	private ArrayList<BloodpressureModel> mBloodpressureData;
	private BloodpressureAdapter mBloodpressureAdapter;	
	private BluetoothManager mBTManager;
	private AccessableIF mConnectedThread;	
	private Handler mBloodpressureHandler, mHandlerAct;;
	private PressureTelMessageReader mMessageConverter;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		setContentView(R.layout.activity_bloodpressure);
		
		setupBackBtn();
		setupStartBtn();
		setupDevicesBtn();
		setupAcceptRecordBtn();
		setupResultData();
		setupPressureTelArrayAdapter();
		setupResultLstV();
		setupBluetoothManager();
		setupBluetooth();
		setupUser();
		setupDBManager();
		setupBloodpressureHandler();
		setupHandlerAct();
		setupMessageConverter();
		initList();
		
	}
	

	@Override
	protected synchronized void onStart() {
		
		super.onStart();	
		
		PreferencesManager pm = new PreferencesManager(getApplicationContext());
		String deviceName = pm.getName(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR);
		
		Log.d(CLAZZ_NAME, "device name: " + deviceName);
		Log.d(CLAZZ_NAME, "DEVICES: " + APOCO_PREFERENCES.KNOWN_DEVICES.BT_A1C51C4.toString());
		
		if (null != deviceName) {
			
			if (deviceName.equals(APOCO_PREFERENCES.KNOWN_DEVICES.BT_A1C51C4.toString())) {
				
				Log.d(CLAZZ_NAME, "known device: " + deviceName);
				if (mBTManager.isEnabled()) {
					
					mBTManager.listenForInquiryConnections(
							mBloodpressureHandler, 
							new PressureTelCreator(), 
							BodyTelUUIDsIF.PRESSURETEL_UUID_SPP_1234, 
							SDP_SERVICE_NAME
							);
				}
			} else {
				
				Toasting.inScreenCenter(getApplicationContext(), "Gerät für diese Messung ist Unbekannt");
			}
		} else {			
			
			Log.d(CLAZZ_NAME, "name ist null");
		}		
		
		Log.d(CLAZZ_NAME, "onStart()");
		
		
		
	}
	
	
	@Override
	protected synchronized void onStop() {
		
		super.onStop();
		if (null != mConnectedThread) mConnectedThread.cancel();
		if (null != mBTManager) mBTManager.onStop();
	}

	
	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}
	
	
	private void initList() {
		
		
		Cursor cursor = mDBManager.initBloodpressure(mUser);
		while (cursor.moveToNext()) {
				
				BloodpressureDTO bpdto = new BloodpressureDTO(cursor);
				mBloodpressureAdapter.add(bpdto);
			
		}
		cursor.close();
		Log.d(CLAZZ_NAME, "finish initList()");
		

	}
	
	
	private void setupHandlerAct() {
		
		mHandlerAct = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				
				switch(msg.what) {
				
				case SYNCHRONIZING_DATA_COMPLETE:
					
					onBackPressed();
					break;
					
					
				case SYNCHRONIZING_DATA_FAILED:
					
					onBackPressed();
					break;
					
					
				case PERFORME_CLOSE:
					
					onBackPressed();
					break;
					
				}
			}
		};
	}
	
	
	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityBloodpressure.this);
	}
	
	
	private void setupMessageConverter() {
		
		mMessageConverter = new PressureTelMessageReader(mBloodpressureHandler, this);
	}


	private void setupBloodpressureHandler() {
		
		mBloodpressureHandler = new Handler() {
			
			
			private static final boolean DEBUG = false;
			private final String CLAZZ_NAME = Handler.class.getSimpleName() + "PressureTel";		
					
			private ProgressDialog mProgressDialog;
			
			
			@Override
			public void handleMessage(Message msg) {	
				
			
				switch (msg.what) {			
				
				case HandlerMessagesIF.READ: 
					
					String answear = mMessageConverter.readMessage(msg);
					if (DEBUG) Log.d(CLAZZ_NAME, "writing: " + answear);
					break;
					
					
				case HandlerMessagesIF.WRITE:
					
					byte[] lAnswear = (byte[]) msg.obj;
					if (null != mConnectedThread) mConnectedThread.writeTo(lAnswear);
					if (DEBUG) Log.d(CLAZZ_NAME, "writing: " + HexConverter.hexBytesToString(lAnswear, lAnswear.length));
					break;
					
					
				case HandlerMessagesIF.MEASUREMENT_FINISH:
					
					List<BloodpressureResult> resultList = null;
					if (msg.obj instanceof List) {
						
						resultList = (LinkedList<BloodpressureResult>) msg.obj;
					}
					
					if (null != resultList) {
						
						for (BloodpressureResult e : resultList) {
							
							e.setDeviceName(new PreferencesManager(getApplicationContext()).getName(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR));							
							BloodpressureDTO bloodpressure = new BloodpressureDTO(mUser, e);
							mBloodpressureAdapter.add(BloodpressureModel.convertDTO_to_MODEL(bloodpressure));
							long rowid = mDBManager.insertBloodpressure(bloodpressure);
							Log.d(CLAZZ_NAME, "rowid: " + rowid);
						}
						
						mProgressDialog.dismiss();
						break;
					}
					mProgressDialog.dismiss();
					Toasting.inScreenCenter(getApplicationContext(), "Fehler bei Datenübertragung, bitte erneut Messen");
					break;
					
					
				case HandlerMessagesIF.RECEIVING_ACCESSABLE:
					
					performWriteTo("Waage verbunden, warte auf Daten...");
					mProgressDialog = new ProgressDialog(ActivityBloodpressure.this);
					mProgressDialog.setMessage("Warte auf Dateneingang...");
					mProgressDialog.setIndeterminate(false);
					mProgressDialog.setCancelable(true);
					mProgressDialog.show();
					
					
					synchronized (this) {
						
						if (null != mConnectedThread) {
							
							mConnectedThread.cancel();
							mConnectedThread = null;
						}
						mConnectedThread = (AccessableIF) msg.obj;
						mConnectedThread.performStart();
						break;
					}
					
					
				}
			}
			
		};
	}


	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}
	
	
	private void setupResultLstV() {
		
		mResultLstV = (ListView) findViewById(R.id.resultListView);
		mResultLstV.setAdapter(mBloodpressureAdapter);		
		mResultLstV.setOnItemClickListener(new OnItemClickListener() {			
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				
				Object o = mBloodpressureAdapter.getItem(position);
				if (o instanceof BloodpressureModel) {
					
					BloodpressureModel result = (BloodpressureModel) o;
					
					Toasting.inScreenCenter(
							getApplicationContext()
							, BloodpressureDiagnose.performDiagnose(result)
							);
				}
			}
		});
	}


	private void setupPressureTelArrayAdapter() {
		
		//BloodpressureAdapterFabric.getBloodpressureAdapter(this, mResultData);
		mBloodpressureAdapter = new BloodpressureAdapter(this, mBloodpressureData);
	}


	private void setupResultData() {
		
		mBloodpressureData = new ArrayList<BloodpressureModel>();
	}
	

	private void setupBluetooth() {
		
		if (!mBTManager.isEnabled()) {
			
			Intent lBTEnable = mBTManager.enableBluetooth();
			startActivityForResult(lBTEnable, ActivityRequestCodesIF.REQUEST_BT_ENABLE);			
		}		
		if (!mBTManager.isBluetoothAvailable()) {
			
			Toasting.inScreenCenter(getApplicationContext(), "Bluetooth not available");
			finish();
			overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
		}
				
		
	}
	

	private void setupBluetoothManager() {
		
		mBTManager = new BluetoothManager();
	}

	
	private void setupAcceptRecordBtn() {

		mAcceptRecordBtn = (Button) findViewById(R.id.btnAcceptRecord);
		mAcceptRecordBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Context activity = ActivityBloodpressure.this;
				new SynchronizeBloodpressure(activity, new NetworkHandler(activity, true), mHandlerAct).execute(mUser);
				
			}
		});
	}


	private void setupDevicesBtn() {
		
		mDevicesBtn = (Button) findViewById(R.id.btnDevices);
		mDevicesBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lDevicesScreen = new Intent(getApplicationContext(), ActivityDevices.class);
				startActivityForResult(lDevicesScreen, ActivityRequestCodesIF.WHO_IS_CALLER_ACTIVITY);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);
			}
		});
	}


	private void setupStartBtn() {
		
		mStartBtn = (Button) findViewById(R.id.btnStart);
		mStartBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}

	
	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}

	
	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
	
	
	@Override
	protected void onActivityResult(int pRequestCode, int pResultCode, Intent pData) {
		
		super.onActivityResult(pRequestCode, pResultCode, pData);
		switch(pResultCode) {
		
		
		case ActivityRequestCodesIF.REQUEST_BT_ENABLE:
			
			if (RESULT_OK == pResultCode) {
				
				if (DEBUG) Log.d(CLAZZ_NAME, "bluetooth is enabled");
			}
			break;
			
			
		}
	}

	
	@Override
	public void performWriteTo(String msg) {
		
		
//		if (msg.equals(WeightTelMessageProtocol.SUCCESS)) {
//			
//			Message lMsg = new Message();
//			lMsg.what = HandlerMessagesIF.MEASUREMENT_FINISH;
//			mPressureTelHandler.sendMessageDelayed(lMsg, RETURN_TO_LAST_ACTIVITY_TIME);
//			return;
//		}
//		displayMessage(msg);
	}
	
	
	@Override
	public void performWriteTo(byte[] msg) {
		
		if (null != mConnectedThread) mConnectedThread.writeTo(msg);
		if (DEBUG) Log.d(CLAZZ_NAME, "writing: " + new String(msg));		
	}


	@Override
	public void close() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
}
