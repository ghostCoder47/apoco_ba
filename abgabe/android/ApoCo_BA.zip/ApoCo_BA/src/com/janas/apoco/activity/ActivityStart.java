package com.janas.apoco.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.database.local.dto.UserDTO;

public class ActivityStart extends Activity {
	
	
	public static final String CLAZZ_NAME = ActivityStart.class.getSimpleName();
	
	
	private Button 
		mKoerpergewichtBtn, 
		mBlutdruckBtn, 
		mKcalBtn, 
		mUebersichtBtn,
		mDevicesBtn;
	private UserDTO mUser;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_start);
		
		setupKoerpergewichtBtn();
		setupBlutdruckBtn();
		setupKcalBtn();
		setupUebersichtBtn();
		setupDevicesBtn();
		setupUser();
		
	}


	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}


	private void setupDevicesBtn() {
		
		mDevicesBtn = (Button) findViewById(R.id.btnStartTools);
		mDevicesBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lDevicesScreen = new Intent(getApplicationContext(), ActivityDevices.class);
				startActivityForResult(lDevicesScreen, ActivityRequestCodesIF.WHO_IS_CALLER_ACTIVITY);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);
			}
		});
	}


	private void setupUebersichtBtn() {
		
		mUebersichtBtn = (Button) findViewById(R.id.btnUebersicht);
		mUebersichtBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lUebersichtScreen = new Intent(getApplicationContext(), ActivitySummary.class);
				lUebersichtScreen.putExtra(ActivityExtrasCodesIF.USER, mUser);	
				startActivity(lUebersichtScreen);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
	}


	private void setupKcalBtn() {
		
		mKcalBtn = (Button) findViewById(R.id.btnKcal);
		mKcalBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lFoodKcalScreen = new Intent(getApplicationContext(), ActivityFoodKcal.class);
				lFoodKcalScreen.putExtra(ActivityExtrasCodesIF.USER, mUser);	
				startActivity(lFoodKcalScreen);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
	}


	private void setupBlutdruckBtn() {
		
		mBlutdruckBtn = (Button) findViewById(R.id.btnBlutdruck);
		mBlutdruckBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lBloodpressureScreen = new Intent(getApplicationContext(), ActivityBloodpressure.class);
				lBloodpressureScreen.putExtra(ActivityExtrasCodesIF.USER, mUser);
				startActivity(lBloodpressureScreen);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
	}


	private void setupKoerpergewichtBtn() {
		
		mKoerpergewichtBtn = (Button) findViewById(R.id.btnKoerperGewicht);
		mKoerpergewichtBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lBodyweightScreen = new Intent(getApplicationContext(), ActivityBodyweight.class);
				lBodyweightScreen.putExtra(ActivityExtrasCodesIF.USER, mUser);
				startActivity(lBodyweightScreen);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
	}

	
}
