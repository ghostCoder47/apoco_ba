package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityBloodpressure;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.BloodpressureDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.database.local.tbl.BloodpressureTbl;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.tools.URLBuilder;

public class SynchronizeBloodpressure extends AsyncTask<UserDTO, Void, Boolean> {

	
	public static final String CLAZZ_NAME = SynchronizeBloodpressure.class.getSimpleName();
	
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	private boolean isNetworkConnected;
	
	
	public SynchronizeBloodpressure(Context context, Handler handlerNet, Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = handlerNet;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("synchronisiere Daten auf Server...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
		mDBManager = new DBManagerLocal(mContext);
	}

	
	@Override
	protected Boolean doInBackground(UserDTO... pUser) {
		
		//netzwerk verfügbarkeit prüfen
		isNetworkConnected = new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet);		
		if (!isNetworkConnected) return false;
		
		
		boolean result = false;		
		mUser = pUser[0];
		
		if (null == mUser) {
			
		}
		
		JSONObject user = mUser.toJSONObject();			
		JSONArray payload = new JSONArray();
		try {
			
			Cursor cursor = mDBManager.synchronizeBloodpressure(mUser);
			//prüfung: muss was synchronisiert werden
			if (cursor.getCount() == 0) {
				
				mDBManager.closeDB();
				return true;	
			}
			
			while (cursor.moveToNext()) {
		
				BloodpressureDTO bpdto = new BloodpressureDTO(cursor);
				payload.put(cursor.getPosition(), bpdto.toJSONObject());
			}
			cursor.close();
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "error while put payload: " + e.getMessage());
		}
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(JSON_TAG_IF.USER, user.toString()));
		params.add(new BasicNameValuePair(JSON_TAG_IF.PAYLOAD, payload.toString()));
				
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.INSERT_BLOODPRESSURE);
		
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);		
		
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
				
				int index = 0, ids[] = new int[payload.length()];
				while (index < payload.length()) {
					
					int id = payload.getJSONObject(index).getInt(BloodpressureTbl._ID);
					ids[index] = id;
					Log.d(CLAZZ_NAME, "id: " + id);
					index++;
				}
				Log.d(CLAZZ_NAME, "before sync");
				mDBManager.confirmSynchronizeBloodpressure(ids);
				Log.d(CLAZZ_NAME, "after sync");
				result = true;
				
			} else {
				
				result = false;
				
			}
			Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
		
		mDBManager.closeDB();
		return result;
	}
	

	@Override
	protected void onPostExecute(Boolean result) {
		
		if (!result) {
			
			if (!isNetworkConnected) return;
			
			if (null != jsonObject) {
				
				try {
					
					AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
					builder.setTitle("Bloodpressure sync");
					builder.setMessage(jsonObject.getString(JSON_TAG_IF.MESSAGE));
					builder.setPositiveButton("OK",new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int whichButton) {

							mHandlerAct.obtainMessage(ActivityBloodpressure.SYNCHRONIZING_DATA_FAILED).sendToTarget();
						}
						
						
					});
					builder.create().show();
					
				} catch (JSONException e) {
					
					Log.d(CLAZZ_NAME, e.getMessage());
				}
				
			} else {
			
				String msg = "Bloodpressure Synchronisierung fehlgeschlagen";
				Toasting.inScreenCenter(mContext, msg);
				mHandlerAct.obtainMessage(ActivityBloodpressure.SYNCHRONIZING_DATA_FAILED).sendToTarget();
			}
			
		} else {
			
			mHandlerAct.obtainMessage(ActivityBloodpressure.SYNCHRONIZING_DATA_COMPLETE).sendToTarget();
		}
		progressDialog.dismiss();
	}		
}
