package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityFoodKcal;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.TageseinheitenDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.tools.URLBuilder;

public class CurrentTageseinheiten extends AsyncTask<UserDTO, Void, Void> {
	
	

	public static final String CLAZZ_NAME = CurrentTageseinheiten.class.getSimpleName();
	public static final int UPDATE_TAGESEINHEITEN = 0x0;
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	private boolean isNetworkConnected;
	
	public CurrentTageseinheiten(Context context, Handler netHandler,  Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = netHandler;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("aktualisiere Tageseinheiten...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
		mDBManager = new DBManagerLocal(mContext);
	}

	
	@Override
	protected Void doInBackground(UserDTO... pUser) {
		
		//netzwerk verfügbarkeit prüfen
		isNetworkConnected = new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet);		
		if (!isNetworkConnected) return null;
		
		mUser = pUser[0];
		
		if (null == mUser) return null;
		
		JSONObject user = mUser.toJSONObject();			
				
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(JSON_TAG_IF.USER, user.toString()));
				
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.CURRENT_TAGESEINHEITEN);		
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);		
		
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
								
				JSONObject obj = jsonObject.getJSONObject(JSON_TAG_IF.TAGESEINHEITEN);
				TageseinheitenDTO tageseinheiten = new TageseinheitenDTO(mUser, obj);
				TageseinheitenDTO currentTageseinheiten = mDBManager.currentTageseinheiten(mUser);	
				
				
				
				if (currentTageseinheiten.added_on.before(tageseinheiten.added_on)) {
					
					mDBManager.insertTageseinheiten(mUser, tageseinheiten);					
					Log.d(CLAZZ_NAME, "insert current Tageseinheiten: " + tageseinheiten.toString());
				}
				
				mDBManager.closeDB();
				
			} else {				
			}
			Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
				
		
		return null;
	}
	

	@Override
	protected void onPostExecute(Void result) {
		
		mHandlerAct.obtainMessage(UPDATE_TAGESEINHEITEN).sendToTarget();
		progressDialog.dismiss();
	}		

}
