package com.janas.apoco.database.extern;

public interface ExternServerDIR {
	
	public static final String ANDROID_CONNECTION_DIR = "http://%s/apoco/android_connect/";

}
