package com.janas.apoco.bluetooth;

public interface BluetoothStateIF {
	
	
	public static final int STATE_NONE 			= 0x00;       
    public static final int STATE_LISTEN 		= 0x01;    		
    public static final int STATE_CONNECTING 	= 0x02; 
    public static final int STATE_CONNECTED 	= 0x03;  

}
