package com.janas.apoco.activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.tools.ConnectivityTest;

public class ActivityLogin extends Activity {
	
	
	public static final String CLAZZ_NAME = ActivityLogin.class.getSimpleName();
	
	
	private Button mLoginBtn, mServerOptions;
	private TextView mLinkToRegister;
	private EditText mEmailET, mPasswordET;
	private Handler mHandler;
	private DBManagerLocal mDBManager;
	private UserDTO mUser;
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_login);
		
		setupLoginBtn();
		setupServerOptionsBtn();
		setupRegisterLink();
		setupEmailET();
		setupPasswordET();
		setupHandler();
		setupDBManager();
		checkNetworkConnectivity();
	}
	
	
	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}


	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityLogin.this);
	}


	private void setupPasswordET() {
		
		mPasswordET = (EditText) findViewById(R.id.passwordET);
	}


	private void setupEmailET() {
		
		mEmailET = (EditText) findViewById(R.id.emailET);
	}


	private void checkNetworkConnectivity() {
		
		new Thread() {
			
			public void run() {
				
				new ConnectivityTest(getApplicationContext()).isAnyNetworkReachable(mHandler);
			}
		}.start();		
	}


	private void setupHandler() {
		
		mHandler = new NetworkHandler(ActivityLogin.this, true);		
	}


	private void setupServerOptionsBtn() {
		
		mServerOptions = (Button) findViewById(R.id.btnServerTools);
		mServerOptions.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lServerOptions = new Intent(getApplicationContext(), ActivityServerOptions.class);
				startActivity(lServerOptions);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);				
			}
		});
	}


	private void setupLoginBtn() {
		
		mLoginBtn = (Button) findViewById(R.id.btnLogin);
		mLoginBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				if (!checkUserInputData()) return;
				
				Intent startActivity = new Intent(getApplicationContext(), ActivityStart.class);
				startActivity.putExtra(ActivityExtrasCodesIF.USER, mUser);				
				startActivity(startActivity);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
				finish();
			}
		});
	}
	
	
	private boolean checkUserInputData() {
		
		
		String em = mEmailET.getText().toString();
		String pw = mPasswordET.getText().toString();
		mUser = new UserDTO();
		mUser.email = em;
		mUser.password = pw;
		
		mUser = mDBManager.loginUser(mUser);	
		if (null == mUser) {
			
			
			mEmailET.requestFocus();
			mEmailET.setError("ungültige Email");
			return false;
			
		} else if (!pw.equals(mUser.password)){
			
			
			mPasswordET.requestFocus();
			mPasswordET.setError("das Passwort ist falsch");
			mUser = null;
			return false;
			
		}
		return true;
	}
	
	
	private void setupRegisterLink() {
		
		mLinkToRegister = (TextView) findViewById(R.id.link_to_register);
		mLinkToRegister.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lLinkToRegister = new Intent(getApplicationContext(), ActivityRegister.class);
				startActivity(lLinkToRegister);
				overridePendingTransition(R.anim.right_side_in, R.anim.right_side_out);
			}
		});
		
	}

}
