package com.janas.apoco.bluetooth;

import java.util.UUID;

public interface StandardUUIDsIF {

	public static final UUID SPP_1101 = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
}
