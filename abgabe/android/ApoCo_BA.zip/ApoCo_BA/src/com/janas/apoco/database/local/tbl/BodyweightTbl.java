package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.BodyweightColumns;
import com.janas.apoco.database.local.columns.UserColumns;

public class BodyweightTbl implements BodyweightColumns {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = BodyweightTbl.class.getSimpleName();
	public static final String TABLE_NAME = "bodyweight";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 		" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				U_ID + 		" INTEGER NOT NULL," + 
				ADDED_ON + 	" TIMESTAMP NOT NULL DEFAULT current_timestamp," + 
				WEIGHT + 	" INTEGER NOT NULL DEFAULT 0, " + 
				UNIT + 		" TEXT NOT NULL, " +
				SYNC + 		" INTEGER NOT NULL DEFAULT 0, " +
				DEVICENAME + " TEXT, " +
				"FOREIGN KEY(" + U_ID + ") REFERENCES " + UserTbl.TABLE_NAME + "(" + UserColumns._ID + ")" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_INSERT_BODYWEIGHT = 
			
			"INSERT INTO " + TABLE_NAME + " (" + 
					U_ID + ", " + 
					ADDED_ON + ", " + 
					WEIGHT + "," + 
					UNIT + "," + 
					DEVICENAME + ")" +
					"VALUES(?,?,?,?,?)";
	
	
	public static final String STMT_INIT_BODYWEIGHT_LIST =
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + " = ?";
	
	
	public static final String STMT_SYNCHRONIZE_BODYWEIGHT = 
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + " = ?" + 
			" AND " + SYNC + "= 0";
	
	
	//wird in dieser version noch nicht verwendet
	public static final String STMT_CONFIRM_SYNCHRONIZE_BODYWEIGHT = 
			
			"UPDATE " + TABLE_NAME + 
			" SET " + SYNC + " = 1" + 
			" WHERE " + _ID + " = ?";

}
