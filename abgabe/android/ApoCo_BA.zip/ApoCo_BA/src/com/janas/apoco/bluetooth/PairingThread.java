package com.janas.apoco.bluetooth;

import java.io.IOException;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.util.Log;


public class PairingThread implements Runnable {

		
		public static final boolean DEBUG = true;
		public static final String CLAZZ_NAME = PairingThread.class.getSimpleName();
		
		
		private final BluetoothAdapter mBTAdapter;
		private Thread mThread;
		private final UUID mUUID;
		private final BluetoothServerSocket serverSocket;
		private BluetoothSocket mSocket;
		private int mScanMode;
		
		public PairingThread(UUID uuid, BluetoothAdapter pBTAdapter) {
			
			mUUID = uuid;
			mBTAdapter = pBTAdapter;
			BluetoothServerSocket tmp = null;
			try {
				
				Log.d(CLAZZ_NAME, "try get serverSocket: " + mBTAdapter.getName());
				tmp = mBTAdapter.listenUsingInsecureRfcommWithServiceRecord("GlucoTel SPP", mUUID);
			} catch (IOException e) {};
			serverSocket = tmp;
		}
		
		@Override
		public void run() {
			
			updateScanMode();
	        while (
	        		null != mThread && 
	        		!mThread.isInterrupted() && 
	        		mScanMode == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE
	        		) {
	        	
	        	
	        	if (DEBUG) Log.d(CLAZZ_NAME, "try to accept");	           
	            updateScanMode();
	        }
	        Log.d(CLAZZ_NAME, "is interrupted");
		}
		
		
		public int updateScanMode() {
			
			mScanMode = mBTAdapter.getScanMode();
			return mScanMode;
		}
		
		
		public synchronized void performStart() {
			
			if (mThread != null) {
				
				mThread.interrupt();
				mThread = null;
			}
			mThread = new Thread(this);
			mThread.start();			
		}
		
		
		public synchronized void cancel() {
	    	
	        try {
	        
	        	if (DEBUG) Log.d(CLAZZ_NAME, "try to close");
	        	serverSocket.close();
	            if (DEBUG) Log.d(CLAZZ_NAME, "closed");
	            performInterrupt();	            
	        } catch (IOException e) { } 
	    }
		
		
		public void performInterrupt() {
	    		    	
	    	mThread.interrupt();
	    	mThread = null;	    	
	    }
		
		
		
	}