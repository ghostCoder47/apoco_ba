package com.janas.apoco.bodytel;


import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.janas.apoco.activity.interfaces.WriteToPerformableIF;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.tools.HexConverter;

public class WeightTelMessageReader {
	
	
	private static final boolean DEBUG = true;
	private static final String CLAZZ_NAME = WeightTelMessageReader.class.getSimpleName();
	
	
	private Handler mHandler;
	private WriteToPerformableIF mWriter;
	private StringBuilder mHexString;
	private int mReadedBytes;
	private boolean 
	mIdent = false, 
	mWeight = false, 
	mNewDataRequest = false, 
	mDeviceFirmware = false,
	mSuccess = false;
	
	
	public WeightTelMessageReader(Handler pHandler, WriteToPerformableIF pWriter) {
		
		mHandler = pHandler;
		mWriter = pWriter;
		mHexString = new StringBuilder();
	}
	
	
	public String readMessage(Message pMsg) {
		
		byte[] lMessage = (byte[]) pMsg.obj;		
		int size = pMsg.arg1;
		mReadedBytes += size;
		
		mHexString.append(HexConverter.hexBytesToString(lMessage, size));
		String hexString = mHexString.toString();
		
		
		if (hexString.contains(WeightTelMessageProtocol.IDENT_PACKET)) {
			
			if ( mReadedBytes <= WeightTelMessageProtocol.IDENT_LENGTH && !mIdent) {
				
				mIdent = true;
			} else {
				
				resetAll();
				mIdent = true;				
			}
			
			mWriter.performWriteTo(WeightTelMessageProtocol.IDENT_ACK);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.WRITE;
//			lAnswear.obj = WeightTelMessageProtocol.IDENT_ACK;
//			mHandler.sendMessage(lAnswear);
						
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			return HexConverter.hexBytesToString(WeightTelMessageProtocol.IDENT_ACK, WeightTelMessageProtocol.IDENT_ACK.length);
			
		} else if (
				hexString.startsWith(WeightTelMessageProtocol.SINGLE_MEASUREMENT_RESULT) && 
				!mWeight && 
				mReadedBytes == WeightTelMessageProtocol.MEASUREMENT_LENGTH) {
			
			mWriter.performWriteTo(WeightTelMessageProtocol.MEASUREMENT_RESULT_ACK);			
			BodyweightResult weightResult = new WeightTelMeasurementDecoder().decodeMeasurement(hexString);
			if (null != weightResult) {
				
				Message resultMessage = new Message();
				resultMessage.what = HandlerMessagesIF.MEASUREMENT_FINISH;
				resultMessage.obj = weightResult;	
				mHandler.sendMessage(resultMessage);
			} else {
				
				Log.d(CLAZZ_NAME, "weightResult is null");
			}
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			mWeight = true;
			return HexConverter.hexBytesToString(WeightTelMessageProtocol.MEASUREMENT_RESULT_ACK, WeightTelMessageProtocol.MEASUREMENT_RESULT_ACK.length);
			
			
		} else if (
				hexString.startsWith(WeightTelMessageProtocol.ANY_NEW_DATA) && 
				!mNewDataRequest && 
				mReadedBytes == WeightTelMessageProtocol.NEW_DATA_REQUEST_LENGTH) {
			
			mWriter.performWriteTo(WeightTelMessageProtocol.REQUEST_DEVICES_FIRMWARE);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.WRITE;
//			lAnswear.obj = WeightTelMessageProtocol.REQUEST_DEVICES_FIRMWARE;
//			mHandler.sendMessage(lAnswear);
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			mNewDataRequest = true;
			return HexConverter.hexBytesToString(WeightTelMessageProtocol.REQUEST_DEVICES_FIRMWARE, WeightTelMessageProtocol.REQUEST_DEVICES_FIRMWARE.length);
			
		} else if (
				hexString.startsWith(WeightTelMessageProtocol.DEVICES_FIRMWARE) && 
				!mDeviceFirmware && 
				mReadedBytes == WeightTelMessageProtocol.DEVICES_FIRMWARE_LENGTH) {
			
			mWriter.performWriteTo(WeightTelMessageProtocol.DEVICES_FIRMWARE_ACK);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.WRITE;
//			lAnswear.obj = WeightTelMessageProtocol.DEVICES_FIRMWARE_ACK;
//			mHandler.sendMessage(lAnswear);
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			mDeviceFirmware = true;
			return HexConverter.hexBytesToString(WeightTelMessageProtocol.DEVICES_FIRMWARE_ACK, WeightTelMessageProtocol.DEVICES_FIRMWARE_ACK.length);
			
		} else if (
				hexString.startsWith(WeightTelMessageProtocol.ANY_NEW_DATA) && 
				mNewDataRequest && 
				mReadedBytes == WeightTelMessageProtocol.NEW_DATA_REQUEST_LENGTH) {
			
			mWriter.performWriteTo(WeightTelMessageProtocol.NO_NEW_DATA);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.WRITE;
//			lAnswear.obj = WeightTelMessageProtocol.NO_NEW_DATA;
//			mHandler.sendMessage(lAnswear);
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			resetAll();
			return HexConverter.hexBytesToString(WeightTelMessageProtocol.NO_NEW_DATA, WeightTelMessageProtocol.NO_NEW_DATA.length);
			
		} else if (
				hexString.startsWith(WeightTelMessageProtocol.SUCCESS) && 
				!mSuccess && 
				mReadedBytes == WeightTelMessageProtocol.SUCCESS_LENGTH) {
			
			mWriter.performWriteTo(WeightTelMessageProtocol.SUCCESS);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.READ_NEEDED_DATA;
//			lAnswear.obj = HexConverter.hexStringToByteArray(WeightTelMessageProtocol.SUCCESS);
//			mHandler.sendMessage(lAnswear);
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			resetAll();
			return WeightTelMessageProtocol.SUCCESS;
			
		} else if (hexString.contains(WeightTelMessageProtocol.CLOSE)) {
			
//			resetAll();
//			mWriter.performWriteTo(WeightTelMessageProtocol.CLOSE);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.MEASUREMENT_FINISH;
//			lAnswear.obj = WeightTelMessageProtocol.CLOSE;
//			mHandler.sendMessage(lAnswear);
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			resetAll();
			return WeightTelMessageProtocol.CLOSE;			
		}		
		
		return "not ready";
		
	}	
	
	
	public void resetAll() {
		
		mIdent = false;
		mWeight = false;
		mNewDataRequest = false;
		mDeviceFirmware = false;
	}


	

}
