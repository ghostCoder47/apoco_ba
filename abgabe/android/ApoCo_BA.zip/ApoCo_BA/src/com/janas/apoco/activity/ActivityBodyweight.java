package com.janas.apoco.activity;


import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.activity.interfaces.CloseableIF;
import com.janas.apoco.activity.interfaces.WriteToPerformableIF;
import com.janas.apoco.arrayadapter.BodyweightAdapter;
import com.janas.apoco.arrayadapter.model.BodyweightModel;
import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.BluetoothManager;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.bodytel.BodyTelUUIDsIF;
import com.janas.apoco.bodytel.BodyweightResult;
import com.janas.apoco.bodytel.WeightTelCreator;
import com.janas.apoco.bodytel.WeightTelMessageReader;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.BodyweightDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.CurrentWunschgewicht;
import com.janas.apoco.network.asynctask.SynchronizeBodyweight;
import com.janas.apoco.preferences.APOCO_PREFERENCES;
import com.janas.apoco.preferences.PreferencesManager;
import com.janas.apoco.tools.BodyweightDiagnose;
import com.janas.apoco.tools.HexConverter;
import com.janas.apoco.tools.Toasting;

public class ActivityBodyweight extends Activity implements WriteToPerformableIF, CloseableIF { 
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = ActivityBodyweight.class.getSimpleName();
	public static final int SYNCHRONIZING_DATA_COMPLETE = 0x0;
	public static final int SYNCHRONIZING_DATA_FAILED 	= 0x1;
	public static final int PERFORME_CLOSE				= 0X2;
	public static final int UPDATE_WUNSCHGEWICHT 		= 0X3;
	
	
	private static final String SDP_SERVICE_NAME = "GlucoTel SPP";
	
		
	private TextView mWunschgewichtTv;	
	private Button mBackBtn, mStartBtn, mDevicesBtn, mAcceptRecordBtn;
	private ListView mResultLstV;
	private ArrayList<BodyweightModel> mResultData;
	private BodyweightAdapter mBodyWeightAdapter;	
	private BluetoothManager mBTManager;
	private AccessableIF mConnectedThread;		
	private Handler mBodyweightHandler, mHandlerAct;
	private WeightTelMessageReader mMessageConverter;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {

		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		setContentView(R.layout.activity_bodyweight);
				
		setupBackBtn();
		setupStartBtn();
		setupDevicesBtn();
		setupAcceptRecordBtn();		
		setupResultData();
		setupBodyweightArrayAdapter();
		setupResultLstV();
		setupBluetoothManager();
		setupBluetooth();
		setupUser();
		setupDBManager();
		setupBodyweightHandler();
		setupHandlerAct();
		setupMessageConverter();
		setupWunschgewichtTv();
		initList();
	}	
	
	
	private void setupWunschgewichtTv() {
				
		mWunschgewichtTv = (TextView) findViewById(R.id.wunschgewichtTv);
		mWunschgewichtTv.setText("--");
		Context activity = ActivityBodyweight.this;
		new CurrentWunschgewicht(activity, new NetworkHandler(activity, false), mHandlerAct).execute(mUser);
	}


	@Override
	
	protected synchronized void onStart() {
		
		super.onStart();
		
		//valid device
		PreferencesManager pm = new PreferencesManager(getApplicationContext());
		String deviceName = pm.getName(APOCO_PREFERENCES.BODY_SCALE);
		
		
		Log.d(CLAZZ_NAME, "device name: " + deviceName);
		Log.d(CLAZZ_NAME, "DEVICES: " + APOCO_PREFERENCES.KNOWN_DEVICES.WeightTel.toString());
		if (null != deviceName) {
			
			if (deviceName.equals(APOCO_PREFERENCES.KNOWN_DEVICES.WeightTel.toString())) {
				
				Log.d(CLAZZ_NAME, "known device: " + deviceName);
				if (mBTManager.isEnabled()) {
					
					mBTManager.listenForInquiryConnections(
							mBodyweightHandler, 
							new WeightTelCreator(), 
							BodyTelUUIDsIF.WEIGHTTEL_UUID_SPP_1101,
							SDP_SERVICE_NAME
							);
				}
			} else {
				
				Toasting.inScreenCenter(getApplicationContext(), "Gerät für diese Messung ist Unbekannt");
			}
		} else {			
			
			Log.d(CLAZZ_NAME, "name ist null");
		}		
		
		Log.d(CLAZZ_NAME, "onStart()");
	}
	
	
	@Override
	protected synchronized void onStop() {
		
		super.onStop();
		if (null != mConnectedThread) mConnectedThread.cancel();
		if (null != mBTManager) mBTManager.onStop();
	}

	
	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}

	
	private void setupHandlerAct() {
		
		mHandlerAct = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				
				switch(msg.what) {
				
				
				case SYNCHRONIZING_DATA_COMPLETE:
					
					onBackPressed();
					break;
					
					
				case SYNCHRONIZING_DATA_FAILED:
					
					onBackPressed();
					break;
					
					
				case PERFORME_CLOSE:
					
					onBackPressed();
					break;
					
					
				case UPDATE_WUNSCHGEWICHT:
					
					mWunschgewichtTv.setText(msg.obj.toString());
					break;
								
				}
			}
		};
	}


	private void setupMessageConverter() {
		
		mMessageConverter = new WeightTelMessageReader(mBodyweightHandler, this);
	}


	private void setupBodyweightHandler() {
		
		mBodyweightHandler = new Handler() {
			
			
			private static final boolean DEBUG = true;
			private final String CLAZZ_NAME = Handler.class.getSimpleName() + "WeightTel";		
					
			private ProgressDialog mProgressDialog;
			
			
			@Override
			public void handleMessage(Message msg) {	
				
			
				switch (msg.what) {			
				
				case HandlerMessagesIF.READ: 
					
					String answear = mMessageConverter.readMessage(msg);
					Log.d(CLAZZ_NAME, "writing: " + answear);
					break;
					
					
				case HandlerMessagesIF.WRITE:
					
					byte[] lAnswear = (byte[]) msg.obj;
					if (null != mConnectedThread) mConnectedThread.writeTo(lAnswear);
					Log.d(CLAZZ_NAME, "writing: " + HexConverter.hexBytesToString(lAnswear, lAnswear.length));
					break;
										
					
				case HandlerMessagesIF.MEASUREMENT_FINISH:
					
					Log.d(CLAZZ_NAME, "read measurement finish");				
					BodyweightResult result = null;
					if (msg.obj instanceof BodyweightResult) {
						
						result = (BodyweightResult) msg.obj;
					}
					
					if (null != result) {
						
						result.setDeviceName(new PreferencesManager(getApplicationContext()).getName(APOCO_PREFERENCES.BODY_SCALE));						
						BodyweightDTO bodyweight = new BodyweightDTO(mUser, result);
						mBodyWeightAdapter.add(BodyweightModel.convertDTO_to_MODEL(bodyweight));
						long rowid = mDBManager.insertBodyweight(bodyweight);
						Log.d(CLAZZ_NAME, "rowid: " + rowid);
						mProgressDialog.dismiss();
						break;
					}
					mProgressDialog.dismiss();
					Toasting.inScreenCenter(getApplicationContext(), "Fehler bei Datenübertragung, bitte erneut Messen");
					break;
					
					
				case HandlerMessagesIF.RECEIVING_ACCESSABLE:
					
					if (null != mProgressDialog) mProgressDialog.dismiss();
					mProgressDialog = new ProgressDialog(ActivityBodyweight.this);
					mProgressDialog.setMessage("Warte auf Dateneingang...");
					mProgressDialog.setIndeterminate(false);
					mProgressDialog.setCancelable(true);
					mProgressDialog.show();
					
					
					synchronized (this) {
						if (null != mConnectedThread) {
							
							mConnectedThread.cancel();
							mConnectedThread = null;
						}
						mConnectedThread = (AccessableIF) msg.obj;
						mConnectedThread.performStart();
						break;
					}
					
					
				}
			}
			
		};
	}
	
	
	private void initList() {
		
		Cursor cursor = mDBManager.initBodyweight(mUser);
		while (cursor.moveToNext()) {
				
				BodyweightDTO bwdto = new BodyweightDTO(cursor);
				mBodyWeightAdapter.add(bwdto);
			
		}
		cursor.close();
		Log.d(CLAZZ_NAME, "finish initList()");
		

	}


	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityBodyweight.this);
	}


	private void setupUser() {
		
		mUser = (UserDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.USER);
		Log.d(CLAZZ_NAME, "User: " + mUser.toString());
	}


	private void setupResultData() {
		
		mResultData = new ArrayList<BodyweightModel>();
	}


	private void setupBodyweightArrayAdapter() {
		//WeightAdapterFabric.getBodyWeightAdapter(this, mResultData);
		mBodyWeightAdapter = new BodyweightAdapter(this, mResultData);		
	}

	
	private void setupResultLstV() {
		
		mResultLstV = (ListView) findViewById(R.id.resultListView);
		mResultLstV.setAdapter(mBodyWeightAdapter);
		mResultLstV.setOnItemClickListener(new OnItemClickListener() {
			
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				
				Object o = mBodyWeightAdapter.getItem(position);
				if (o instanceof BodyweightModel) {
					
					BodyweightModel result = (BodyweightModel) o;
					
					String diagnose = BodyweightDiagnose.performDiagnose(result, mWunschgewichtTv.getText().toString());
					if (!diagnose.equals("---")) Toasting.inScreenCenter(getApplicationContext(), diagnose);
				}
			}
		});
	}
	
	
	private void setupBluetooth() {
		
		if (!mBTManager.isEnabled()) {
			
			Intent lBTEnable = mBTManager.enableBluetooth();
			startActivityForResult(lBTEnable, ActivityRequestCodesIF.REQUEST_BT_ENABLE);			
		}		
		if (!mBTManager.isBluetoothAvailable()) {
			
			Toasting.inScreenCenter(getApplicationContext(), "Bluetooth not available");
			finish();
			overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
		}
		
	}
	

	private void setupBluetoothManager() {
		
		mBTManager = new BluetoothManager();
	}
	
	
	private void setupAcceptRecordBtn() {

		mAcceptRecordBtn = (Button) findViewById(R.id.btnAcceptRecord);
		mAcceptRecordBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
								
				Context activity = ActivityBodyweight.this;
				new SynchronizeBodyweight(activity, new NetworkHandler(activity, true), mHandlerAct).execute(mUser);
			}
		});
	}


	private void setupDevicesBtn() {
		
		mDevicesBtn = (Button) findViewById(R.id.btnDevices);
		mDevicesBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lDevicesScreen = new Intent(getApplicationContext(), ActivityDevices.class);
				startActivityForResult(lDevicesScreen, ActivityRequestCodesIF.WHO_IS_CALLER_ACTIVITY);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);
			}
		});
	}


	private void setupStartBtn() {
		
		mStartBtn = (Button) findViewById(R.id.btnStart);
		mStartBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}
 
	
	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}
	

	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
	
	
	@Override
	protected void onActivityResult(int pRequestCode, int pResultCode, Intent pData) {
		
		Log.d(CLAZZ_NAME, "onActivityResult");
		switch(pRequestCode) {
		
		case ActivityRequestCodesIF.REQUEST_BT_ENABLE:
			
			Log.d(CLAZZ_NAME, "REQUEST_BT_ENABLE");
			
			if (RESULT_OK == pResultCode) {
				
				if (DEBUG) Log.d(CLAZZ_NAME, "bluetooth is enabled");
				
				mBTManager.listenForInquiryConnections(
						mBodyweightHandler, 
						new WeightTelCreator(), 
						BodyTelUUIDsIF.WEIGHTTEL_UUID_SPP_1101,
						SDP_SERVICE_NAME
						);				
			}
			break;
			
			
		}
	}
	
	
	@Override
	public void performWriteTo(String msg) {
		
		/*/*/
	}
	
	
	@Override
	public void performWriteTo(byte[] msg) {
		
		if (null != mConnectedThread) mConnectedThread.writeTo(msg);
		Log.d(CLAZZ_NAME, "writing: " + HexConverter.hexBytesToString(msg, msg.length));		
	}

	
	@Override
	public void close() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}

}
