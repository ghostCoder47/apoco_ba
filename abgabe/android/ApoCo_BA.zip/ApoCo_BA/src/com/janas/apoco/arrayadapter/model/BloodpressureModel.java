package com.janas.apoco.arrayadapter.model;

import java.text.SimpleDateFormat;
import java.util.Locale;

import com.janas.apoco.database.local.dto.BloodpressureDTO;
import com.janas.apoco.tools.DateTemplateIF;

public class BloodpressureModel {

	public String added_on;
	public String diastolic;
	public String systolic;
	public String pulse;
	public String devicename;
	
	
	public static BloodpressureModel convertDTO_to_MODEL(BloodpressureDTO dto) {
		
		BloodpressureModel bpm = new BloodpressureModel();
		
		SimpleDateFormat formatter = new SimpleDateFormat(DateTemplateIF.TIMESTAMP_TEMPLATE, Locale.getDefault());	    
		bpm.added_on = formatter.format(dto.added_on);
		
		bpm.diastolic = Integer.toString(dto.diastolic);
		bpm.systolic = Integer.toString(dto.systolic);
		bpm.pulse = Integer.toString(dto.pulse);
		bpm.devicename = dto.devicename;
		
		return bpm;
	}
}
