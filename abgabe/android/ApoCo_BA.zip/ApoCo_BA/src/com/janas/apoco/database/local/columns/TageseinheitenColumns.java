package com.janas.apoco.database.local.columns;

public interface TageseinheitenColumns {

	
	static final String _ID 			= "_id";
	static final String U_ID 			= "u_id";
	static final String ADDED_ON		= "added_on";
	static final String TAGESEINHEITEN 	= "tageseinheiten";
}
