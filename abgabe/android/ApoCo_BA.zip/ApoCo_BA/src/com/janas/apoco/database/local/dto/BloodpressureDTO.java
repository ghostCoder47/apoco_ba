package com.janas.apoco.database.local.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.bodytel.BloodpressureResult;
import com.janas.apoco.database.local.tbl.BloodpressureTbl;
import com.janas.apoco.tools.TimeTools;

public class BloodpressureDTO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = BloodpressureDTO.class.getSimpleName();
	
	
	public long _id;
	public long u_id;
	public Timestamp added_on;
	public int diastolic;
	public int systolic;
	public int pulse;
	public int sync;
	public String devicename;
	
	
	public BloodpressureDTO(UserDTO user, BloodpressureResult result) {
		
		this.u_id 		= user.get_id();
		this.added_on 	= result.getRecordDate();
		this.diastolic 	= result.getDiastolic();
		this.systolic 	= result.getSystolic();
		this.pulse 		= result.getPulse();
		this.devicename = result.getDeviceName();
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public BloodpressureDTO(long id, long u_id, long added_on, int diastolic, int systolic, int pulse, int sync, String devicename ) {
		
		this._id 		= id;
		this.u_id 		= u_id;
		this.added_on 	= new Timestamp(added_on);
		this.diastolic 	= diastolic;
		this.systolic 	= systolic;
		this.pulse 		= pulse;
		this.sync 		= sync;
		this.devicename = devicename;		
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public BloodpressureDTO(Cursor cursor) {
		
		int idxID 			= cursor.getColumnIndex(BloodpressureTbl._ID);
		int idxU_id			= cursor.getColumnIndex(BloodpressureTbl.U_ID);
		int idxAdded_on 	= cursor.getColumnIndex(BloodpressureTbl.ADDED_ON);
		int idxDiastolic	= cursor.getColumnIndex(BloodpressureTbl.DIASTOLIC);
		int idxSystolic	 	= cursor.getColumnIndex(BloodpressureTbl.SYSTOLIC);
		int idxPulse	 	= cursor.getColumnIndex(BloodpressureTbl.PULSE);
		int idxSync			= cursor.getColumnIndex(BloodpressureTbl.SYNC);
		int idxDevicename	= cursor.getColumnIndex(BloodpressureTbl.DEVICENAME);
		
		this._id 		= cursor.getLong(idxID);
		this.u_id 		= cursor.getLong(idxU_id);
		this.added_on	= new Timestamp(cursor.getLong(idxAdded_on));
		this.diastolic	= cursor.getInt(idxDiastolic);
		this.systolic	= cursor.getInt(idxSystolic);
		this.pulse		= cursor.getInt(idxPulse);
		this.sync		= cursor.getInt(idxSync);
		this.devicename = cursor.getString(idxDevicename);
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public long getU_id() {
		return u_id;
	}


	public void setU_id(long u_id) {
		this.u_id = u_id;
	}


	public Timestamp getAdded_on() {
		return added_on;
	}


	public void setAdded_on(Timestamp added_on) {
		this.added_on = added_on;
	}


	public int getDiastolic() {
		return diastolic;
	}


	public void setDiastolic(int diastolic) {
		this.diastolic = diastolic;
	}


	public int getSystolic() {
		return systolic;
	}


	public void setSystolic(int systolic) {
		this.systolic = systolic;
	}


	public int getPulse() {
		return pulse;
	}


	public void setPulse(int pulse) {
		this.pulse = pulse;
	}


	public int getSync() {
		return sync;
	}


	public void setSync(int sync) {
		this.sync = sync;
	}
	
	
	public String getDevicename() {
		
		return this.devicename;
	}
	
	
	public void setDevicename(String devicename) {
		
		this.devicename = devicename;
	}


	
	
	
	@Override
	public String toString() {
		return "BloodpressureDTO [_id=" + _id + ", u_id=" + u_id
				+ ", added_on=" + added_on + ", diastolic=" + diastolic
				+ ", systolic=" + systolic + ", pulse=" + pulse + ", sync="
				+ sync + ", devicename=" + devicename + "]";
	}


	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(BloodpressureTbl._ID, this._id);
			obj.put(BloodpressureTbl.U_ID, this.u_id);
			obj.put(BloodpressureTbl.ADDED_ON, this.added_on);
			obj.put(BloodpressureTbl.DIASTOLIC, this.diastolic);
			obj.put(BloodpressureTbl.SYSTOLIC, this.systolic);
			obj.put(BloodpressureTbl.PULSE, this.pulse);
			obj.put(BloodpressureTbl.SYNC, this.sync);
			obj.put(BloodpressureTbl.DEVICENAME, this.devicename);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}
	
}
