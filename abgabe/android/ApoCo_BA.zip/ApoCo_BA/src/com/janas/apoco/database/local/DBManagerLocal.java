package com.janas.apoco.database.local;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import com.janas.apoco.bodytel.BloodpressureResult;
import com.janas.apoco.database.local.dto.BloodpressureDTO;
import com.janas.apoco.database.local.dto.BodyweightDTO;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.database.local.dto.MealenergyDTO;
import com.janas.apoco.database.local.dto.TageseinheitenDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.database.local.tbl.BloodpressureTbl;
import com.janas.apoco.database.local.tbl.BodyweightTbl;
import com.janas.apoco.database.local.tbl.FoodTbl;
import com.janas.apoco.database.local.tbl.MealenergyContentTbl;
import com.janas.apoco.database.local.tbl.MealenergyTbl;
import com.janas.apoco.database.local.tbl.TageseinheitenTbl;
import com.janas.apoco.database.local.tbl.UserTbl;
import com.janas.apoco.tools.DateTemplateIF;
import com.janas.apoco.tools.TimeTools;


public final class DBManagerLocal extends SQLiteOpenHelper implements DBManagerPreferencesIF{
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = DBManagerLocal.class.getSimpleName();
		
	
	public DBManagerLocal(Context context) {
		
		super(context, DATENBANK_NAME, null, DATENBANK_VERSION);
	}
	
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		
		//ohne fremdschlüssel zu erst !!!
		db.execSQL(UserTbl.SQL_CREATE);		
		db.execSQL(FoodTbl.SQL_CREATE);
		db.execSQL(BodyweightTbl.SQL_CREATE);	
		db.execSQL(BloodpressureTbl.SQL_CREATE);
		db.execSQL(MealenergyTbl.SQL_CREATE);
		db.execSQL(MealenergyContentTbl.SQL_CREATE);
		db.execSQL(TageseinheitenTbl.SQL_CREATE);
	}
	

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
		//fremdschlüssel zu erst !!! 
		db.execSQL(TageseinheitenTbl.SQL_DROP);
		db.execSQL(MealenergyContentTbl.SQL_DROP);
		db.execSQL(MealenergyTbl.SQL_DROP);
		db.execSQL(BloodpressureTbl.SQL_DROP);
		db.execSQL(BodyweightTbl.SQL_DROP);
		db.execSQL(FoodTbl.SQL_DROP);
		db.execSQL(UserTbl.SQL_DROP);	
		onCreate(db);
	}
	
	
	public void closeDB() {
		
		close();
	}
	
	
	/**
	 * 
	 * @param user
	 * @return row_id 
	 */
	public long registerUser(UserDTO user) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(UserTbl.STMT_INSERT_USER);
		long rowID = -1;
		db.beginTransaction();
		try {
			
			statement.bindString(1, user.vorname);
			statement.bindString(2, user.nachname);
			statement.bindString(3, user.email);
			statement.bindString(4, user.password);
			rowID = statement.executeInsert();
			db.setTransactionSuccessful();
		} catch(Throwable ex) {
			
			Log.d(CLAZZ_NAME, "Fehler beim einfuegen von neuen User: " + ex.getMessage());
		} finally {
			
			db.endTransaction();
		}	
		
		user.set_id(rowID);
		long time = System.currentTimeMillis();
		insertTageseinheiten(user, new TageseinheitenDTO(0, 0, time, TageseinheitenTbl.DEFAULT_TAGESEINHEITEN));
		return rowID;
	}
	
	
	/**
	 * 
	 * @param user
	 * @param tageseinheiten
	 * @return sucess
	 */
	public long insertTageseinheiten(UserDTO user, TageseinheitenDTO tageseinheiten) throws SQLException {
				
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(TageseinheitenTbl.STMT_INSERT_TAGESEINHEITEN);
		long rowId = -1;
		db.beginTransaction();
		try {
			
			statement.bindLong(1, user._id);			
			statement.bindLong(2, tageseinheiten.added_on.getTime());
			statement.bindLong(3, tageseinheiten.tageseinheiten);
			rowId = statement.executeInsert();
			db.setTransactionSuccessful();			
		} catch (Throwable ex) {
		
		Log.e(CLAZZ_NAME, ex.getMessage());
		} finally {
		
			db.endTransaction();		
		}
		
		return rowId;
	}
	
	
	public UserDTO loginUser(UserDTO user) throws SQLException {
		
		String[] param = {
				user.email
				};
		Cursor cursor = getReadableDatabase().rawQuery(UserTbl.STMT_USER_BY_EMAIL, param);
		if (cursor.getCount() == 1) {
			
			cursor.moveToFirst();
			return new UserDTO(cursor);
		} return null;
	}
	
	
	public long insertBodyweight(BodyweightDTO bodyweightDTO) throws SQLException {
		
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(BodyweightTbl.STMT_INSERT_BODYWEIGHT);
		long rowID = -1;
		db.beginTransaction();
		try {
			
			statement.bindLong(1, bodyweightDTO.u_id);
			statement.bindLong(2, bodyweightDTO.added_on.getTime());
			statement.bindDouble(3, bodyweightDTO.weight);
			statement.bindString(4, bodyweightDTO.unit);
			
			String devName = bodyweightDTO.devicename;			
			if (null != devName)
				
				statement.bindString(5, devName);
			else 
				
				statement.bindString(5, "unknow");
			
			rowID = statement.executeInsert();
			db.setTransactionSuccessful();
		} catch(Throwable ex) {
			
			Log.d(CLAZZ_NAME, "Fehler beim einfuegen von Bodyweight result: " + ex.getMessage());
		} finally {
			
			db.endTransaction();
		}	
				
		return rowID;
	}
	
	
	public long insertBloodpressure(BloodpressureDTO bloodpressure) throws SQLException {
		
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(BloodpressureTbl.STMT_INSERT_BLOODPRESSURE);
		long rowID = -1;
		db.beginTransaction();
		try {
			
			statement.bindLong(1, bloodpressure.u_id);
			statement.bindLong(2, bloodpressure.added_on.getTime());
			statement.bindLong(3, bloodpressure.diastolic);
			statement.bindLong(4, bloodpressure.systolic);
			statement.bindLong(5, bloodpressure.pulse);
			statement.bindLong(6, bloodpressure.sync);
			
			String devName = bloodpressure.devicename;
			if (null != devName)
				
				statement.bindString(7, bloodpressure.devicename);
			else 
				
				statement.bindString(7, "unknow");
			
			rowID = statement.executeInsert();
			db.setTransactionSuccessful();
		} catch(Throwable ex) {
			
			Log.d(CLAZZ_NAME, "Fehler beim einfuegen von Bloodpressure result: " + ex.getMessage());
		} finally {
			
			db.endTransaction();
		}	
				
		return rowID;
	}
	
	
	public long insertBloodpressure(UserDTO user, List<BloodpressureResult> bloodpressureList) throws SQLException {
		
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(BloodpressureTbl.STMT_INSERT_BLOODPRESSURE);
		long rowID = -1;
		db.beginTransaction();
		try {
			
			for (BloodpressureResult e: bloodpressureList) {
				
				statement.bindLong(1, user._id);
				statement.bindLong(2, e.getRecordDate().getTime());
				statement.bindLong(3, e.getDiastolic());
				statement.bindLong(4, e.getSystolic());
				statement.bindLong(5, e.getPulse());
				statement.bindLong(6, 0);
				statement.bindString(7, e.getDeviceName());
				rowID = statement.executeInsert();
			}
			
			db.setTransactionSuccessful();
		} catch(Throwable ex) {
			
			Log.d(CLAZZ_NAME, "Fehler beim einfuegen von Bloodpressure result: " + ex.getMessage());
		} finally {
			
			db.endTransaction();
		}	
				
		return rowID;
	}
	
	
	public Cursor initBodyweight(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(BodyweightTbl.STMT_INIT_BODYWEIGHT_LIST, param);
		return cursor;
	}
	
	
	public Cursor initBloodpressure(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(BloodpressureTbl.STMT_INIT_BLOODPRESSURE_LIST, param);
		return cursor;
	}
	
	
	public Cursor initMealenergy(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(MealenergyTbl.STMT_INIT_MEALENERGY_LIST, param);
		return cursor;
	}
	
	
	public Cursor initMealenergyContent(long id) throws SQLException {
		
		String[] param = {
				Integer.toString( (int)id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(MealenergyContentTbl.STMT_INIT_MEALENERGY_CONTENT_LIST, param);
		return cursor;
	}
	
	
	public Cursor synchronizeBodyweight(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(BodyweightTbl.STMT_SYNCHRONIZE_BODYWEIGHT, param);
		return cursor;
	}
	
	
	public Cursor synchronizeBloodpressure(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(BloodpressureTbl.STMT_SYNCHRONIZE_BLOODPRESSURE, param);
		return cursor;
	}
	
	
	public Cursor synchronizeMealenergy(UserDTO user) throws SQLException {
		
		String[] param = {
				Integer.toString( (int) user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(MealenergyTbl.STMT_SYNCHRONIZE_MEALENERGY, param);
		return cursor;
	}
	
	
	public void confirmSynchronizeBodyweight(int ids[]) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(BodyweightTbl.SYNC, 1);
		
		for (int i = 0; i<ids.length; i++) {
			
			db.update(BodyweightTbl.TABLE_NAME, values, BodyweightTbl._ID + "=" + ids[i], null);			
		}
		Log.d(CLAZZ_NAME, "updating sync");
		
		
	}
	
	
	public void confirmSynchronizeBloodpressure(int ids[]) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(BloodpressureTbl.SYNC, 1);
		
		for (int i = 0; i<ids.length; i++) {
			
			db.update(BloodpressureTbl.TABLE_NAME, values, BloodpressureTbl._ID + "=" + ids[i], null);			
		}
		Log.d(CLAZZ_NAME, "updating sync");
	}
	
	
	public void confirmMealenergy(int ids[]) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(MealenergyTbl.SYNC, 1);
		
		int rows = 0;
		for (int i = 0; i<ids.length; i++) {
			
			
			rows = db.update(MealenergyTbl.TABLE_NAME, values, MealenergyTbl._ID + "=" + ids[i], null);
			Log.d(CLAZZ_NAME, "updating Mealenergy sync: " + rows + " id: " + ids[i]);			
		}
		
	}
	
	
	public void confirmMealenergyContent(int ids[]) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(MealenergyContentTbl.SYNC, 1);
		
		int rows = 0;
		for (int i = 0; i<ids.length; i++) {
			
			rows = db.update(MealenergyContentTbl.TABLE_NAME, values, MealenergyContentTbl._ID + "=" + ids[i], null);
			Log.d(CLAZZ_NAME, "updating MealenergyContent sync: " + rows + " id: " + ids[i]);			
		}
		
	}
	
	
	public TageseinheitenDTO currentTageseinheiten(UserDTO user) {
				
		String[] param = {
				Long.toString(user._id)
				};
		Cursor cursor = getReadableDatabase().rawQuery(TageseinheitenTbl.STMT_CURRENT_TAGESEINHEITEN, param);
		if (cursor.getCount() == 1) {
			
			cursor.moveToFirst();
			return new TageseinheitenDTO(cursor);
		} return null;
	}
	
	
	public Cursor dayMealList(UserDTO user) {
		
		Calendar cal=Calendar.getInstance();
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		Date startOfDay = cal.getTime();
		String dayStart = Long.toString(startOfDay.getTime());
		cal.add(Calendar.DAY_OF_MONTH, +1);
		Date afterDate = cal.getTime();
		String after = Long.toString(afterDate.getTime());	
		
		String[] param = {
							
				dayStart, 
				after,
				Long.toString(user._id)
		};
		
		Log.d(CLAZZ_NAME, "datums: " + dayStart.toString() + ", " + after.toString());
		
		Cursor cursor = getReadableDatabase().rawQuery(MealenergyTbl.STMT_MEALENERGY_OF_TODAY, param);
		
		if (cursor.getCount() > 0) {			
			
				return cursor;			
		}
		
		return null;		
	}
	
	
	public Cursor mealenergyContent(long id) {
		
		String[] param = { Long.toString(id)};
		Cursor cursor = getReadableDatabase().rawQuery(MealenergyContentTbl.STMT_MEALENERGY_CONTENT, param);
		return cursor;
	}
	
	
	public FoodDTO getFood(String barcode) {
				
		String[] param = {
				barcode
				};
		Cursor cursor = getReadableDatabase().rawQuery(FoodTbl.STMT_GET_FOOD, param);
		if (cursor.getCount() == 1) {
			
			cursor.moveToFirst();
			return new FoodDTO(cursor);
		} 
		
		return null;
	}
	
	
	public long insertFood(FoodDTO food) throws SQLException {
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(FoodTbl.STMT_INSERT_FOOD);
		long rowId = -1;
		db.beginTransaction();
		try {
			
			statement.bindString(1, food.barcode);			
			statement.bindString(2, food.markenname);
			statement.bindString(3, food.produkt);
			statement.bindLong(4, food.energie_p100g);
			rowId = statement.executeInsert();
			db.setTransactionSuccessful();			
		} catch (Throwable ex) {
		
		Log.e(CLAZZ_NAME, ex.getMessage());
		} finally {
		
			db.endTransaction();		
		}
		
		return rowId;
	}
	
	
	public long insertMealenergy(MealenergyDTO meal) {
				
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(MealenergyTbl.STMT_INSERT_MEAL);
		long rowId = -1;
		db.beginTransaction();
		try {
			
			statement.bindLong(1, meal.u_id);			
			statement.bindLong(2, meal.added_on.getTime());
			
			rowId = statement.executeInsert();
			db.setTransactionSuccessful();			
		} catch (Throwable ex) {
		
		Log.e(CLAZZ_NAME, ex.getMessage());
		} finally {
		
			db.endTransaction();		
		}
		
		return rowId;
	}
	
	
	public long insertMealenergyContent(MealenergyContentDTO mealContent) {
		
		SQLiteDatabase db = getWritableDatabase();
		SQLiteStatement statement = db.compileStatement(MealenergyContentTbl.STMT_INSERT_MEALCONTENT);
		long rowId = -1;
		db.beginTransaction();
		try {
			
			statement.bindLong(1, 	mealContent.meal_id);			
			statement.bindString(2, mealContent.barcode);
			statement.bindLong(3, 	mealContent.energie_kcal);			
			statement.bindDouble(4, mealContent.weight);
			
			rowId = statement.executeInsert();
			db.setTransactionSuccessful();			
		} catch (Throwable ex) {
		
		Log.e(CLAZZ_NAME, ex.getMessage());
		} finally {
		
			db.endTransaction();		
		}
		
		return rowId;
	}
	

}
