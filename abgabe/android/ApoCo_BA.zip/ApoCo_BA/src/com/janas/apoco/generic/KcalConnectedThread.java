package com.janas.apoco.generic;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.tools.HexConverter;

public class KcalConnectedThread implements Runnable, AccessableIF {

	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = KcalConnectedThread.class.getSimpleName();
	
	
	private Thread mThread = null;
	private Handler mHandler;
	private BluetoothSocket mBluetoothSocket;
	private InputStream mInputStream;	
	private OutputStream mOutputStream;
	
	
	public KcalConnectedThread(Handler pHandler, BluetoothSocket pSocket) throws IOException {
		
		
		mHandler = pHandler;
		mBluetoothSocket = pSocket;
		try {
			
			Log.d(CLAZZ_NAME, "try get Streams");
			mInputStream = mBluetoothSocket.getInputStream();
			mOutputStream = mBluetoothSocket.getOutputStream();
		} catch (IOException e) {
			
			cancel();
		}
		Log.d(CLAZZ_NAME, "got Streams");
	}
	
	@Override
	public void run() {
		
		String deviceName = mBluetoothSocket.getRemoteDevice().getName();
		mHandler.obtainMessage(HandlerMessagesIF.CONNECTED_TO, "connected to : " + deviceName).sendToTarget();
		
		byte[] buffer = new byte[64];
        int bytes = 0;     
        while (null != mThread) {
        	
            try {
            	
                bytes = mInputStream.read(buffer);   
                byte[] bufferTrimmed = new byte[bytes];
				System.arraycopy( buffer, 0, bufferTrimmed, 0, bytes);
                
                mHandler.obtainMessage(HandlerMessagesIF.READ, bytes, -1, bufferTrimmed).sendToTarget();
                Log.d(CLAZZ_NAME, "read " + bytes + " bytes ," + new String(bufferTrimmed)); //HexConverter.hexBytesToString(buffer, bytes
            } catch (IOException e) {
            	
            	Log.d(CLAZZ_NAME, "IOException: " + e.getMessage());
            	cancel();
            	mHandler.obtainMessage(HandlerMessagesIF.INTERRUPTED_BY_EXCEPTION).sendToTarget();
                break;
            }
        }
        if (DEBUG) Log.d(CLAZZ_NAME, "interrupted");
	}
	
	@Override
	public synchronized void writeTo(byte[] msg) {
    	
    	try {
    		
			mOutputStream.write(msg);
		} catch (IOException e) {
			
			e.printStackTrace();
//			cancel();
		}
    }
	
	@Override
	public synchronized void cancel() {
		
		try {
			
			if (DEBUG) Log.d(CLAZZ_NAME, "try to close");
			mBluetoothSocket.close();
			if (DEBUG) Log.d(CLAZZ_NAME, "closed");
			performInterrupt();
		} catch (IOException e) {
			
		}
	}
	
	@Override
	public synchronized void performStart() {
    	
    	if (null == mThread) {
    		
    		mThread = new Thread(this);
    		mThread.start();
    	}
    }
    
    
    public synchronized void performInterrupt() {
    	
    	
    	if (null != mThread) {
    		
    		mThread.interrupt();
    	}
    }

}
