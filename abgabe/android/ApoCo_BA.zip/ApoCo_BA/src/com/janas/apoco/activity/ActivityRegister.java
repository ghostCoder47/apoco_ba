package com.janas.apoco.activity;


import java.util.StringTokenizer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.RegisterNewUser;
import com.janas.apoco.tools.PasswordCheck;
import com.janas.apoco.tools.Toasting;

public class ActivityRegister extends Activity {
	
	
	public static final String CLAZZ_NAME = ActivityRegister.class.getSimpleName();
	public static final int CLEAR_PASSWORD = 0x0;
	public static final int REGISTER_USER_SUCCESSFUL = 0x1;
	
	
	private Button mRegisterBtn, mBackBtn, mServerOptionsBtn;
	private TextView mLinkToLogin;
	private EditText mFullNameET, mEmailET, mPasswordET, mConfirmPasswordET;
	private Handler mNetworkHandler, mHandler;
	private DBManagerLocal mDBManager;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_register);
		
		
		setupRegisterBtn();
		setupFullNameET();
		setupEmailET();
		setupPassworET();
		setupConfirmPasswordET();
		setupLoginLink();
		setupBackBtn();
		setupServerOptionsBtn();
		setupNetworkHandler();
		setupHandler();
		setuptDBManager();
		
	}
	
	
	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}
	
	
	private void setuptDBManager() {
		
		mDBManager = new DBManagerLocal(getApplicationContext());
	}
	

	private void setupHandler() {
		
		mHandler = new Handler() {
			
			
			@Override
			public void handleMessage(Message msg) {
				

				//registerUserLocal();
//				Intent loginScreen = new Intent(RegisterActivity.this, LoginActivity.class);
//				startActivity(loginScreen);
				switch (msg.what) {
				
				case CLEAR_PASSWORD:
					
					break;
					
					
				case REGISTER_USER_SUCCESSFUL:
					
					UserDTO user = (UserDTO) msg.obj;
					long row_id = mDBManager.registerUser(user);
					Toasting.inScreenCenter(ActivityRegister.this, user.getVorname() + " you can Login now" + row_id);				
					finish();
					overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
					break;					
					
				}
				
			}
		};
	}

	private void setupConfirmPasswordET() {
		
		mConfirmPasswordET = (EditText) findViewById(R.id.confirmPasswordET);
	}

	private void setupPassworET() {
		
		mPasswordET = (EditText) findViewById(R.id.passwordET);
	}

	private void setupEmailET() {
		
		mEmailET = (EditText) findViewById(R.id.emailET);
	}

	private void setupFullNameET() {
		
		mFullNameET = (EditText) findViewById(R.id.fullNameET);
	}
	
	
	private void setupNetworkHandler() {
		
		mNetworkHandler = new NetworkHandler(ActivityRegister.this, true);		
	}



	private void setupServerOptionsBtn() {
		
		mServerOptionsBtn = (Button) findViewById(R.id.btnServerTools);
		mServerOptionsBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lServerOptions = new Intent(getApplicationContext(), ActivityServerOptions.class);
				startActivity(lServerOptions);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);				
			}
		});
	}


	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				finish();
				overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
			}
		});
		
	}


	private void setupRegisterBtn() {
		
		mRegisterBtn = (Button) findViewById(R.id.btnRegister);
		mRegisterBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				if (!checkUserInputData()) return;
				
				int id = -1;
				
				StringTokenizer st = new StringTokenizer(mFullNameET.getText().toString());
				String vorname = st.nextToken();
				String nachname = st.nextToken();
				String email = mEmailET.getText().toString();
				String password = mPasswordET.getText().toString();
				
				UserDTO user = new UserDTO(id, vorname, nachname, email, password);
				new RegisterNewUser(ActivityRegister.this, mNetworkHandler, mHandler).execute(user);
				
			}
		});
	}
	
	
	private boolean checkUserInputData() {
		
		
		String fn = mFullNameET.getText().toString();
		String em = mEmailET.getText().toString();
		String pw = mPasswordET.getText().toString();
		String cp = mConfirmPasswordET.getText().toString();
		
		
		StringTokenizer st = new StringTokenizer(fn);
		if (st.countTokens() != 2) {
			
			
			mFullNameET.requestFocus();
			mFullNameET.setText("");
			mFullNameET.setHint(fn);
			mFullNameET.setError("Ungültige Namenseingabe");
			return false;
			
		} else if (!em.contains("@") || !em.contains(".")) {
			
			
			mEmailET.requestFocus();
			mEmailET.setText("");
			mEmailET.setHint(em);
			mEmailET.setError("ungültige Email");
			return false;
			
		} else if (!new PasswordCheck().correctPassword(pw, cp)) {
			
			
			mPasswordET.requestFocus();
			mPasswordET.setText("");
			mPasswordET.setHint("password");
			
			mConfirmPasswordET.setText("");
			mConfirmPasswordET.setHint("confirm password");
			mConfirmPasswordET.setError("Email und Bestätigung stimmen nicht überein");
			return false;
			
		}
		return true;
	}


	private void setupLoginLink() {
		
		mLinkToLogin = (TextView) findViewById(R.id.link_to_login);
		mLinkToLogin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				finish();
				overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
			}
		});
	}


	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}

}
