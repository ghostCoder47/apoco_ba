package com.janas.apoco.arrayadapter;

import java.util.ArrayList;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.arrayadapter.model.MealModel;

public class MealenergyAdapter extends BaseAdapter {

	private ArrayList<MealModel> mData;
	private LayoutInflater mInflater;
	
	
	public MealenergyAdapter(Activity pContext, ArrayList<MealModel> pData) {
		
		mInflater = LayoutInflater.from(pContext);
		mData = pData;		
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View rowView = convertView;
		ViewContainer viewContainer;
		if (null == rowView) {
		
			rowView = mInflater.inflate(R.layout.mealenergy_entry, null);
			
			viewContainer = new ViewContainer();
			
			viewContainer.mTimestamp = (TextView) rowView.findViewById(R.id.datum);
			viewContainer.mEnergie = (TextView) rowView.findViewById(R.id.energie);
			
			rowView.setTag(viewContainer);
			
		} else {
			
			viewContainer = (ViewContainer) rowView.getTag();
		}
				
		MealModel mm = mData.get(position);
			
		viewContainer.mTimestamp.setText(mm.added_on);
		viewContainer.mEnergie.setText(mm.energie);
		
		
		return rowView;
	}
	
	
	public void add(MealModel mm) {
		
		mData.add(0, mm);
		notifyDataSetChanged();
	}
	
	
//	public void add(Object bwdto) {
//		
//		MealModel mm = MealModel.convertDTO_to_MODEL(bwdto);
//		add(mm);
//	}
	
	
	static class ViewContainer {
		
		public TextView mTimestamp;
		public TextView mEnergie;
	}


	@Override
	public int getCount() {
		
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		
		return position;
	}

}
