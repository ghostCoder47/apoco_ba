package com.janas.apoco.bodytel;

import java.util.Arrays;
import java.util.List;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.janas.apoco.activity.interfaces.WriteToPerformableIF;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.tools.HexConverter;

public class PressureTelMessageReader {

	private static final boolean DEBUG = true;
	private static final String CLAZZ_NAME = PressureTelMessageReader.class.getSimpleName();
	
	
	private Handler mHandler;
	private WriteToPerformableIF mWriter;
	private StringBuilder mHexString;
	private int mReadedBytes;
	private int mSMSLength = 0;
	private boolean searchForSMSLength = false;
	private StringBuilder mMessageLengthSB = new StringBuilder();
	private boolean mReadSMSLength = false;
	
	
	public PressureTelMessageReader(Handler pHandler, WriteToPerformableIF pWriter) {
		
		mHandler = pHandler;
		mWriter = pWriter;
		mHexString = new StringBuilder();
	}
	
	
	public String readMessage(Message pMsg) {
		
		byte[] hexBytes = (byte[]) pMsg.obj;		
		int size = pMsg.arg1;
		mReadedBytes += size;
		
		String hexString = new String(hexBytes);
		mHexString.append(hexString);
		Log.d(CLAZZ_NAME, "read: " + hexString);
		
		if (Arrays.equals(hexBytes, PressureTelMessageProtocol.IDENT_PACKET)) {
						
			mWriter.performWriteTo(PressureTelMessageProtocol.IDENT_ACK);
//			Message lAnswear = new Message();
//			lAnswear.what = HandlerMessagesIF.WRITE;
//			lAnswear.obj = PressureTelMessageProtocol.IDENT_ACK;
//			mHandler.sendMessage(lAnswear);
			Log.d(CLAZZ_NAME, "write: " + new String(PressureTelMessageProtocol.IDENT_ACK));	
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			return HexConverter.hexBytesToString(PressureTelMessageProtocol.IDENT_ACK, PressureTelMessageProtocol.IDENT_ACK.length);
			
		} else if (Arrays.equals(hexBytes, PressureTelMessageProtocol.END_OF_SMS)) {
			
			mWriter.performWriteTo(PressureTelMessageProtocol.END_OF_SMS_ACK);
			Log.d(CLAZZ_NAME, "write: " + new String(PressureTelMessageProtocol.END_OF_SMS_ACK));
			
			//decode message
			List<BloodpressureResult> resultList = new PressureTelMeasurementDecoder().decodeMeasurement(mHexString.toString());
			//Message.obtain
			Message resultMessage = new Message();
			resultMessage.what = HandlerMessagesIF.MEASUREMENT_FINISH;
			resultMessage.obj = resultList;
			mHandler.sendMessage(resultMessage);	
			
			
			mHexString.delete(0, mHexString.length());
			mReadedBytes = 0;
			return HexConverter.hexBytesToString(PressureTelMessageProtocol.IDENT_ACK, PressureTelMessageProtocol.IDENT_ACK.length);
		} else {
			
			if (Arrays.equals(hexBytes, PressureTelMessageProtocol.SMS_HEAD)) {
				
				mReadSMSLength = true;
				mHexString.delete(0, mHexString.length());
				mReadedBytes = 0;
			} else if (mReadSMSLength) {
				
				for(int i = 0; i<mReadedBytes; i++) {
					
					if (Character.isDigit(hexString.charAt(i))) {
						
						mMessageLengthSB.append(hexString.substring(i, i+1));
					} else {
						
						mHexString.delete(0, mHexString.length());
						mReadedBytes = 0;
						mReadSMSLength = false;
						Log.d(CLAZZ_NAME, "sms length: " + mMessageLengthSB.toString());
					}
				}
				mSMSLength = Integer.valueOf(mMessageLengthSB.toString());
			} else if (Arrays.equals(hexBytes, "\r".getBytes())) {
				
				mHexString.delete(mReadedBytes, mReadedBytes + 1);
				mReadedBytes--;
			}
			
		}
		
		
		return "not ready";
		
	}	

	
	public void resetAll() {
		
		
	}

}
