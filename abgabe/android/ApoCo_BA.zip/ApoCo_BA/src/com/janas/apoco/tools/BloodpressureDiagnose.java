package com.janas.apoco.tools;

import com.janas.apoco.arrayadapter.model.BloodpressureModel;

public final class BloodpressureDiagnose {
	
	
	enum Diagnose {
		
		OPTIMAL,
		NORMAL,
		HOCHNORMAL,
		HYPERTONIE_GRAD1,
		HYPERTONIE_GRAD2,
		HYPERTONIE_GRAD3,
		ISOLIERTE_SYSTOLISCHE_HYPERTONIE
	}	
	
	
	public static String performDiagnose(BloodpressureModel model) {
		
		Diagnose diagnose = Diagnose.OPTIMAL;
		
		
		int diastolic = Integer.parseInt(model.diastolic);
		int systolic = Integer.parseInt(model.systolic);
		if (diastolic < 85) diagnose = Diagnose.OPTIMAL;
		else if (diastolic < 85) diagnose = Diagnose.NORMAL;
		else if (diastolic < 90) diagnose = Diagnose.HOCHNORMAL;
		else if (diastolic < 100) diagnose = Diagnose.HYPERTONIE_GRAD1;
		else if (diastolic < 110) diagnose = Diagnose.HYPERTONIE_GRAD2;
		else if (diastolic >= 110) diagnose = Diagnose.HYPERTONIE_GRAD3;
		
		if (systolic < 120) diagnose = Diagnose.OPTIMAL;
		else if (systolic < 130) diagnose = Diagnose.NORMAL;
		else if (systolic < 140) diagnose = Diagnose.HOCHNORMAL;
		else if (systolic >= 140 && diastolic < 90) diagnose = Diagnose.ISOLIERTE_SYSTOLISCHE_HYPERTONIE;
		else if (systolic < 160) diagnose = Diagnose.HYPERTONIE_GRAD1;
		else if (systolic < 180) diagnose = Diagnose.HYPERTONIE_GRAD3;
		else if (systolic >= 180) diagnose = Diagnose.HYPERTONIE_GRAD3;
		
		switch (diagnose) {
		
		case OPTIMAL:
			
			return "Blutdruck:\nOptimal";
		case NORMAL:
			
			return "Blutdruck:\nNormal";
		case HOCHNORMAL:
			
			return "Blutdruck:\nHochnormal";
		case HYPERTONIE_GRAD1:
			
			return "Blutdruck:\nHypertonie Grad 1";
		case HYPERTONIE_GRAD2:
			
			return "Blutdruck:\nHypertonie Grad 2";
		case HYPERTONIE_GRAD3:
			
			return "Blutdruck:\nHypertonie Grad 3";
		case ISOLIERTE_SYSTOLISCHE_HYPERTONIE:
			
			return "Blutdruck:\nIsolierte-Systolische Hypertonie";
		}
		
		return "";
	}

}
