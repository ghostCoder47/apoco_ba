package com.janas.apoco.bodytel;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.tools.HexConverter;

public class PressureTelConnectedThread implements Runnable, AccessableIF {	
	
	
	public static final boolean DEBUG = false;
	public static final String CLAZZ_NAME = PressureTelConnectedThread.class.getSimpleName();
	
	
	private Thread mThread = null;
	private Handler mHandler;
	private BluetoothSocket mBluetoothSocket;
	private InputStream mInputStream;
	private OutputStream mOutputStream;

	
	public PressureTelConnectedThread(Handler pHandler, BluetoothSocket pSocket) throws IOException {
		
		
		mHandler = pHandler;
		mBluetoothSocket = pSocket;
		try {
			
			Log.d(CLAZZ_NAME, "try get Streams");
			mInputStream = mBluetoothSocket.getInputStream();
			mOutputStream = mBluetoothSocket.getOutputStream();
		} catch (IOException e) {
			
			cancel();
		}
		Log.d(CLAZZ_NAME, "got Streams");
	}
	
	@Override
	public void run() {
		
		byte[] buffer = new byte[64];
        int bytes = 0;     
        while (null != mThread) {
        	
            try {
            	
                bytes = mInputStream.read(buffer);   
                byte[] sendMe = new byte[bytes];
                System.arraycopy(buffer, 0, sendMe, 0, bytes);
                
                mHandler.obtainMessage(HandlerMessagesIF.READ, bytes, -1, sendMe).sendToTarget();
                if (DEBUG) Log.d(CLAZZ_NAME, "read " + bytes + " bytes ," + new String(sendMe));
            } catch (IOException e) {
            	
            	cancel();
                break;
            }
        }
	}
	
	@Override
	public synchronized void writeTo(byte[] pMsg) {
		
 	try {
    		
			mOutputStream.write(pMsg);
		} catch (IOException e) {
			
			e.printStackTrace();
//			cancel();
		}
	}

	@Override
	public synchronized void performStart() {
		
		if (null == mThread) {
    		
    		mThread = new Thread(this);
    		mThread.start();
    	}
	}

	@Override
	public synchronized void cancel() {
		
		try {
			
			if (DEBUG) Log.d(CLAZZ_NAME, "try to close");
			mBluetoothSocket.close();
			if (DEBUG) Log.d(CLAZZ_NAME, "closed");
			performInterrupt();
		} catch (IOException e) {
			
		}
	}

	
	
	
	public void performInterrupt() {
		
		if (null != mThread) {
    		
    		mThread.interrupt();
    	}
	}

}
