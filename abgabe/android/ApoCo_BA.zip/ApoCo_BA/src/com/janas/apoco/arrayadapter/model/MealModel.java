package com.janas.apoco.arrayadapter.model;

import java.text.SimpleDateFormat;
import java.util.Locale;

import com.janas.apoco.database.local.dto.MealenergyContentDTO;
import com.janas.apoco.database.local.dto.MealenergyDTO;
import com.janas.apoco.tools.DateTemplateIF;


public class MealModel {

	
	public static final String CLAZZ_NAME = MealModel.class.getSimpleName();
	
	public long mealId;
	public String added_on;
	public String energie;
	
	
	public static MealModel convertDTO_to_MODEL(MealenergyDTO mealenergy, int energySum) {
		
		MealModel mm = new MealModel();
		
		mm.mealId = mealenergy._id;		
		SimpleDateFormat formatter = new SimpleDateFormat(DateTemplateIF.TIMESTAMP_TEMPLATE, Locale.getDefault());	    
	    mm.added_on = formatter.format(mealenergy.added_on);
		mm.energie = Integer.toString(energySum);
		
		return mm;
	}
	
	
}
