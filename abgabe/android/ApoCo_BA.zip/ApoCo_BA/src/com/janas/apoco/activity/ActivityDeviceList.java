package com.janas.apoco.activity;

import java.util.Set;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.tools.Toasting;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class ActivityDeviceList extends Activity {

	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = ActivityDeviceList.class.getSimpleName();
	
	
	private Button mScanBtn;
	private BluetoothAdapter mBluetoothAdapter;
	private ArrayAdapter<String> mPairedDeviceArrayAdapter, mNewDeviceArrayAdapter;
	private ListView mPairedDeviceLv, mNewDeviceLv; 
	private BroadcastReceiver mDiscoveryReceiver;
	private OnItemClickListener mOnItemClickListener;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_device_list);
		setProgressBarIndeterminateVisibility(false);
		setResult(RESULT_CANCELED);
		
		
		setupScanBtn();
		setupBluetoothAdapter();
		setupPairedDeviceAdapter();
		setupNewDeviceAdapter();
		setupOnItemClickListener();
		setupPairedListView();
		setupNewDeviceListView();
		setupDiscoveryReceiver();
		
	}
	

	private void setupOnItemClickListener() {
		
		mOnItemClickListener = new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> pParent, View pView, int pPosition, long pRowId) {
				
				mBluetoothAdapter.cancelDiscovery();
				Intent lResult = new Intent();
				String lInfo = ((TextView) pView).getText().toString();
				if (!lInfo.equals("no Device found") && !lInfo.equals("no pared device")) {
					
					String lAddress = lInfo.substring(lInfo.length() - 17);
					lResult.putExtra(ActivityExtrasCodesIF.EXTRA_DEVICE_ADDRESS, lAddress);
					setResult(RESULT_OK, lResult);
				} else {
					
					setResult(RESULT_CANCELED);
				}					
				finish();
				overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
			}
		};
	}


	@Override
	public void onDestroy() {
		
		super.onDestroy();
		if (mBluetoothAdapter != null) {
			
			mBluetoothAdapter.cancelDiscovery();
		}
		
		unregisterReceiver(mDiscoveryReceiver);
	}


	private void setupDiscoveryReceiver() {
		
		mDiscoveryReceiver = new BroadcastReceiver() {

			@Override
			public void onReceive(Context pContext, Intent pIntent) {
					
					
				String lAction = pIntent.getAction();
					
				if (BluetoothDevice.ACTION_FOUND.equals(lAction)) {
				
					BluetoothDevice lDevice = pIntent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
		            if (lDevice.getBondState() != BluetoothDevice.BOND_BONDED) {
		            	
		            	String lDeviceNameAndAddress = lDevice.getName() + "\n" + lDevice.getAddress();
		            	mNewDeviceArrayAdapter.add(lDeviceNameAndAddress);
		            }				
				} else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(lAction)) {
						
					setProgressBarIndeterminateVisibility(false);
			        setTitle("Select Device");
			        if (mNewDeviceArrayAdapter.getCount() == 0) {
			        	
			            String noDevices = "no Device found";
			            mNewDeviceArrayAdapter.add(noDevices);
			        }
				} else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(lAction)) {
					
					setProgressBarIndeterminateVisibility(true);
			        setTitle("Scanning");
			        Toasting.inScreenCenter(getApplicationContext(), "is discovering: " + mBluetoothAdapter.isDiscovering());
				}
			}			
		};
		
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
		filter.addAction(BluetoothDevice.ACTION_FOUND);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		registerReceiver(mDiscoveryReceiver, filter);		
	}


	private void setupPairedListView() {
		
		mPairedDeviceLv = (ListView) findViewById(R.id.pairedListView);
		mPairedDeviceLv.setAdapter(mPairedDeviceArrayAdapter);
		mPairedDeviceLv.setOnItemClickListener(mOnItemClickListener);
	}


	private void setupNewDeviceListView() {
		
		mNewDeviceLv = (ListView) findViewById(R.id.newDevicesListView);
		mNewDeviceLv.setAdapter(mNewDeviceArrayAdapter);
		mNewDeviceLv.setOnItemClickListener(mOnItemClickListener);
	}


	private void setupNewDeviceAdapter() {
		
		mNewDeviceArrayAdapter = new ArrayAdapter<String>(getBaseContext(), R.layout.device_entry);
	}


	private void setupPairedDeviceAdapter() {
		
		mPairedDeviceArrayAdapter = new ArrayAdapter<String>(getBaseContext(), R.layout.device_entry);
		Set<BluetoothDevice> lPairedDeviceSet = mBluetoothAdapter.getBondedDevices();
		if (lPairedDeviceSet.size() > 0 ) {
			
			for (BluetoothDevice device : lPairedDeviceSet) {
				
				mPairedDeviceArrayAdapter.add(device.getName() + "\n" + device.getAddress());
			}
		} else {
			
			String lNoDevice = "no pared device";
			mPairedDeviceArrayAdapter.add(lNoDevice);
		}
	}


	private void setupBluetoothAdapter() {
		
		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
	}


	private void setupScanBtn() {
		
		mScanBtn = (Button) findViewById(R.id.btnScanDevices);
		mScanBtn.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View view) {				
				
//				setProgressBarIndeterminateVisibility(true);
//		        setTitle("Scanning");
		        if (mBluetoothAdapter.isDiscovering()) mBluetoothAdapter.cancelDiscovery();
		        mBluetoothAdapter.startDiscovery();
//		        Toasting.inScreenCenter(getApplicationContext(), "is discovering: " + mBluetoothAdapter.isDiscovering());
			}
		});
	}	
	
	
}
