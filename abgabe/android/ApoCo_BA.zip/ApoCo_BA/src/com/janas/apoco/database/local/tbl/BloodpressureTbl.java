package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.BloodpressureColumns;
import com.janas.apoco.database.local.columns.UserColumns;

public class BloodpressureTbl implements BloodpressureColumns {

	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = BloodpressureTbl.class.getSimpleName();
	public static final String TABLE_NAME = "bloodpressure";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 			" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				U_ID + 			" INTEGER NOT NULL," + 
				ADDED_ON + 		" TIMESTAMP NOT NULL DEFAULT current_timestamp," + 
				DIASTOLIC + 	" INTEGER NOT NULL DEFAULT 0, " + 
				SYSTOLIC + 		" INTEGER NOT NULL DEFAULT 0, " +
				PULSE + 		" INTEGER NOT NULL DEFAULT 0, " +
				SYNC + 			" INTEGER NOT NULL DEFAULT 0, " +
				DEVICENAME + 	" TEXT," +
				"FOREIGN KEY(" + U_ID + ") REFERENCES " + UserTbl.TABLE_NAME + "(" + UserColumns._ID + ")" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_INIT_BLOODPRESSURE_LIST =
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + " = ?";
	
	
	public static final String STMT_INSERT_BLOODPRESSURE = 
			
			"INSERT INTO " + TABLE_NAME + "(" + 
			U_ID + "," + 
			ADDED_ON + ", " + 
			DIASTOLIC + ", " + 
			SYSTOLIC + ", " + 
			PULSE + ", " + 
			SYNC + ", " + 
			DEVICENAME + 
			") VALUES (?,?,?,?,?,?,?)";
	
	
	public static final String STMT_SYNCHRONIZE_BLOODPRESSURE =
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + " = ?" + 
			" AND " + SYNC + "= 0";
}
