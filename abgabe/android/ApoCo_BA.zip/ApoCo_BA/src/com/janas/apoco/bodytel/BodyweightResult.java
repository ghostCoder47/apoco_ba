package com.janas.apoco.bodytel;

import java.sql.Timestamp;

import android.util.Log;

import com.janas.apoco.tools.TimeTools;

public class BodyweightResult {
	
	
	public static final String CLAZZ_NAME = BodyweightResult.class.getSimpleName();

	private String mDeviceName;
	private Timestamp mRecordDate;
	private String mWeight;
	private String mUnit;
	
	
	public BodyweightResult() {
		
	}
	
	
	public BodyweightResult(double weightValue, String unit) throws IndexOutOfBoundsException {
	
		long time = System.currentTimeMillis();	
		mRecordDate = new Timestamp(time);
		mWeight = "" + weightValue;
		mUnit = unit;		
		Log.d(CLAZZ_NAME, this.toString());
	}
	
	
	public Timestamp getRecordDate() {
		
		return mRecordDate;
	}
	
	
	public void setRecordDate(Timestamp date) {
		
		mRecordDate = date;
	}


	public String getWeight() {
		
		return mWeight;
	}
	
	
	public void setWeight(String weight) {
		
		mWeight = weight;
	}


	public String getUnit() {
		return mUnit;
	}
	
	
	public void setUnit(String unit) {
		
		mUnit = unit;
	}

	
	public void setDeviceName(String pDeviceName) {
		
		mDeviceName = pDeviceName;
	}
	
	
	public String getDeviceName() {
		
		return mDeviceName;
	}


	@Override
	public String toString() {
		return "BodyweightResult [mDeviceName=" + mDeviceName
				+ ", mRecordDate=" + mRecordDate + ", mWeight=" + mWeight
				+ ", mUnit=" + mUnit + "]";
	}
	
	

}
