package com.janas.apoco.activity;

import java.io.IOException;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.bluetooth.BluetoothManager;
import com.janas.apoco.bluetooth.StandardUUIDsIF;
import com.janas.apoco.preferences.PreferencesManager;
import com.janas.apoco.tools.ResourcesTools;
import com.janas.apoco.tools.Toasting;

public class ActivityDevices extends Activity {
	
	
	public static final String CLAZZ_NAME = ActivityDevices.class.getSimpleName();
	
	
	private Button mStartBtn, mBackBtn, mPairingAsServerBtn, mPairingAsClientBtn, mCancelBtn, mDevicesBtn, mServerOptionsBtn;
	private RadioGroup mRadioDevices;
	private String mSelectedDevice = null;
	private BluetoothManager mBTManager;
	private BroadcastReceiver bcReceiver;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_devices);
		
		setupStartBtn();
		setupBackBtn();
		setupRadioDevices();
		setupPairingAsServerBtn();
		setupPairingAsClientBtn();	//update
		setupDevicesBtn();
		setupServerOptionsBtn();
		setupBTManager();
		setupBCReceiver();
		setuptSelectedDevice();
		setupCancelBtn();
		
		
	}	


	private void setupCancelBtn() {
		
		mCancelBtn = (Button) findViewById(R.id.btnCancel);
		mCancelBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				scanning(false);
				mBTManager.performDisableBluetooth();
				mBTManager.performEnableBluetooth();
			}
		});
	}


	private void setuptSelectedDevice() {
		
		int id = mRadioDevices.getCheckedRadioButtonId();
		mSelectedDevice = getResources().getResourceEntryName(id);
		Log.d(CLAZZ_NAME, "selected device id : " + mSelectedDevice);
	}
	

	private void setupBCReceiver() {
		
		bcReceiver = new BroadcastReceiver() {

			@Override
			public void onReceive(Context context, Intent intent) {
				
				String action = intent.getAction();
				
				if (action.equals(BluetoothDevice.ACTION_ACL_CONNECTED)) {
					
					BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
					boolean result = performUpdateDevice(device);					
				} else if (action.equals(BluetoothDevice.ACTION_ACL_DISCONNECTED)) {
					
					BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
					String name = device.getName();
					Log.d(CLAZZ_NAME, "Device try to disconnect: " + name);
				} else if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {
					
					int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);
					switch (mode) {
					
					
					case BluetoothAdapter.ERROR:
						break;
						
						
					case BluetoothAdapter.SCAN_MODE_NONE:
						
						Log.d(CLAZZ_NAME, "SCAN_MODE_NONE");
						scanning(false);
						break;
						
						
					case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
						
						Log.d(CLAZZ_NAME, "SCAN_MODE_CONNECTABLE");
						scanning(false);
						break;
						
						
					case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
						
						Log.d(CLAZZ_NAME, "SCAN_MODE_CONNECTABLE_DISCOVERABLE");
						scanning(true);
						break;
						
						
					}
				}
			}
			
			
		};		
	}
	

	@Override
	protected void onStart() {
		
		super.onStart();
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
		filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);	
		filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
		registerReceiver(bcReceiver, filter);
	}
	
	@Override
	protected void onStop() {
		
		super.onStop();
		mBTManager.onStop();
	}
	
	@Override
	protected void onDestroy() {
		
		super.onDestroy();
		unregisterReceiver(bcReceiver);
	}
	
	
	private void setupBTManager() {
		
		mBTManager = new BluetoothManager();
	}

	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		Log.d(CLAZZ_NAME, "onActivityResult: ");
		switch(requestCode) {
		
		case ActivityRequestCodesIF.REQUEST_BT_DISCOVERABLE:
			
			Log.d(CLAZZ_NAME, "REQUEST_BT_DISCOVERABLE");
			if (resultCode == Activity.RESULT_CANCELED) {
				
				Toasting.inScreenCenter(
						getApplicationContext(), 
						new ResourcesTools().getString(getApplicationContext(), 
								R.string.request_bt_canceled));
			} else {
				
				Log.d(CLAZZ_NAME, "mBTManager.startListening()");
			}
			break;	
			
			
		case ActivityRequestCodesIF.REQUEST_CONNECT_DEVICE:
			
			if (resultCode == RESULT_OK) {
				
				String lAddress = data.getExtras().getString(ActivityExtrasCodesIF.EXTRA_DEVICE_ADDRESS);
				Toasting.inScreenCenter(getApplicationContext(), "Adresse: " + lAddress);
				//device in preferences aufnähmen
				BluetoothDevice device = mBTManager.getRemotedDevice(lAddress);
				try {
					device.createRfcommSocketToServiceRecord(StandardUUIDsIF.SPP_1101);
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				boolean result = performUpdateDevice(device);
				Toasting.inScreenCenter(getApplicationContext(), "gerät aufgenomen: " + result);
			}			
			break;
			
		}
	}
	
	
	private void setupServerOptionsBtn() {
		
		mServerOptionsBtn = (Button) findViewById(R.id.btnServerOptions);
		mServerOptionsBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lServerOptions = new Intent(getApplicationContext(), ActivityServerOptions.class);
				startActivity(lServerOptions);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);				
			}
		});
	}   
	
	
	private void setupDevicesBtn() {
		
		ComponentName lComponent = getCallingActivity();
		String lClazzName = lComponent.getClassName();
		
		if (!lClazzName.contains("StartActivity")) {
			
			mDevicesBtn = (Button) findViewById(R.id.btnDevices);
			mDevicesBtn.setVisibility(View.GONE);
			return;
		}
		
	}
	

	private void setupPairingAsServerBtn() {
		
		mPairingAsServerBtn = (Button) findViewById(R.id.btnPairingAsServer);
		mPairingAsServerBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
//				mPairingAsServerBtn.setVisibility(View.GONE);
//				mPairingAsClientBtn.setVisibility(View.GONE);
//				mCancelBtn.setVisibility(View.VISIBLE);
				mBTManager.paringAsServer(ActivityDevices.this);				
			}
		});
	}
	
	
	private void setupPairingAsClientBtn() {
		
		mPairingAsClientBtn = (Button) findViewById(R.id.btnPairingAsClient);
		mPairingAsClientBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent selectDevice = new Intent(getApplicationContext(), ActivityDeviceList.class);
				startActivityForResult(selectDevice, ActivityRequestCodesIF.REQUEST_CONNECT_DEVICE);
				//startActivityForResult???
//				mBTManager.paringAsClient(pContext)				
			}
		});
	}
	

	private void setupRadioDevices() {
		
		mRadioDevices = (RadioGroup) findViewById(R.id.radioDevices);
		mRadioDevices.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				
				mSelectedDevice = getResources().getResourceEntryName(checkedId);
				Log.d(CLAZZ_NAME, "Selected Device changed: " + mSelectedDevice);
			}
			
			
		});
	}
	

	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}
	

	private void setupStartBtn() {
		
		mStartBtn = (Button) findViewById(R.id.btnStartTools);
		ComponentName lComponent = getCallingActivity();
		String lClazzName = lComponent.getClassName();
		
		if (!lClazzName.contains("StartActivity")) {
			
			mStartBtn.setVisibility(View.GONE);
			return;
		}
		
		mStartBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
		
	}
	
	
	private void scanning(boolean perform) {
		
		if (perform) {
			
			mRadioDevices.setVisibility(View.GONE);
			mPairingAsServerBtn.setVisibility(View.GONE);
			mPairingAsClientBtn.setVisibility(View.GONE);
			mCancelBtn.setVisibility(View.VISIBLE);
		} else {
			
			mRadioDevices.setVisibility(View.VISIBLE);
			mPairingAsServerBtn.setVisibility(View.VISIBLE);
			mPairingAsClientBtn.setVisibility(View.VISIBLE);
			mCancelBtn.setVisibility(View.GONE);
		}
	}
	
	
	private boolean performUpdateDevice(BluetoothDevice device) {
		
		String name = device.getName();
		String address = device.getAddress();
		PreferencesManager pm = new PreferencesManager(getApplicationContext());
		Log.d(CLAZZ_NAME, "Device try to pair: " + name + " " + address);
		return pm.updateDevice(mSelectedDevice, address, name);
	}
	

	@Override
	public void onBackPressed() {
		
		finish();
		overridePendingTransition(R.anim.up_side_in, R.anim.up_side_out);
	}

}
