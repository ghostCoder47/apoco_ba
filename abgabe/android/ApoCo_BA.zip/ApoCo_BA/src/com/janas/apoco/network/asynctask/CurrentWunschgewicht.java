package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityBodyweight;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.URLBuilder;



public class CurrentWunschgewicht extends AsyncTask<UserDTO, Void, String> {

	
	public static final String CLAZZ_NAME = CurrentWunschgewicht.class.getSimpleName();
	public static final int UPDATE_WUNSCHGEWICHT = 0x0;
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private UserDTO mUser;
//	private DBManagerLocal mDBManager;
	private boolean isNetworkConnected;
	
	public CurrentWunschgewicht(Context context, Handler netHandler,  Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = netHandler;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("aktualisiere Wunschgewicht...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
//		mDBManager = new DBManagerLocal(mContext);
	}

	
	@Override
	protected String doInBackground(UserDTO... pUser) {
		
		//netzwerk verfügbarkeit prüfen
		isNetworkConnected = new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet);		
		if (!isNetworkConnected) return null;
		
		mUser = pUser[0];
		
		if (null == mUser) return null;
		
		JSONObject user = mUser.toJSONObject();			
				
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(JSON_TAG_IF.USER, user.toString()));
				
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.CURRENT_WUNSCHGEWICHT);		
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);		
		
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
								
				JSONObject obj = jsonObject.getJSONObject(JSON_TAG_IF.WUNSCHGEWICHT);
				return obj.getString("wunschgewicht");
//				TageseinheitenDTO tageseinheiten = new TageseinheitenDTO(mUser, obj);
//				TageseinheitenDTO currentTageseinheiten = mDBManager.currentTageseinheiten(mUser);	
				
				
				
//				if (currentTageseinheiten.added_on.before(tageseinheiten.added_on)) {
//					
//					mDBManager.insertTageseinheiten(mUser, tageseinheiten);					
//					Log.d(CLAZZ_NAME, "insert current Tageseinheiten: " + tageseinheiten.toString());
//				}
				
//				mDBManager.closeDB();
				
			} else {
				
				return "--";
			}			
			
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
				
		
		return null;
	}
	

	@Override
	protected void onPostExecute(String result) {
		
		if (null == result) {
			
			mHandlerAct.obtainMessage(ActivityBodyweight.UPDATE_WUNSCHGEWICHT, "--").sendToTarget();
		} else {
			
			mHandlerAct.obtainMessage(ActivityBodyweight.UPDATE_WUNSCHGEWICHT, result).sendToTarget();
		}
		progressDialog.dismiss();
	}		
}
