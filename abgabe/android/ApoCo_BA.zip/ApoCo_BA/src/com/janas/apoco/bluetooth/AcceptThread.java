package com.janas.apoco.bluetooth;

import java.io.IOException;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.interfaces.AccessableCreatorIF;


public class AcceptThread implements Runnable, StartableCanceableIF {
    
	
	private final boolean DEBUG = true;
	private final String CLAZZ_NAME = AcceptThread.class.getSimpleName();
	
	
	
	private Thread mThread = null;
	private final BluetoothServerSocket mmServerSocket;
    private final Handler mHandler;
    private final BluetoothAdapter mBTAdapter;
    private final AccessableCreatorIF mCreator;
    private final UUID mUUID;
    private final String mSDPServiceName;
	
    public AcceptThread(Handler pHandler, BluetoothAdapter pBTAdapter, AccessableCreatorIF pCreator, UUID pUUID, String pSDPServiceName) {
    	
    	mHandler = pHandler;
    	mBTAdapter = pBTAdapter;
    	mCreator = pCreator;
    	mUUID = pUUID;
    	mSDPServiceName = pSDPServiceName;
    	
        BluetoothServerSocket tmp = null;
        try {
            	        	
            tmp = mBTAdapter.listenUsingRfcommWithServiceRecord(	//listenUsingInsecureRfcommWithServiceRecord(
            		mSDPServiceName,
            		mUUID
            		);
        } catch (IOException e) { }
        mmServerSocket = tmp;
        if (DEBUG) Log.d(CLAZZ_NAME, "got serverSocket");
    }

    public void run() {	    	
    	
    	Log.d(CLAZZ_NAME, "run()");
    	BluetoothSocket socket = null;
        while (null != mThread && !mThread.isInterrupted()) {
        	
        	if (DEBUG) Log.d(CLAZZ_NAME, "try to accept");
            try {
            	
                socket = mmServerSocket.accept();	                           
                if (DEBUG) Log.d(CLAZZ_NAME, "accepted");
                BluetoothDevice device = socket.getRemoteDevice();
                Log.d(CLAZZ_NAME, device.getName() + " " + device.getAddress());
            } catch (IOException e) {
            	
                break;
            }
            
            if (socket != null) {
                
            	if (DEBUG) Log.d(CLAZZ_NAME, "create accessable");
            	AccessableIF lAccessable = mCreator.createAccessable(mHandler, socket);
				mHandler.obtainMessage(HandlerMessagesIF.RECEIVING_ACCESSABLE, lAccessable).sendToTarget();         	
            }
            
        }
        Log.d(CLAZZ_NAME, "is interrupted");
        
    }

        
    public synchronized void cancel() {
    	
        try {
        	
        	if (DEBUG) Log.d(CLAZZ_NAME, "try to close");
            mmServerSocket.close();
            if (DEBUG) Log.d(CLAZZ_NAME, "closed");
            performInterrupt();
        } catch (IOException e) { }
    }
    
    
    public synchronized void performStart() {
    	
    	Log.d(CLAZZ_NAME, "performStart()");
    	if (mThread != null) {
			
			mThread.interrupt();
			mThread = null;
		}
    	mThread = new Thread(this);
    	mThread.start();    	
    }
    
    
    public void performInterrupt() {
    	    		
    	mThread.interrupt();
    	mThread = null;
    }
}