package com.janas.apoco.bodytel;

import java.sql.Timestamp;

import android.util.Log;

public class BloodpressureResult {
	

	public static final String CLAZZ_NAME = BloodpressureResult.class.getSimpleName();


	private String mDeviceName = "";
	private Timestamp mRecordDate;
	private int mSystolic;
	private int mDiastolic;
	private int mPulse;
	
	
	public BloodpressureResult() {
		
	}
	
	
	public BloodpressureResult(String hexSMS) throws IndexOutOfBoundsException {
		
		long time = PressureTelSMS.secSince01011997(hexSMS);
		mRecordDate = new Timestamp(time);
		int index = 8;
		mSystolic = Integer.valueOf(hexSMS.substring(index, index + 2), PressureTelSMS.RADIX_HEX) + 45; index += 2;
		mDiastolic = Integer.valueOf(hexSMS.substring(index, index + 2), PressureTelSMS.RADIX_HEX); index += 2;
		mPulse = Integer.valueOf(hexSMS.substring(index, index + 2), PressureTelSMS.RADIX_HEX);	
		
		Log.d(CLAZZ_NAME, this.toString());
	}
	

	public Timestamp getRecordDate() {
		
		return mRecordDate;
	}
	
	
	public void setRecordDate(Timestamp date) {
		
		this.mRecordDate = date;
	}
	

	public int getSystolic() {
		
		return mSystolic;
	}
	
	
	public void setSystolic(int systolic) {
		
		this.mSystolic = systolic;
	}
	

	public int getDiastolic() {
		
		return mDiastolic;
	}
	
	
	public void setDiastolic(int diastolic) {
		
		this.mDiastolic = diastolic;
	}
	

	public int getPulse() {
		
		return mPulse;
	}
	
	
	public void setPulse(int pulse) {
		
		this.mPulse = pulse;
	}
	
	
	public void setDeviceName(String pDeviceName) {
		
		mDeviceName = pDeviceName;
	}
	
	
	public String getDeviceName() {
		
		return mDeviceName;
	}


	@Override
	public String toString() {
		return "BloodpressureResult [mDeviceName=" + mDeviceName
				+ ", mRecordDate=" + mRecordDate + ", mSystolic=" + mSystolic
				+ ", mDiastolic=" + mDiastolic + ", mPulse=" + mPulse + "]";
	}

	
	

}
