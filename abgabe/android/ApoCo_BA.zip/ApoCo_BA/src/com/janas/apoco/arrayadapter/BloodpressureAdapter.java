package com.janas.apoco.arrayadapter;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.arrayadapter.model.BloodpressureModel;
import com.janas.apoco.bodytel.BloodpressureResult;
import com.janas.apoco.database.local.dto.BloodpressureDTO;

public class BloodpressureAdapter extends BaseAdapter {
	

	private ArrayList<BloodpressureModel> mData;
	private LayoutInflater mInflater;
	
	
	public BloodpressureAdapter(Activity pContext, ArrayList<BloodpressureModel> pData) {
		
		mInflater = LayoutInflater.from(pContext);
		mData = pData;		
	}
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		View rowView = convertView;
		ViewContainer viewContainer;
		if (null == rowView) {
		
			rowView = mInflater.inflate(R.layout.bloodpressure_entry, null);
			
			viewContainer 					= new ViewContainer();
			viewContainer.mTitle 			= (TextView) rowView.findViewById(R.id.title);
			viewContainer.mTimestamp 		= (TextView) rowView.findViewById(R.id.date);
			viewContainer.mBloodpressure 	= (TextView) rowView.findViewById(R.id.bloodpressureValues);
			viewContainer.mUnitBP			= (TextView) rowView.findViewById(R.id.unitBP);
			viewContainer.mPulse 			= (TextView) rowView.findViewById(R.id.pulseValue);
			viewContainer.mUnitP 			= (TextView) rowView.findViewById(R.id.unitP);
			
			rowView.setTag(viewContainer);
			
		} else {
			
			viewContainer = (ViewContainer) rowView.getTag();
		}
		
		viewContainer.mTitle.setText("Blutdruck & Puls");
		
		BloodpressureModel bpm = mData.get(position);
			
		viewContainer.mTimestamp.setText(bpm.added_on);
		viewContainer.mBloodpressure.setText(bpm.systolic + "/" + bpm.diastolic);
		viewContainer.mUnitBP.setText("mmHg");
		viewContainer.mPulse.setText("" + bpm.pulse);
		viewContainer.mUnitP.setText("bpm");
		
		
		return rowView;
	}
	
	
	public void add(BloodpressureModel bpm) {
		
		mData.add(0, bpm);
		notifyDataSetChanged();
	}
	
	
	public void add(BloodpressureDTO bpdto) {
		
		BloodpressureModel bpm = BloodpressureModel.convertDTO_to_MODEL(bpdto);
		add(bpm);
	}
	
	
	public void add(List<BloodpressureModel> bpmList) {
		
		for (BloodpressureModel e : bpmList) {
			
			add(e);
		}
	}
	
	
	static class ViewContainer {
		
		public TextView mTitle;
		public TextView mTimestamp;
		public TextView mBloodpressure;
		public TextView mUnitBP;
		public TextView mPulse;		
		public TextView mUnitP;
	}


	@Override
	public int getCount() {
		
		return mData.size();
	}
	

	@Override
	public Object getItem(int position) {
		
		return mData.get(position);
	}

	
	@Override
	public long getItemId(int position) {
		
		return position;
	}

}
