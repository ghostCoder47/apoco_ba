package com.janas.apoco.activity;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.R.anim;
import com.janas.apoco.R.id;
import com.janas.apoco.R.layout;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.BluetoothManager;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.bluetooth.StandardUUIDsIF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.database.local.dto.TageseinheitenDTO;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.generic.GenericCreator;
import com.janas.apoco.generic.KcalResult;
import com.janas.apoco.kern.KERN_PCB_MessageBuilder;
import com.janas.apoco.network.NetworkHandler;
import com.janas.apoco.network.asynctask.GetFood;
import com.janas.apoco.preferences.APOCO_PREFERENCES;
import com.janas.apoco.preferences.PreferencesManager;
import com.janas.apoco.tools.FloatPrecision;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.zxing.IntentIntegrator;
import com.janas.apoco.zxing.IntentResult;

public class ActivityFoodKcalNewEntry extends Activity {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME 	= ActivityFoodKcalNewEntry.class.getSimpleName();
	public static final int FOOD_SUCCESS 	= 0x0;
	public static final int FOOD_FAILED		= 0x1;
	
	
	private Button mOKBtn, mBarcodeBtn;
	private TextView mProduktTv, mMarkeTv, mGewichtTv, mEnergieTv, mGesEnergieTv, mFreieEinheitenTv, mConnectedInfoTv, mReconnectTv;
	private Handler mHandler;
	private AccessableIF mConnectedThread;
	private BluetoothManager mBTManager;
	private UserDTO mUser;
	private DBManagerLocal mDBManager;
	private TageseinheitenDTO mTageseinheiten;
	private int mFreieEinheiten, mGesammtenergie;
	
	private FoodDTO mFood;
	private float mFoodGewicht;
	private int mFoodEnergy;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		setContentView(R.layout.activity_foodkcal_new_entry);
		
		setupOKBtn();
		setupBarcodeBtn();
		setupProduktTv();
		setupMarkeTv();
		setupGewichtTv();
		setupEnergieTv();
		setupGesEnergieTv();
		setupFreieEinheitenTv();
		setupReconnectTv();
		setupConnectedInfo();
		setupHandler();
		setupBluetoothManager();
		setupDBManager();
		connectToDevice();	
		updateConnectedInfo("disconnected");
		initData();
	}
	
	
	@Override
	public void onDestroy() {
		
		
		super.onDestroy();		
	}
	
	
	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityFoodKcalNewEntry.this);
	}
	
	
	private void initData() {
		
		Intent extras = getIntent();
		mUser = (UserDTO) extras.getSerializableExtra(ActivityExtrasCodesIF.USER);	
		mTageseinheiten = (TageseinheitenDTO) extras.getSerializableExtra(ActivityExtrasCodesIF.TAGESEINHEITEN);
		mGesammtenergie = extras.getIntExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, 0);
		
		updateGesammtenergie();
		updateFreieEinheiten();
	}


	private void setupReconnectTv() {
		
		mReconnectTv = (TextView) findViewById(R.id.reconnectTV);
		mReconnectTv.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				connectToDevice();
				mReconnectTv.setVisibility(View.INVISIBLE);
			}
		});
	}


	private void setupConnectedInfo() {
		
		mConnectedInfoTv = (TextView) findViewById(R.id.connectedInfo);
	}


	private void setupBluetoothManager() {
		
		mBTManager = new BluetoothManager();
	}


	@Override
	protected synchronized void onStart() {
		
		super.onStart();		
		Log.d(CLAZZ_NAME, "onStart()");
	}
	
	
	private void connectToDevice() {
		
		PreferencesManager pm = new PreferencesManager(getApplicationContext());
		String name = pm.getName(APOCO_PREFERENCES.FOOD_SCALE);
		String address = pm.getAdress(APOCO_PREFERENCES.FOOD_SCALE);
		if (address != null) {
			
			mBTManager.connect(address, mHandler, new GenericCreator(), StandardUUIDsIF.SPP_1101);
		}
		else {
			
			Toasting.inScreenCenter(getApplicationContext(), "Gerät für diese Messung ist Unbekannt");
		}
		
	
	}


	private void setupHandler() {
		
		mHandler = new Handler() {
			
			
			@Override
			public void handleMessage(Message msg) {
				
				super.handleMessage(msg);
				
				switch (msg.what) {
				
				
				case HandlerMessagesIF.READ: 
					
					byte[] buffer = (byte[]) msg.obj;
					
					KERN_PCB_MessageBuilder.getInstance().appendToMessage(buffer);
					
					if (KERN_PCB_MessageBuilder.getInstance().isMessageReady()) {
						
						String read = KERN_PCB_MessageBuilder.getInstance().readMessage();
						updateGewicht(read);
						calculateEnergy();
					}
					
					break;
					
					
				case HandlerMessagesIF.RECEIVING_ACCESSABLE:
					
					synchronized (this) {
						
						if (null != mConnectedThread) {
							
							mConnectedThread.cancel();
							mConnectedThread = null;
						}
						mConnectedThread = (AccessableIF) msg.obj;
						mConnectedThread.performStart();
					}
					break;
					
					
				case HandlerMessagesIF.INTERRUPTED_BY_EXCEPTION:

					mReconnectTv.setVisibility(View.VISIBLE);
					updateConnectedInfo("disconnected");
					break;
				
					
				case HandlerMessagesIF.CONNECTED_TO: 
					
					String deviceName = (String) msg.obj;
					updateConnectedInfo(deviceName);
					mReconnectTv.setVisibility(View.INVISIBLE);
					break;
					
					
				case HandlerMessagesIF.CONNECTING:
					
					String message = (String) msg.obj;
					updateConnectedInfo(message);
					break;
					
					
				case FOOD_FAILED:
					
					AlertDialog.Builder builder = new AlertDialog.Builder(ActivityFoodKcalNewEntry.this);
					builder.setTitle("unbekanter Barcode");
					String why = msg.obj.toString();
					builder.setMessage(why);
					builder.setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {
			
						@Override
						public void onClick(DialogInterface dialog, int whichButton) {
							
							updateMarke("...");
							updateProdukt("unbekannt");
						}
						
					});
					builder.create().show();
					break;
					
					
				case FOOD_SUCCESS:
					
					mFood = (FoodDTO) msg.obj;
					updateMarke(mFood.markenname);
					updateProdukt(mFood.produkt);
					break;
				}
					
			}
			
		};
	}


	private void setupFreieEinheitenTv() {
		
		mFreieEinheitenTv = (TextView) findViewById(R.id.freieEinheiten);
	}


	private void setupGesEnergieTv() {
		
		mGesEnergieTv = (TextView) findViewById(R.id.gesEnergie);
	}


	private void setupGewichtTv() {
		
		mGewichtTv = (TextView) findViewById(R.id.gewicht);
	}


	private void setupEnergieTv() {
		
		mEnergieTv = (TextView) findViewById(R.id.energie);
	}


	private void setupMarkeTv() {
		
		mMarkeTv = (TextView) findViewById(R.id.marke);
	}


	private void setupProduktTv() {
		
		mProduktTv = (TextView) findViewById(R.id.produkt);
	}


	private void setupBarcodeBtn() {
		
		mBarcodeBtn = (Button) findViewById(R.id.btnBarcode);
		mBarcodeBtn.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View view) {
				
				IntentIntegrator integrator = new IntentIntegrator(ActivityFoodKcalNewEntry.this);
				integrator.initiateScan();
			}
		});
	}


	private void setupOKBtn() {
		
		mOKBtn = (Button) findViewById(R.id.btnOK);
		mOKBtn.setOnClickListener(new OnClickListener() {
			
			
			@Override
			public void onClick(View view) {
				
				if ( !new FloatPrecision().isEqualWithinPrecision(mFoodGewicht, 0, 0.00001)) {
					
					String marke	= mFood.markenname;
					String produkt	= mFood.produkt;
					float gewicht	= mFoodGewicht;
					int energie		= mFoodEnergy;
					String barcode	= mFood.barcode;
					KcalResult result = new KcalResult(produkt, marke, gewicht, energie, barcode);
					Intent resultData = getIntent();
					resultData.putExtra(ActivityExtrasCodesIF.KCAL_RESULT, result);
					setResult(RESULT_OK, resultData);				
				} 
				onBackPressed();
			}
		});		
	}
		
	
	private void updateProdukt(String produkt) {
		
		mProduktTv.setText(produkt);
	}
	
	
	private void updateMarke(String marke) {
		
		mMarkeTv.setText(marke);
	}
	
	
	private void updateGewicht(String gewicht) {
		
		
		mFoodGewicht = Float.parseFloat(gewicht);
		mGewichtTv.setText(gewicht);
		
	}
	
	
	private void updateEnergie(String energie) {
		
		mEnergieTv.setText(energie);
	}
	
	
	private void updateGesammtenergie() {		
		
		mGesEnergieTv.setText(Integer.toString(mGesammtenergie));
	}
	
	
	private void updateFreieEinheiten() {
		
		mFreieEinheiten = mTageseinheiten.tageseinheiten - mGesammtenergie;
		mFreieEinheitenTv.setText(Integer.toString(mFreieEinheiten));
	}
	
	
	private void calculateEnergy() {
		
		
		if (null == mFood) {
			AlertDialog.Builder builder = new AlertDialog.Builder(ActivityFoodKcalNewEntry.this);
			builder.setTitle("WOOOPPSS... !!!");
			builder.setMessage("zuerst Barcode scannen");
			builder.setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {
	
				@Override
				public void onClick(DialogInterface dialog, int whichButton) {
				}
				
			});
			builder.create().show();
			return;
		}
		initData();
		mFoodEnergy = Math.round(mFood.energie_p100g / 100f * mFoodGewicht);
		mGesammtenergie += mFoodEnergy;
		updateEnergie(Float.toString(mFoodEnergy));
		updateGesammtenergie();
		updateFreieEinheiten();
	}

	
	private void updateConnectedInfo(String connected) {
		
		mConnectedInfoTv.setText(connected);
	}
	

	@Override
	public void onBackPressed() {
		
		if (null != mConnectedThread) mConnectedThread.cancel();
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);
	}
	
		
	@Override
	protected void onActivityResult(int pRequestCode, int pResultCode, Intent pData) {
		
		super.onActivityResult(pRequestCode, pResultCode, pData);
		switch(pRequestCode) {
		
		
		case IntentIntegrator.REQUEST_CODE:
			
			if (RESULT_OK == pResultCode) {
				
				if (null == pData) return;
				
				IntentResult scanResult = IntentIntegrator.parseActivityResult(pRequestCode, pResultCode, pData);
				String barcode = scanResult.getContents();
				Toasting.inScreenCenter(getApplicationContext(), "Barcode: " + barcode);
				initFood(barcode);
			}
			break;
						
		}
	}
	
	
	private void initFood(String barcode) {
		
		updateGewicht("0");
		updateEnergie("0");
		Context activity = ActivityFoodKcalNewEntry.this;
		new GetFood(activity, new NetworkHandler(activity, true), mHandler).execute(barcode);
	}
	

}
