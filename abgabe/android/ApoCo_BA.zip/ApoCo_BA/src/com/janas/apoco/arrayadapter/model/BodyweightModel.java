package com.janas.apoco.arrayadapter.model;

import java.text.SimpleDateFormat;
import java.util.Locale;

import com.janas.apoco.database.local.dto.BodyweightDTO;
import com.janas.apoco.tools.DateTemplateIF;

public class BodyweightModel {

	public String added_on;
	public String weight;
	public String unit;
	public String deviceName;
	
	
	public static BodyweightModel convertDTO_to_MODEL(BodyweightDTO dto) {
		
		BodyweightModel bwm = new BodyweightModel();
		
		SimpleDateFormat formatter = new SimpleDateFormat(DateTemplateIF.TIMESTAMP_TEMPLATE, Locale.getDefault());	    
	    bwm.added_on = formatter.format(dto.added_on);
		
		bwm.weight = Double.toString(dto.weight);
		bwm.unit = dto.unit;
		bwm.deviceName = dto.devicename;
		return bwm;
	}
}
