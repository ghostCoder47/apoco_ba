package com.janas.apoco.network;

public interface JSON_TAG_IF {

	/* in */
	public static final String DATA				= "data";
	public static final String USER 			= "user";
	public static final String SYNC 			= "sync";
	public static final String MEAL				= "meal";
	public static final String CONTENT			= "content";
	public static final String TAGESEINHEITEN 	= "tageseinheiten";
	public static final String WUNSCHGEWICHT	= "wunschgewicht";
	public static final String BARCODE			= "EAN";
	public static final String ENERGIE			= "energie";
	
	/* out */
	public static final String SUCCESS 			= "success";
	public static final String MESSAGE 			= "message";
	public static final String PAYLOAD 			= "payload";
	
}
