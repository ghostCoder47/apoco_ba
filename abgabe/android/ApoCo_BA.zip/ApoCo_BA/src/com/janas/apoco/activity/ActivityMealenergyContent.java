package com.janas.apoco.activity;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.janas.apoco.R;
import com.janas.apoco.activity.interfaces.ActivityExtrasCodesIF;
import com.janas.apoco.activity.interfaces.ActivityRequestCodesIF;
import com.janas.apoco.arrayadapter.model.MealContentModel;
import com.janas.apoco.bluetooth.AccessableIF;
import com.janas.apoco.bluetooth.BluetoothManager;
import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.bluetooth.StandardUUIDsIF;
import com.janas.apoco.database.local.DBManagerLocal;
import com.janas.apoco.database.local.dto.FoodDTO;
import com.janas.apoco.generic.GenericCreator;
import com.janas.apoco.generic.KcalResult;
import com.janas.apoco.kern.KERN_PCB_MessageBuilder;
import com.janas.apoco.preferences.APOCO_PREFERENCES;
import com.janas.apoco.preferences.PreferencesManager;
import com.janas.apoco.tools.Toasting;

public class ActivityMealenergyContent extends Activity {

	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = ActivityMealenergyContent.class.getSimpleName();
	
	
	
	private Button mReconnectBtn, mOKBtn, mBackBtn, mServerOptionsBtn, mDevicesBtn;
	private DBManagerLocal mDBManager;	
	private TextView mGesammtenergieTv, mFreieEinheitenTv, mProduktTv, mMarkeTv, mGewichtTv, mEnergieTv, mConnectTv;	
	private Handler mHandlerAct;	
	private int mGesammtenergie, mTageseinheiten, mEnergie;
	private float mGewicht;
	private FoodDTO mFoodDTO;
	private KcalResult kcalResult;
	//bt
	private AccessableIF mConnectedThread;
	private BluetoothManager mBTManager;
	
	
	@Override
	public void onCreate(Bundle pSavedInstanceState) {
		
		super.onCreate(pSavedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.activity_mealenergy_content);
		
		
		setupReconnectBtn();
		setupOKBtn();
		setupBackBtn();
		setupServerOptionsBtn();
		setupDevicesBtn();
		setupDBManager();
		setupGesammtenergieTv();
		setupTageseinheiten();
		setupFreieEinheitenTv();
		setupFoodDTO();
		setupProduktTv();
		setupMarkeTv();
		setupGewichtTv();
		setupEnergieTv();
		setupHandlerAct();
		setupBTManager();
		setupConnectTv();
		
	}

	
	private void setupDevicesBtn() {
		
		mDevicesBtn = (Button) findViewById(R.id.btnDevices);
		mDevicesBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lDevicesScreen = new Intent(getApplicationContext(), ActivityDevices.class);
				startActivityForResult(lDevicesScreen, ActivityRequestCodesIF.WHO_IS_CALLER_ACTIVITY);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);
			}
		});
	}


	private void setupServerOptionsBtn() {
		
		mServerOptionsBtn = (Button) findViewById(R.id.btnServerOptions);
		mServerOptionsBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				Intent lServerOptions = new Intent(getApplicationContext(), ActivityServerOptions.class);
				startActivity(lServerOptions);
				overridePendingTransition(R.anim.down_side_in, R.anim.down_side_out);				
			}
		});
		
	}


	private void setupBackBtn() {
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mBackBtn.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick(View pView) {
				
				onBackPressed();
			}
		});
	}


	@Override
	public void onDestroy() {
		
		mDBManager.closeDB();
		super.onDestroy();
	}
	

	private void setupReconnectBtn() {
		
		mReconnectBtn = (Button) findViewById(R.id.btnRecconect);
		mReconnectBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				//TODO reconnect
				connectToDevice();
			}
		});
	}
	
	
	private void connectToDevice() {
		
		PreferencesManager pm = new PreferencesManager(getApplicationContext());
		String name = pm.getName(APOCO_PREFERENCES.FOOD_SCALE);
		String address = pm.getAdress(APOCO_PREFERENCES.FOOD_SCALE);
		if (address != null) {
			
			if (mConnectedThread != null) mConnectedThread.cancel();
			mBTManager.connect(address, mHandlerAct, new GenericCreator(), StandardUUIDsIF.SPP_1101);
		}
		else {
			
			Toasting.inScreenCenter(getApplicationContext(), "Gerät für diese Messung ist Unbekannt");
		}
	}


	private void setupOKBtn() {
		
		mOKBtn = (Button) findViewById(R.id.btnOK);
		mOKBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				if (null != kcalResult) {
					
					Intent result = new Intent();
					result.putExtra(ActivityExtrasCodesIF.KCAL_RESULT, kcalResult);
					setResult(RESULT_OK, result);		
					Log.d(CLAZZ_NAME, "kcalResult as extra");
				}
				
				onBackPressed();
			}
		});
	}
	
	
	private void setupDBManager() {
		
		mDBManager = new DBManagerLocal(ActivityMealenergyContent.this);
	}
	

	private void setupGesammtenergieTv() {
		
		mGesammtenergieTv = (TextView) findViewById(R.id.gesEnergie);
		mGesammtenergie = getIntent().getIntExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, 7);		
		mGesammtenergieTv.setText(Integer.toString(mGesammtenergie));
	}

		
	private void setupTageseinheiten() {
		
		mTageseinheiten = getIntent().getIntExtra(ActivityExtrasCodesIF.TAGESEINHEITEN, 0);	
	}
	

	private void setupFreieEinheitenTv() {
		
		mFreieEinheitenTv = (TextView) findViewById(R.id.freieEinheiten);
		int freieEinheiten = mTageseinheiten - mGesammtenergie;
		mFreieEinheitenTv.setText(Integer.toString(freieEinheiten));
		if (freieEinheiten <= 0) {
		
			mFreieEinheitenTv.setTextColor(Color.RED);
			
			AlertDialog.Builder builder = new AlertDialog.Builder(ActivityMealenergyContent.this);
			builder.setTitle("Freieinheiten überschritten");
			builder.setMessage(String.format("Die zugelassenen Freieinheiten von: %d kcal wurden für Heute überschritten", mTageseinheiten));
			builder.setPositiveButton("OK", null);
			builder.create().show();
		}
		else
			mFreieEinheitenTv.setTextColor(Color.BLACK);
		
		
		Log.d(CLAZZ_NAME, "Freieeinheiten: " + freieEinheiten);
	}
	
	
	public void setupFoodDTO() {
		
		mFoodDTO = (FoodDTO) getIntent().getSerializableExtra(ActivityExtrasCodesIF.FOOD);
		Log.d(CLAZZ_NAME, "User: " + mFoodDTO.toString());
	}
	
	
	public void setupProduktTv() {
		
		mProduktTv = (TextView) findViewById(R.id.produkt);
		mProduktTv.setText(mFoodDTO.produkt);
	}
	
	
	public void setupMarkeTv() {
		
		mMarkeTv = (TextView) findViewById(R.id.marke);
		mMarkeTv.setText(mFoodDTO.markenname);
	}
	
	
	public void setupGewichtTv() {
		
		mGewichtTv = (TextView) findViewById(R.id.gewicht);
	}
	
	
	public void setGewicht(String gewicht) {
		
		mGewichtTv.setText(gewicht);
		mGewicht = Float.parseFloat(gewicht);
	}
	
	
	public void setupEnergieTv() {
		
		mEnergieTv = (TextView) findViewById(R.id.energie);
	}
	
	
	public void setConnectInfo(String msg) {
		
		mConnectTv.setText(msg);
	}

	
	public void setupHandlerAct() {
		
		mHandlerAct = new Handler() {
			
			@Override
			public void handleMessage(Message msg) {
				
				switch (msg.what) {
				
				
				case HandlerMessagesIF.READ: 
					
					byte[] buffer = (byte[]) msg.obj;
					
					KERN_PCB_MessageBuilder.getInstance().appendToMessage(buffer);
					
					if (KERN_PCB_MessageBuilder.getInstance().isMessageReady()) {
						
						String read = KERN_PCB_MessageBuilder.getInstance().readMessage();
						setGewicht(read);
						calculateEnergy();
						
						mGesammtenergie = getIntent().getIntExtra(ActivityExtrasCodesIF.GESAMMTENERGIE, 0) + mEnergie;
						mGesammtenergieTv.setText(Integer.toString(mGesammtenergie));
						setupFreieEinheitenTv();
						
						generateResult();
						String nachricht = String.format("energie: %d, \ngewicht: %f, \nGesammtenergie: %d\n", mEnergie, mGewicht, mGesammtenergie);
						Log.d(CLAZZ_NAME, nachricht);
					}
					
					break;
					
					
				case HandlerMessagesIF.RECEIVING_ACCESSABLE:
					
					synchronized (this) {
						
						if (null != mConnectedThread) {
							
							mConnectedThread.cancel();
							mConnectedThread = null;
						}
						mConnectedThread = (AccessableIF) msg.obj;
						mConnectedThread.performStart();
					}
					break;
					
					
				case HandlerMessagesIF.INTERRUPTED_BY_EXCEPTION:

					setConnectInfo("disconnected");
					mReconnectBtn.setText("Waage verbinden?");
					break;
				
					
				case HandlerMessagesIF.CONNECTED_TO: 
					
					String deviceName = (String) msg.obj;
					setConnectInfo(deviceName);
					mReconnectBtn.setText("connected");
					break;
					
					
				case HandlerMessagesIF.CONNECTING:
					
					String message = (String) msg.obj;
					setConnectInfo(message);
					break;
				

				}
			}
		};
	}
	
	
	private void calculateEnergy() {		
		
		mEnergie = Math.round(mFoodDTO.energie_p100g / 100f * mGewicht);
		mEnergieTv.setText(Integer.toString(mEnergie));
		Log.d(CLAZZ_NAME, "Energie: " + mEnergie);
	}
	
	
	private void generateResult() {
				
		kcalResult = new KcalResult(mFoodDTO.produkt, mFoodDTO.markenname, mGewicht, mEnergie, mFoodDTO.barcode);
	}
	
	
	public void setupBTManager() {
		
		mBTManager = new BluetoothManager();
	}
	
	
	public void setupConnectTv() {
		
		mConnectTv = (TextView) findViewById(R.id.connectedInfo);
	}
	
	
	@Override
	public void onBackPressed() {
		
		if (null != mConnectedThread) mConnectedThread.cancel();
		finish();
		overridePendingTransition(R.anim.left_side_in, R.anim.left_side_out);	
	}
}
