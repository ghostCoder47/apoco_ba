package com.janas.apoco.network.asynctask;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.activity.ActivityRegister;
import com.janas.apoco.database.extern.PHP_URL_IF;
import com.janas.apoco.database.local.dto.UserDTO;
import com.janas.apoco.database.local.tbl.UserTbl;
import com.janas.apoco.network.JSON_TAG_IF;
import com.janas.apoco.tools.ConnectivityTest;
import com.janas.apoco.tools.JSONParser;
import com.janas.apoco.tools.Toasting;
import com.janas.apoco.tools.URLBuilder;


public class RegisterNewUser extends AsyncTask<UserDTO , Void, Boolean> {
	
	
	public static final String CLAZZ_NAME = RegisterNewUser.class.getSimpleName();
	
	
	private	ProgressDialog progressDialog;
	private Context mContext;
	private Handler mHandlerNet, mHandlerAct;
	private JSONObject jsonObject;
	private UserDTO mUser;
	
	
	public RegisterNewUser(Context context, Handler handlerNet, Handler handlerAct) {
		
		this.mContext = context;
		this.mHandlerNet = handlerNet;
		this.mHandlerAct = handlerAct;
	}
	
	
	@Override
	protected void onPreExecute() {
		
		super.onPreExecute();
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setMessage("Regestrierung läuft...");
		progressDialog.setIndeterminate(false);
		progressDialog.setCancelable(true);
		progressDialog.show();
	}

	
	@Override
	protected Boolean doInBackground(UserDTO... pUser) {
		
		//netzwerk verfügbarkeit prüfen
		if (!new ConnectivityTest(mContext).isAnyNetworkReachable(mHandlerNet)) return false;
		
		
		boolean result = false;		
		mUser = pUser[0];
		
		if (null == mUser) {
			
		}
		
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair(UserTbl.VORNAME, mUser.getVorname()));
		params.add(new BasicNameValuePair(UserTbl.NACHNAME, mUser.getNachname()));
		params.add(new BasicNameValuePair(UserTbl.EMAIL, mUser.getEmail()));
		params.add(new BasicNameValuePair(UserTbl.PASSWORD, mUser.getPassword()));
		
		String url = new URLBuilder().getURL(mContext, PHP_URL_IF.REGISTER_USER);
		
		jsonObject = new JSONParser().preformHttpRequest(url, JSONParser.RequestMethodE.POST, params);
		
		Log.d(CLAZZ_NAME, jsonObject.toString());
		try {
			
			int success = jsonObject.getInt(JSON_TAG_IF.SUCCESS);
			if (1 == success) {
				
				result = true;
				Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			} else {
				
				result = false;
				Log.d(CLAZZ_NAME, jsonObject.getString(JSON_TAG_IF.MESSAGE));
			}
		} catch (JSONException ex) {
			
			Log.e("JSONException ", ex.getMessage());
		}
		
		return result;
	}

	@Override
	protected void onPostExecute(Boolean result) {
		
		if (!result) {
			
			if (null != jsonObject) {
				
				try {
					
					AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
					builder.setTitle("Regestrierung");
					builder.setMessage(jsonObject.getString(JSON_TAG_IF.MESSAGE));
					builder.setPositiveButton("OK",null);
					builder.create().show();
					
				} catch (JSONException e) {
					
					Log.d(CLAZZ_NAME, e.getMessage());
				}
				
			} else {
			
				String msg = "Registrierung ist fehlgeschlagen";
				Toasting.inScreenCenter(mContext, msg);
			}
			
			//resetPasswordVields();
			mHandlerAct.obtainMessage(ActivityRegister.CLEAR_PASSWORD).sendToTarget();
		} else {
			
			mHandlerAct.obtainMessage(ActivityRegister.REGISTER_USER_SUCCESSFUL, mUser).sendToTarget();
		}
		progressDialog.dismiss();
	}		

}
