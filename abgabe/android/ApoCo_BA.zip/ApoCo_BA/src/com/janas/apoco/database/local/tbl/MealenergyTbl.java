package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.MealenergyColumns;
import com.janas.apoco.database.local.columns.UserColumns;

public class MealenergyTbl implements MealenergyColumns {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = MealenergyTbl.class.getSimpleName();
	public static final String TABLE_NAME = "mealenergy";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 		" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				U_ID + 		" INTEGER NOT NULL," + 
				ADDED_ON + 	" TIMESTAMP NOT NULL DEFAULT current_timestamp," + 
				SYNC + 		" INTEGER NOT NULL DEFAULT 0," +
				"FOREIGN KEY(" + U_ID + ") REFERENCES " + UserTbl.TABLE_NAME + "(" + UserColumns._ID + ")" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_MEALENERGY_OF_TODAY = 
			
			"SELECT " + _ID + " FROM " + TABLE_NAME +
			" WHERE " + ADDED_ON + " >=  ?" + 
			" AND " + ADDED_ON + " < ?" + 
			" AND " + U_ID + "= ?";

	
	public static final String STMT_INSERT_MEAL = 
			
			"INSERT INTO " + TABLE_NAME + "(" +
			U_ID + "," + 
			ADDED_ON + ")" +
			"VALUES (?,?)";
	
	
	public static final String STMT_INIT_MEALENERGY_LIST = 
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + "=?";
	
	public static final String STMT_SYNCHRONIZE_MEALENERGY =
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + U_ID + "=?" + 
			" AND " + SYNC + " = 0";

}
