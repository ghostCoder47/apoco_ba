package com.janas.apoco.bluetooth;

public interface AccessableIF {
	
	public void writeTo(byte[] pMsg);
	public void performStart();
	public void cancel();
}
