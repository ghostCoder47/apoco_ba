package com.janas.apoco.database.local.columns;

public interface MealenergyContentColumns {

	
	public static final String _ID 			= "_id";
	public static final String MEAL_ID 		= "meal_id";
	public static final String BARCODE 		= "barcode";
	public static final String ENERGIE_KCAL = "energie_kcal";
	public static final String WEIGHT		= "weight";
	public static final String SYNC			= "sync";
}
