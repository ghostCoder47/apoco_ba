package com.janas.apoco.database.local.columns;

public interface UserColumns {

	
	static final String _ID 		= "_id";
	static final String VORNAME 	= "vorname";
	static final String NACHNAME 	= "nachname";
	static final String EMAIL 		= "email";
	static final String PASSWORD 	= "password";
	
}
