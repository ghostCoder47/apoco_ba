package com.janas.apoco.preferences;


import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {
	
	private SharedPreferences mApocoPref;
	
	public PreferencesManager(Context pActivity) {
		
		mApocoPref = pActivity.getSharedPreferences(APOCO_PREFERENCES.FILENAME, Context.MODE_PRIVATE);
	}
	
	
	public boolean updateDevice(String type, String pAddress, String pName) {
		
		if (type.equals(APOCO_PREFERENCES.BODY_SCALE)) {
			
			return updateBodyScale(pAddress, pName);
		} else if (type.equals(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR)) {
			
			return updateBloodPressureMonitor(pAddress, pName);
		} else if (type.equals(APOCO_PREFERENCES.FOOD_SCALE)) {
			
			return updateFoodScale(pAddress, pName);
		} else return false;
	}
	
	
	public boolean updateBodyScale(String pAddress, String pName) {
		
		SharedPreferences.Editor lPrefEditor = mApocoPref.edit();
		lPrefEditor.putString(APOCO_PREFERENCES.BODY_SCALE_ADDRESS, pAddress);
		lPrefEditor.putString(APOCO_PREFERENCES.BODY_SCALE_NAME, pName);
		return lPrefEditor.commit();
	}
	
	
	public boolean updateFoodScale(String pAddress, String pName) {
		
		SharedPreferences.Editor lPrefEditor = mApocoPref.edit();
		lPrefEditor.putString(APOCO_PREFERENCES.FOOD_SCALE_ADDRESS, pAddress);
		lPrefEditor.putString(APOCO_PREFERENCES.FOOD_SCALE_NAME, pName);
		return lPrefEditor.commit();		
	}


	public boolean updateBloodPressureMonitor(String pAddress, String pName) {
	
		SharedPreferences.Editor lPrefEditor = mApocoPref.edit();
		lPrefEditor.putString(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR_ADDRESS, pAddress);
		lPrefEditor.putString(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR_NAME, pName);
		return lPrefEditor.commit();
	}
	
	
	public String getAdress(String pDevice) {
		
		if (pDevice.equals(APOCO_PREFERENCES.BODY_SCALE)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.BODY_SCALE_ADDRESS, null);
		} else if (pDevice.equals(APOCO_PREFERENCES.FOOD_SCALE)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.FOOD_SCALE_ADDRESS, null);
		} else if (pDevice.equals(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR_ADDRESS, null);
		} else {
			
			return null;
		}
	}
	
	
	public String getName(String pDevice) {
		
		if (pDevice.equals(APOCO_PREFERENCES.BODY_SCALE)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.BODY_SCALE_NAME, null);
		} else if (pDevice.equals(APOCO_PREFERENCES.FOOD_SCALE)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.FOOD_SCALE_NAME, null);
		} else if (pDevice.equals(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR)) {
			
			return mApocoPref.getString(APOCO_PREFERENCES.BLOOD_PRESSURE_MONITOR_NAME, null);
		} else {
			
			return null;
		}
	}
	
	
	public boolean updateServerPort(String pServerPort) {
		
		SharedPreferences.Editor lPrefEditor = mApocoPref.edit();
		lPrefEditor.putString(APOCO_PREFERENCES.SERVER_PORT, pServerPort);
		return lPrefEditor.commit();
	}
	
	
	public boolean updateServerIP(String pServerIP) {
		
		SharedPreferences.Editor lPrefEditor = mApocoPref.edit();
		lPrefEditor.putString(APOCO_PREFERENCES.SERVER_IP, pServerIP);
		return lPrefEditor.commit();
	}
	
	
	public String getServerPort() {
		
		return mApocoPref.getString(APOCO_PREFERENCES.SERVER_PORT, null);
	}
	
	
	public String getServerIP() {
		
		return mApocoPref.getString(APOCO_PREFERENCES.SERVER_IP, null);
	}

}
