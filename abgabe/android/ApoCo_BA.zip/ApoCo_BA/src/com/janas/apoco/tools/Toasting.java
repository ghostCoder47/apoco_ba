package com.janas.apoco.tools;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

/**
 * Eigene Konfigurationsklasse für Android Toast.
 * Die Toasts sollen mittig auf dem Bildschirm dargestellt werden.
 */
public class Toasting {

	
	public static void inScreenCenter(Context pContext, String pMessage) {
				
		Toast lToast = Toast.makeText(pContext, pMessage, Toast.LENGTH_SHORT);
		lToast.setGravity(Gravity.CENTER | Gravity.CENTER, 0,  0);
		lToast.show();
	}

}
