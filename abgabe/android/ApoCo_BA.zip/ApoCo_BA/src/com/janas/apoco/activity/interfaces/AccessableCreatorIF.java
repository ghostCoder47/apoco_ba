package com.janas.apoco.activity.interfaces;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;

import com.janas.apoco.bluetooth.AccessableIF;

public interface AccessableCreatorIF {
	
	public abstract AccessableIF createAccessable(Handler pHandler, BluetoothSocket pSocket);

}
