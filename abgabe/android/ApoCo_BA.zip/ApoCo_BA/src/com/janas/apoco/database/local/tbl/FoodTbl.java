package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.FoodColumns;

public class FoodTbl implements FoodColumns {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = FoodTbl.class.getSimpleName();
	public static final String TABLE_NAME = "food";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 			" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				BARCODE + 		" TEXT NOT NULL," + 
				MARKENNAME + 	" TEXT NOT NULL," + 
				PRODUKT + 		" TEXT NOT NULL, " + 
				ENERGIE_P100G + " INTEGER NOT NULL DEFAULT 0" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_GET_FOOD = 
			
			"SELECT * FROM " + TABLE_NAME +
			" WHERE " + BARCODE + "=?";
	
	
	public static final String STMT_INSERT_FOOD =
			
			"INSERT INTO " + TABLE_NAME + "(" +
			BARCODE + "," +
			MARKENNAME + "," +
			PRODUKT + "," +
			ENERGIE_P100G + ")" +
			"VALUES (?,?,?,?)";

}
