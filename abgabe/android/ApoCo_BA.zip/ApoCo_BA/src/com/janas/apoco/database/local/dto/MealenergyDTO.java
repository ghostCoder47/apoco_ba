package com.janas.apoco.database.local.dto;

import java.io.Serializable;
import java.sql.Timestamp;

import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.util.Log;

import com.janas.apoco.database.local.tbl.MealenergyTbl;
import com.janas.apoco.tools.TimeTools;

public class MealenergyDTO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = MealenergyDTO.class.getSimpleName();
	
	
	public long _id;
	public long u_id;
	public Timestamp added_on;
	public int sync;
	
	
	public MealenergyDTO(UserDTO user) {
		
		this.u_id = user._id;
		
		long time = System.currentTimeMillis();
		this.added_on = new Timestamp(time);
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public MealenergyDTO(long id, long u_id, long added_on, int sync) {
		
		this._id = id;
		this.u_id = u_id;
		this.added_on = new Timestamp(added_on);
		this.sync = sync;
		
		Log.d(CLAZZ_NAME, toString());
	}
	
	
	public MealenergyDTO(Cursor cursor) {
		
		int idxID 		= cursor.getColumnIndex(MealenergyTbl._ID);
		int idxU_id		= cursor.getColumnIndex(MealenergyTbl.U_ID);
		int idxAdded_on = cursor.getColumnIndex(MealenergyTbl.ADDED_ON);
		int idxSync		= cursor.getColumnIndex(MealenergyTbl.SYNC);
		
		this._id 			= cursor.getLong(idxID);
		this.u_id 			= cursor.getInt(idxU_id);
		
		Log.d(CLAZZ_NAME, "TIME: " + cursor.getLong(idxAdded_on));
		this.added_on		= new Timestamp(cursor.getLong(idxAdded_on));
		this.sync			= cursor.getInt(idxSync);
		
		Log.d(CLAZZ_NAME, toString());
	}


	public long get_id() {
		return _id;
	}


	public void set_id(long _id) {
		this._id = _id;
	}


	public long getU_id() {
		return u_id;
	}


	public void setU_id(long u_id) {
		this.u_id = u_id;
	}


	public Timestamp getAdded_on() {
		return added_on;
	}


	public void setAdded_on(Timestamp added_on) {
		this.added_on = added_on;
	}


	public int getSync() {
		return sync;
	}


	public void setSync(int sync) {
		this.sync = sync;
	}


	@Override
	public String toString() {
		return "MealenergyDTO [_id=" + _id + ", u_id=" + u_id + ", added_on="
				+ added_on + ", sync=" + sync + "]";
	}
	
	
	public JSONObject toJSONObject() {
		
		JSONObject obj = new JSONObject();
		try {
			
			
			obj.put(MealenergyTbl._ID, this._id);
			obj.put(MealenergyTbl.U_ID, this.u_id);
			obj.put(MealenergyTbl.ADDED_ON, this.added_on);
			obj.put(MealenergyTbl.SYNC, this.sync);
			
		} catch (JSONException e) {
			
			Log.d(CLAZZ_NAME, "toJSONObject failed: " + e.getMessage());
		}
		return obj;
	}
	
}
