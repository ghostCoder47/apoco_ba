package com.janas.apoco.tools;

public class FloatPrecision {

	public boolean isEqualWithinPrecision(final double value, final double expected, final double epsilon) {
		
		return value > expected - epsilon && value < expected + epsilon;
	}
}
