package com.janas.apoco.tools;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.util.Log;

import com.janas.apoco.bluetooth.HandlerMessagesIF;
import com.janas.apoco.preferences.PreferencesManager;

public class ConnectivityTest {
	
	
	public static final String CLAZZ_NAME = ConnectivityTest.class.getSimpleName();
	
	
	private Context mContext;
	
	
	public ConnectivityTest(Context context) {
		
		this.mContext = context;
	}
	
	
	public boolean isAnyNetworkReachable(Handler handler) {
		
		ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo ni = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		
		if (null != ni) {
			
			boolean isWifiAvail = ni.isAvailable();
			boolean isWifiConn = ni.isConnected();
			boolean isWifi = isWifiAvail && isWifiConn;
			if (isWifi)	return checkServerAnswear(handler);
		}
		
		ni = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		
		if (null != ni) {
			
			boolean isMobileAvail = ni.isAvailable();
			boolean isMobileConn = ni.isConnected();
			boolean isMobile = isMobileAvail && isMobileConn;
			if (isMobile) return checkServerAnswear(handler);
		}
		
		handler.obtainMessage(HandlerMessagesIF.NETWORK_DISCONNECTED).sendToTarget();
		return false;
		
	}
	
	
	private boolean checkServerAnswear(Handler handler) {
		
		String ip = null;
		URL url;
		try {
			
			ip = new PreferencesManager(mContext).getServerIP();				
			url = new URL(String.format("http://%s/", ip));
			HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
            urlc.setRequestProperty("Connection", "close");
            urlc.setConnectTimeout(5000); // Timeout 5 seconds.
            urlc.connect();

            if (urlc.getResponseCode() == 200) { //Successful response.
            	
            	handler.obtainMessage(HandlerMessagesIF.SERVER_RESPONDING_200_SUCCESS).sendToTarget();
            	return true;
            } 
            else {
            	
    			handler.obtainMessage(HandlerMessagesIF.NO_SERVER_RESPONSE_200, ip).sendToTarget();
    			return false;
            }			
		} catch (MalformedURLException e) {
			
			Log.d(CLAZZ_NAME, "isNetworkReachable failed: " + e.getMessage());
			handler.obtainMessage(HandlerMessagesIF.URL_CONNECTION_ERROR, ip).sendToTarget();
			return false;
		} catch (IOException e) {
			
			Log.d(CLAZZ_NAME, "isNetworkReachable failed: " + e.getMessage());
			handler.obtainMessage(HandlerMessagesIF.URL_CONNECTION_ERROR, ip).sendToTarget();
			return false;
		}			
	}

}
