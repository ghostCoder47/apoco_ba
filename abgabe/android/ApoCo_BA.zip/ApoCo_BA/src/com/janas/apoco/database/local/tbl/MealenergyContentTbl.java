package com.janas.apoco.database.local.tbl;

import com.janas.apoco.database.local.columns.FoodColumns;
import com.janas.apoco.database.local.columns.MealenergyColumns;
import com.janas.apoco.database.local.columns.MealenergyContentColumns;

public class MealenergyContentTbl implements MealenergyContentColumns {
	
	
	public static final boolean DEBUG = true;
	public static final String CLAZZ_NAME = MealenergyContentTbl.class.getSimpleName();
	public static final String TABLE_NAME = "mealenergy_content";
	
	
	public static final String SQL_CREATE = 
			
			"CREATE TABLE " + TABLE_NAME + "(" + 
				_ID + 			" INTEGER PRIMARY KEY AUTOINCREMENT," + 
				MEAL_ID + 		" INTEGER NOT NULL," + 
				BARCODE + 		" TEXT NOT NULL," +
				ENERGIE_KCAL + 	" INTEGER NOT NULL," +
				WEIGHT +		" REAL NOT NULL," +
				SYNC + 			" INTEGER NOT NULL DEFAULT 0," +
				"FOREIGN KEY(" + MEAL_ID + ") REFERENCES " + MealenergyTbl.TABLE_NAME + "(" + MealenergyColumns._ID + ")," +
				"FOREIGN KEY(" + BARCODE + ") REFERENCES " + FoodTbl.TABLE_NAME +"(" + FoodColumns.BARCODE + ")" +
			");" ; 
	
	
	public static final String SQL_DROP = 
			
			"DROP TABLE IF EXISTS " + 
			TABLE_NAME;
	
	
	public static final String STMT_MEALENERGY_CONTENT = 
			
			"SELECT * FROM " + TABLE_NAME +
			" WHERE " + MEAL_ID + "= ?";
	

	public static final String STMT_INSERT_MEALCONTENT = 
			
			"INSERT INTO " + TABLE_NAME + "(" +
			MEAL_ID + "," + 
			BARCODE + "," +
			ENERGIE_KCAL + "," +
			WEIGHT + ")" +
			"VALUES (?,?,?,?)";
	
	
	public static final String STMT_INIT_MEALENERGY_CONTENT_LIST = 
			
			"SELECT * FROM " + TABLE_NAME + 
			" WHERE " + MEAL_ID + "=?";
	
	

			

}
