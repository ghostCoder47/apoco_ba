


<?php


interface WunschgewichtColumns {
	
	const _ID 			= "_id";
	const U_ID 			= "u_id";
	const ADDED_ON 		= "added_on";
	const WUNSCHGEWICHT = "wunschgewicht";
	const UNIT = "unit";
}

?>