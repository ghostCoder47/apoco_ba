

<?php

interface JSON_TAGS {

	
	const SUCCESS	= "success";
	const MESSAGE 	= "message";
	const PAYLOAD 	= "payload";
	const USER 		= "user";
	const EAN		= "EAN";
}		
?>