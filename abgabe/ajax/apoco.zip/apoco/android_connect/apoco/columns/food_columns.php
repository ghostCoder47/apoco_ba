

<?php


interface FoodColumns {
	
	const HERSTELLER 			= "hersteller";
	const MARKENNAME 			= "markenname";
	const PRODUKT 				= "produkt";
	const GLUTEN 				= "gluten";
	const LACTOSE 				= "lactose";
	const KREBSTIERE 			= "krebstiere";
	const EIERPRODUKTE 			= "eierprodukte";
	const FISCH 				= "fisch";
	const ERDNUESSE 			= "erdnuesse";
	const SOJA 					= "soja";
	const MILCH 				= "milch";
	const NUESSE 				= "nuesse";
	const SELLERIE 				= "sellerie";
	const SENF 					= "senf";
	const SESAM 				= "sesam";
	const SCHWEFELDIOXID 		= "schwefeldioxid";
	const BASIS_ENERGIE 		= "basis_energie";
	const BASISEINHEIT_ENERGIE 	= "basiseinheit_energie";
	const ZUTATEN 				= "zutaten";
	const BILD 					= "bild";
	const EAN 					= "EAN";
	const KANN_GLUTEN 			= "kann_gluten";
	const KANN_LACTOSE			= "kann_lactose";
	const KANN_KREBSTIERE 		= "kann_krebstiere";
	const KANN_EIERPRODUKTE 	= "kann_eierprodukte";
	const KANN_FISCH 			= "kann_fisch";
	const KANN_ERDNUESSE 		= "kann_erdnuesse";
	const KANN_SOJA 			= "kann_soja";
	const KANN_MILCH 			= "kann_milch";
	const KANN_NUESSE 			= "kann_nuesse";
	const KANN_SELLERIE 		= "kann_sellerie";
	const KANN_SENF 			= "kann_senf";
	const KANN_SESAM 			= "kann_sesam";
	const KANN_SCHWEFELDIOXID 	= "kann_schwefeldioxid";
	const INHALTSSTOFF 			= "inhaltsstoff";
	const MENGE 				= "menge";
	const MASSEINHEIT 			= "masseinheit";
	
	
}


?>
