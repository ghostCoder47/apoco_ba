

<?php


interface BloodpressureColumns {
	
	const _ID 		= "_id";
	const U_ID 		= "u_id";
	const ADDED_ON 	= "added_on";
	const DIASTOLIC = "diastolic";
	const SYSTOLIC 	= "systolic";
	const PULSE		= "pulse";
}

?>