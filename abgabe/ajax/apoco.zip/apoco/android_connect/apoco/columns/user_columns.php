

<?php


interface UserColumns {
	
	const _ID 		= "_id";
	const VORNAME 	= "vorname";
	const NACHNAME 	= "nachname";
	const EMAIL 	= "email";
	const PASSWORD 	= "password";
}

?>