

<?php


interface TageseinheitenColumns {
	
	const _ID 				= "_id";
	const U_ID 				= "u_id";
	const ADDED_ON 			= "added_on";
	const TAGESEINHEITEN 	= "tageseinheiten";
}

?>