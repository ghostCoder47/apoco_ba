

<?php


interface MealenergyContentColumns {
	
	const _ID 			= "_id";
	const MEAL_ID 		= "meal_id";
	const BARCODE 		= "barcode";
	const ENERGIE_KCAL 	= "energie_kcal";
	const WEIGHT 		= "weight";
}

?>